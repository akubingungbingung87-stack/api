const express = require('express');
const chalk = require('chalk');
const cfonts = require('cfonts');
const fs = require('fs');
const cors = require('cors');
const path = require('path');
const axios = require('axios');
const multer = require('multer');
const os = require('os');
const session = require('express-session');

const app = express();
const PORT = process.env.PORT || 4437;

const JSONBIN_API_KEY = 'ambil di https://jsonbin.io';
const JSONBIN_AUTH_BIN_ID = '-';
const JSONBIN_STATS_BIN_ID = '-';
const JSONBIN_BLOCK_BIN_ID = '-';

const TELEGRAM_BOT_TOKEN = 'Token Bot Mu';
const TELEGRAM_CHAT_ID = 'ID TELEGRAM MU';

let blockedIPs = new Set();
let isBlockJsonLogged = false;

async function loadBlockedIPsFromBin() {
  try {
    const url = `https://api.jsonbin.io/v3/b/${JSONBIN_BLOCK_BIN_ID}/latest`;
    const res = await axios.get(url, {
      headers: { 'X-Master-Key': JSONBIN_API_KEY }
    });
    
    const record = res.data?.record;
    const list = Array.isArray(record) ? record : (record?.blockedIPs || []);
    blockedIPs = new Set(list);
    isBlockJsonLogged = false;
  } catch (err) {
    if (!isBlockJsonLogged) {
      console.log(chalk.yellow('Gagal memuat block.json dari JsonBin.io atau data belum ada.'));
      isBlockJsonLogged = true;
    }
  }
}

setInterval(() => {
  loadBlockedIPsFromBin();
}, 20000);

async function saveBlockedIPsToBin(newList) {
  const url = `https://api.jsonbin.io/v3/b/${JSONBIN_BLOCK_BIN_ID}`;
  
  await axios.put(url, newList, {
    headers: {
      'Content-Type': 'application/json',
      'X-Master-Key': JSONBIN_API_KEY
    }
  });

  blockedIPs = new Set(newList);
}

function cleanHtmlText(text) {
  if (!text) return "";
  return String(text).replace(/<\/?tg-thinking>/gi, "").trim();
}

async function sendTelegramAlert(ip, pathUrl, reqCount, durationSec) {
  if (!TELEGRAM_BOT_TOKEN || TELEGRAM_BOT_TOKEN.includes('ISI_TOKEN_BOT')) return;

  const d = new Date();
  const day = d.toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', day: 'numeric' });
  const month = d.toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', month: 'numeric' });
  const year = d.toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', year: 'numeric' });
  const timeStr = d.toLocaleTimeString('id-ID', { timeZone: 'Asia/Jakarta', hour12: false }).replace(/\./g, ':');
  
  const now = `${day}/${month}/${year} - ${timeStr} WIB`;

  const richHtml = `<h3>🚨 SPAM / DDOS DETECTED</h3>
<p>Sistem mendeteksi lonjakan request berulang yang melampaui batas toleransi keamanan server.</p>

<table bordered striped compact>
  <caption>SECURITY INCIDENT REPORT</caption>
  <tr><td>⬡ Client IP</td><td><code>${ip}</code></td></tr>
  <tr><td>⬡ Endpoint</td><td><code>${pathUrl}</code></td></tr>
  <tr><td>⬡ Frekuensi</td><td><b>${reqCount} Request / ${durationSec}s</b></td></tr>
  <tr><td>⬡ Waktu</td><td>${now}</td></tr>
  <tr><td>⬡ Status</td><td><b>Rate Limited</b></td></tr>
</table>

<hr/>
<details open>
  <summary><b>ⓘ Rekomendasi Respons</b></summary>
  <p>Tambahkan alamat IP ke daftar hitam permanen untuk memblokir akses ke seluruh endpoint API.</p>
</details>

<hr/>
<p>
  <tg-button-row align="center">
    <tg-button type="copy_text" text="${ip}">Copy IP Address</tg-button>
  </tg-button-row>
</p>

<hr/>
<footer>© security by - <a href="https://t.me/luyatiem">⋆ @mèlviñn.</a></footer>
`;

  try {
    await axios.post(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendRichMessage`, {
      chat_id: TELEGRAM_CHAT_ID,
      rich_message: {
        html: cleanHtmlText(richHtml)
      }
    }, { timeout: 8000 });
  } catch (err) {
    const fallbackHtml = 
`🚨 <b>ALERT: DETEKSI SPAM / DDOS</b> 🚨
━━━━━━━━━━━━━━━━━━━━
🌐 <b>IP Address:</b> <code>${ip}</code>
⏰ <b>Waktu:</b> ${now}
📍 <b>Endpoint:</b> <code>${pathUrl}</code>
⚠️ <b>Jumlah Request:</b> ${reqCount}x dalam ${durationSec} detik
🛡️ <b>Status:</b> <b>SPAM DETECTED</b>
━━━━━━━━━━━━━━━━━━━━`;

    await axios.post(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
      chat_id: TELEGRAM_CHAT_ID,
      text: fallbackHtml,
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [{ text: "Copy IP Address", copy_text: { text: ip } }],
          [{ text: "Open Page Developer", url: "https://api.mlvin.my.id/developer" }]
        ]
      }
    }, { timeout: 8000 }).catch(e => console.error(chalk.red('Gagal kirim Telegram Alert:'), e.message));
  }
}

const requestTracker = new Map();
const SPAM_LIMIT = 5;
const SPAM_WINDOW_MS = 3000;

const endpointCooldownMap = new Map();
const GLOBAL_COOLDOWN_MS = 10000;

setInterval(() => {
  const now = Date.now();
  for (const [ip, data] of requestTracker.entries()) {
    if (now - data.startTime > SPAM_WINDOW_MS) {
      requestTracker.delete(ip);
    }
  }
  for (const [ip, timestamp] of endpointCooldownMap.entries()) {
    if (now - timestamp > GLOBAL_COOLDOWN_MS) {
      endpointCooldownMap.delete(ip);
    }
  }
}, 60000);

function getJakartaDate() {
  return new Intl.DateTimeFormat('id-ID', {
    timeZone: 'Asia/Jakarta',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).format(new Date()).split('/').reverse().join('-');
}

let apiStats = {
  date: getJakartaDate(),
  today: 0,
  monthly: 0,
  total: 0
};

// ----------------------------------------------------
// 2. Integrasi Stats Traffic dengan JsonBin.io
// ----------------------------------------------------
async function loadStatsFromBin() {
  try {
    const url = `https://api.jsonbin.io/v3/b/${JSONBIN_STATS_BIN_ID}/latest`;
    const res = await axios.get(url, {
      headers: { 'X-Master-Key': JSONBIN_API_KEY }
    });
    
    const decoded = res.data?.record || {};
    const currentDate = getJakartaDate();

    if (decoded.date === currentDate) {
      apiStats = decoded;
    } else {
      apiStats = {
        date: currentDate,
        today: 0,
        monthly: decoded.monthly || 0,
        total: decoded.total || 0
      };
    }
  } catch (e) {
    console.log(chalk.yellow('Gagal memuat stats dari JsonBin.io, menggunakan data default lokal.'));
  }
}

async function saveStatsToBin() {
  try {
    const url = `https://api.jsonbin.io/v3/b/${JSONBIN_STATS_BIN_ID}`;
    const currentDate = getJakartaDate();

    if (apiStats.date !== currentDate) {
      apiStats.date = currentDate;
      apiStats.today = 0;
    }

    await axios.put(url, apiStats, {
      headers: {
        'Content-Type': 'application/json',
        'X-Master-Key': JSONBIN_API_KEY
      }
    });
  } catch (e) {
    console.error('Sync JsonBin Stats Error:', e.response?.data?.message || e.message);
  }
}

const upload = multer({
  dest: os.tmpdir(),
  limits: { fileSize: 50 * 1024 * 1024 }
});

app.enable("trust proxy");
app.set("json spaces", 2);

app.use(express.static(path.join(__dirname, 'src')));
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));
app.use(cors());

app.use(session({
  secret: 'xvnsync-developer-auth-key-2026',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 24 * 60 * 60 * 1000 }
}));

app.use((req, res, next) => {
  const clientIp = req.headers['x-forwarded-for']?.split(',')[0].trim() || req.socket.remoteAddress || req.ip;

  if (blockedIPs.has(clientIp)) {
    return res.status(403).json({
      creator: "t.me/luyatiem",
      message: "Akses ditolak. IP anda di Blockir",
      status: false
    });
  }

  if (req.path.startsWith('/api/') && req.path !== '/api/stats' && req.path !== '/api/data' && !req.path.startsWith('/api/internal/')) {
    const now = Date.now();
    const tracker = requestTracker.get(clientIp) || { count: 0, startTime: now, alerted: false };

    if (now - tracker.startTime <= SPAM_WINDOW_MS) {
      tracker.count++;
      if (tracker.count >= SPAM_LIMIT && !tracker.alerted) {
        tracker.alerted = true;
        const durationSec = ((now - tracker.startTime) / 1000).toFixed(1);
        sendTelegramAlert(clientIp, req.originalUrl, tracker.count, durationSec);
      }
    } else {
      tracker.count = 1;
      tracker.startTime = now;
      tracker.alerted = false;
    }

    requestTracker.set(clientIp, tracker);

    if (endpointCooldownMap.has(clientIp)) {
      const lastRequest = endpointCooldownMap.get(clientIp);
      const diff = now - lastRequest;

      if (diff < GLOBAL_COOLDOWN_MS) {
        const remainingSeconds = Math.ceil((GLOBAL_COOLDOWN_MS - diff) / 1000);
        return res.status(429).json({
          status: false,
          creator: "t.me/luyatiem",
          message: `Rate limit. Please retry after ${remainingSeconds} seconds.`
        });
      }
    }

    endpointCooldownMap.set(clientIp, now);
  }

  next();
});

const requireAuth = (req, res, next) => {
  if (req.session && req.session.user) {
    return next();
  }
  return res.status(401).json({
    status: false,
    creator: "t.me/luyatiem",
    message: "Unauthorized. Silakan login terlebih dahulu."
  });
};

app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ status: false, message: "Username dan password wajib diisi." });
  }

  try {
    const resBin = await axios.get(`https://api.jsonbin.io/v3/b/${JSONBIN_AUTH_BIN_ID}/latest`, {
      headers: {
        'X-Master-Key': JSONBIN_API_KEY
      }
    });

    const users = resBin.data.record?.users || [];
    const validUser = users.find(u => u.username === username && u.password === String(password));

    if (validUser) {
      req.session.user = { username: validUser.username, role: validUser.role || 'owner' };
      return res.json({ status: true, message: "Login berhasil!", role: validUser.role || 'owner' });
    } else {
      return res.status(401).json({ status: false, message: "Username atau password salah!" });
    }
  } catch (err) {
    return res.status(500).json({ status: false, message: "Gagal memverifikasi ke JsonBin.io: " + err.message });
  }
});

app.post('/api/logout', (req, res) => {
  req.session.destroy();
  res.json({ status: true, message: "Berhasil logout." });
});

app.get('/developer', (req, res) => {
  res.sendFile(path.join(__dirname, 'src/developer.html'));
});

app.get('/api/internal/blocked-ips', requireAuth, (req, res) => {
  const clientIp = req.headers['x-forwarded-for']?.split(',')[0].trim() || req.socket.remoteAddress || req.ip;
  res.json({
    status: true,
    clientIp: clientIp,
    user: req.session.user,
    blockedIPs: [...blockedIPs]
  });
});

app.post('/api/internal/save-blocked-ips', requireAuth, async (req, res) => {
  const { ips } = req.body;
  if (!Array.isArray(ips)) {
    return res.status(400).json({ status: false, message: "Data ips harus array" });
  }
  try {
    await saveBlockedIPsToBin(ips);
    res.json({ status: true, message: "Blacklist IP berhasil diperbarui!" });
  } catch (e) {
    res.status(500).json({ status: false, message: e.message });
  }
});

const endpointNameMap = {};

app.use((req, res, next) => {
  res.on('finish', () => {
    const cleanPath = req.path;

    if (!cleanPath.startsWith('/api/') || cleanPath === '/api/data' || cleanPath === '/api/stats' || cleanPath.startsWith('/api/internal/')) {
      return;
    }

    const currentDate = getJakartaDate();
    if (apiStats.date !== currentDate) {
      apiStats.date = currentDate;
      apiStats.today = 0;
    }

    apiStats.today++;
    apiStats.monthly++;
    apiStats.total++;
    
    saveStatsToBin();

    const clientIp = req.headers['x-forwarded-for']?.split(',')[0].trim() || req.socket.remoteAddress || req.ip;
    const status = res.statusCode;
    
    let statusColored = chalk.bold.cyan(`[${status}]`);
    if (status >= 400) {
      statusColored = chalk.bold.red(`[${status}]`);
    } else if (status >= 300) {
      statusColored = chalk.bold.yellow(`[${status}]`);
    } else if (status >= 200) {
      statusColored = chalk.bold.green(`[${status}]`);
    }

    const ipColored = chalk.bold.hex('#00f0ff')(`[${clientIp}]`);
    const fullUrl = `${req.protocol}://${req.get('host')}${req.originalUrl}`;

    console.log(`${ipColored} = ${statusColored} ${fullUrl}`);
  });

  next();
});

global.getBuffer = async (url, options = {}) => {
  try {
    const res = await axios({ method: 'get', url, headers: { 'DNT': 1, 'Upgrade-Insecure-Request': 1 }, ...options, responseType: 'arraybuffer' });
    return res.data;
  } catch (err) { return err; }
};

global.fetchJson = async (url, options = {}) => {
  try {
    const res = await axios({ method: 'GET', url, headers: { 'User-Agent': 'Mozilla/5.0' }, ...options });
    return res.data;
  } catch (err) { return err; }
};

const settings = {
  name: "Melvin Rest Api",
  description: "Melvin Rest Api is a simple and lightweight REST API built with Express, designed to provide easy access to various web functionalities.",
  apiSettings: { creator: "t.me/luyatiem" },
  linkWhatsapp: "https://whatsapp.com/channel/0029VbDlfld4yltRwFKFL73X"
};

global.apikey = ["vinn"];

app.use((req, res, next) => {
  const originalJson = res.json;
  res.json = function (data) {
    if (data && typeof data === 'object') {
      if (data.message && data.message.includes("di Blockir")) {
        return originalJson.call(this, data);
      }
      const { status, ...rest } = data;
      const responseData = {
        status: status,
        creator: "t.me/luyatiem",
        ...rest
      };
      return originalJson.call(this, responseData);
    }
    return originalJson.call(this, data);
  };
  next();
});

let totalRoutes = 0;
let rawEndpoints = {};
const registeredRoutesList = [];

const apiFolder = path.join(__dirname, './api');

function convertParametersForFrontend(parameters) {
  if (!parameters) return {};
  
  const converted = {};
  for (const [paramName, paramConfig] of Object.entries(parameters)) {
    converted[paramName] = {
      type: paramConfig.type || "string",
      ...(paramConfig.required !== undefined && { required: paramConfig.required }),
      ...(paramConfig.example && { example: paramConfig.example }),
      ...(paramConfig.value && { value: paramConfig.value }),
      ...(paramConfig.selection && { selection: paramConfig.selection })
    };
  }
  return converted;
}

const register = (ep, file) => {
  if (ep && ep.name && (ep.desc || ep.description) && ep.category && ep.path && typeof ep.run === "function") {
    const cleanPath = ep.path.split("?")[0];
    const method = ep.method ? ep.method.toLowerCase() : 'get';
    
    endpointNameMap[`${method.toUpperCase()}:${cleanPath}`] = ep.name;

    const handler = async (req, res, next) => {
      try {
        await ep.run(req, res, next);
      } catch (err) {
        next(err);
      }
    };

    if (method === 'post') {
      app.post(cleanPath, (req, res, next) => {
        upload.any()(req, res, (err) => {
          if (err) {
            return res.status(400).json({ status: false, error: err.message || "Gagal memproses file yang diunggah" });
          }

          req.apiKeyInput = req.headers['x-apikey'] || req.headers['apikey'] || req.query?.apikey || req.body?.apikey;
          handler(req, res, next);
        });
      });
    } else {
      app.get(cleanPath, (req, res, next) => {
        req.apiKeyInput = req.headers['x-apikey'] || req.headers['apikey'] || req.query?.apikey;
        handler(req, res, next);
      });
    }

    if (!rawEndpoints[ep.category]) rawEndpoints[ep.category] = [];
    
    const endpointData = {
      name: ep.name,
      description: ep?.description || ep?.desc || null,
      path: ep.path,
      method: ep.method || 'GET',
      parameters: convertParametersForFrontend(ep.parameters),
      ...(ep.innerDesc ? { innerDesc: ep.innerDesc } : {}),
      ...(ep.body ? { body: ep.body } : {})
    };
    
    rawEndpoints[ep.category].push(endpointData);
    totalRoutes++;

    registeredRoutesList.push({
      name: ep.name,
      category: ep.category,
      path: ep.path,
      method: (ep.method || 'GET').toUpperCase(),
      params: ep.parameters ? Object.keys(ep.parameters).join(', ') : 'none'
    });
  }
};

function loadAllEndpoints(directory) {
  let items;
  try {
    items = fs.readdirSync(directory);
  } catch (e) {
    return;
  }
  for (const item of items) {
    const fullPath = path.join(directory, item);
    let stat;
    try {
      stat = fs.statSync(fullPath);
    } catch (e) {
      continue;
    }
    if (stat.isDirectory()) {
      loadAllEndpoints(fullPath);
    } else if (item.endsWith('.js') && item !== 'index.js') {
      const baseName = path.relative(apiFolder, fullPath);
      try {
        delete require.cache[require.resolve(fullPath)];
        const routeModule = require(fullPath);
        if (Array.isArray(routeModule)) {
          routeModule.forEach(ep => register(ep, baseName));
        } else if (routeModule && typeof routeModule === 'object') {
          if (routeModule.endpoint) {
            register(routeModule.endpoint, baseName);
          } else {
            register(routeModule, baseName);
          }
        } else if (typeof routeModule === "function") {
          routeModule(app);
        }
      } catch (err) {
        console.error(chalk.red(`Error loading ${baseName}:`), err.message);
      }
    }
  }
}

loadAllEndpoints(apiFolder);
global.rawEndpoints = rawEndpoints;

app.get('/api/stats', (req, res) => {
  const currentDate = getJakartaDate();
  if (apiStats.date !== currentDate) {
    apiStats.date = currentDate;
    apiStats.today = 0;
    saveStatsToBin();
  }

  res.json({
    status: true,
    today: apiStats.today,
    monthly: apiStats.monthly,
    total: apiStats.total
  });
});

app.get('/api/data', (req, res) => {
  const endpoints = {
    categories: Object.keys(rawEndpoints)
      .sort((a, b) => a.localeCompare(b))
      .map(category => ({
        name: category,
        items: rawEndpoints[category]
          .sort((a, b) => a.name.localeCompare(b.name))
          .map(endpoint => ({
            name: endpoint.name,
            method: endpoint.method || 'GET',
            path: endpoint.path,
            description: endpoint.description || endpoint.desc,
            parameters: endpoint.parameters || {}
          }))
      }))
  };
  
  res.json({
    status: true,
    data: endpoints,
    message: `Loaded ${totalRoutes} endpoints`
  });
});

app.get('/settings', (req, res) => {
  const endpoints = {
    categories: Object.keys(rawEndpoints)
      .sort((a, b) => a.localeCompare(b))
      .map(category => ({
        name: category,
        items: rawEndpoints[category]
          .sort((a, b) => a.name.localeCompare(b.name))
          .map(endpoint => ({
            name: endpoint.name,
            method: endpoint.method || 'GET',
            path: endpoint.path,
            description: endpoint.description || endpoint.desc,
            parameters: endpoint.parameters || {}
          }))
      }))
  };
  
  const fullSettings = {
    status: true,
    ...settings,
    categories: endpoints.categories,
    metadata: {
      totalEndpoints: totalRoutes,
      totalCategories: endpoints.categories.length,
      lastUpdated: new Date().toISOString()
    }
  };
  
  res.json(fullSettings);
});

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'src/home.html'));
});

app.get('/api-reference', (req, res) => {
  res.sendFile(path.join(__dirname, 'src/api-reference.html'));
});

app.get('/docs', (req, res) => {
  res.sendFile(path.join(__dirname, 'src/docs.html'));
});

app.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    serverTime: new Date().toISOString(),
    uptime: process.uptime(),
    endpoints: totalRoutes
  });
});

app.use((err, req, res, next) => {
  if (res.headersSent) {
    return next(err);
  }

  const clientIp = req.headers['x-forwarded-for']?.split(',')[0].trim() || req.socket.remoteAddress || req.ip;
  const fullUrl = `${req.protocol}://${req.get('host')}${req.originalUrl}`;
  const status = 500;

  const ipColored = chalk.bold.hex('#00f0ff')(`[${clientIp}]`);
  const statusColored = chalk.bold.red(`[${status}]`);

  console.log(`${ipColored} = ${statusColored} ${fullUrl}`);

  return res.status(500).json({
    status: false,
    error: 'Internal Server Error',
    message: err.message || String(err)
  });
});

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

app.listen(PORT, '0.0.0.0', async () => {
  await loadStatsFromBin();
  await loadBlockedIPsFromBin();

  let publicIp = '';
  try {
    const { data } = await axios.get('https://api.ipify.org?format=json', { timeout: 10000 });
    publicIp = data.ip;
  } catch (err) {
    publicIp = 'Gagal memuat IP';
  }

  console.clear();

  cfonts.say('MELVIN|REST API', {
    font: 'block',
    align: 'center',
    colors: ['#00f0ff', '#ff0077'],
    background: 'transparent',
    letterSpacing: 1,
    lineHeight: 1,
    space: false
  });

  console.log('\n');

  for (let index = 0; index < registeredRoutesList.length; index++) {
    const item = registeredRoutesList[index];
    const num = String(index + 1).padStart(2, '0');
    const methodBadge = item.method === 'POST'
      ? chalk.bold.hex('#10b981')('[POST]')
      : chalk.bold.hex('#00f0ff')('[GET]');

    const catBadge = chalk.bold.hex('#cbd5e1')(`[${item.category}]`);
    const numBadge = chalk.gray(`[${num}]`);
    const nameText = chalk.bold.white(item.name);
    const pathText = chalk.hex('#94a3b8')(item.path);

    console.log(`  ${numBadge}  ${methodBadge}  ${catBadge}  ${nameText}`);
    console.log(chalk.gray(`        ⤷ Path   : `) + pathText);
    console.log(chalk.gray(`        ⤷ Params : `) + chalk.yellow(item.params));
    console.log('');

    await sleep(100);
  }

  const totalCategories = Object.keys(rawEndpoints).length;
  const title = 'REST API SERVER ACTIVE';
  const boxInner = 56;
  const tPadLeft = Math.floor((boxInner - title.length) / 2);
  const tPadRight = boxInner - title.length - tPadLeft;

  const buildRow = (label, valueRaw, valueColored) => {
    const prefix = `  ◉ ${label.padEnd(14)}: `;
    const pad = boxInner - prefix.length - valueRaw.length;
    return `${chalk.hex('#ff0077')('│')}  ${chalk.hex('#00f0ff')('◉')} ${chalk.bold.white(label.padEnd(14))}: ${valueColored}${' '.repeat(Math.max(0, pad))}${chalk.hex('#ff0077')('│')}`;
  };

  console.log(chalk.hex('#ff0077')('╭' + '─'.repeat(boxInner) + '╮'));
  console.log(chalk.hex('#ff0077')('│') + ' '.repeat(tPadLeft) + chalk.bold.hex('#00f0ff')(title) + ' '.repeat(tPadRight) + chalk.hex('#ff0077')('│'));
  console.log(chalk.hex('#ff0077')('├' + '─'.repeat(boxInner) + '┤'));
  console.log(chalk.hex('#ff0077')('│') + ' '.repeat(boxInner) + chalk.hex('#ff0077')('│'));
  console.log(buildRow('Status', 'Online', chalk.bold.greenBright('Online')));
  console.log(buildRow('Total Routes', `${totalRoutes} Endpoints`, chalk.bold.white(`${totalRoutes} Endpoints`)));
  console.log(buildRow('Categories', `${totalCategories} Categories`, chalk.bold.yellow(`${totalCategories} Categories`)));
  console.log(buildRow('Port Server', `${PORT}`, chalk.bold.cyanBright(`${PORT}`)));
  console.log(buildRow('IP Server', `${publicIp}`, chalk.bold.magentaBright(`${publicIp}`)));
  console.log(chalk.hex('#ff0077')('│') + ' '.repeat(boxInner) + chalk.hex('#ff0077')('│'));
  console.log(chalk.hex('#ff0077')('╰' + '─'.repeat(boxInner) + '╯\n'));
});

module.exports = app;