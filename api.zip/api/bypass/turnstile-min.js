const axios = require('axios');
const { shz: bycf } = require('bycf');

module.exports = [
  {
    name: "Cloudflare Turnstile Min",
    desc: "Solve and bypass Cloudflare Turnstile captcha challenges automatically to obtain clearance tokens.",
    category: "Bypass",
    path: "/api/bypass/turnstile-min",
    method: "GET",
    parameters: {
      apikey: { type: "string", required: true },
      url: { type: "string", required: true },
      sitekey: { type: "string", required: true }
    },
    async run(req, res) {
      const apikey = req.apiKeyInput || req.query?.apikey || req.body?.apikey || req.headers['x-apikey'];
      const targetUrl = req.query?.url || req.body?.url;
      const sitekey = req.query?.sitekey || req.body?.sitekey;

      if (!global.apikey || !global.apikey.includes(apikey)) {
        return res.status(403).json({ status: false, error: "Apikey invalid" });
      }

      if (!targetUrl || typeof targetUrl !== 'string' || !targetUrl.trim()) {
        return res.status(400).json({ status: false, error: "Parameter 'url' target wajib diisi!" });
      }

      if (!sitekey || typeof sitekey !== 'string' || !sitekey.trim()) {
        return res.status(400).json({ status: false, error: "Parameter 'sitekey' Turnstile wajib diisi!" });
      }

      let cleanUrl = decodeURIComponent(targetUrl).trim();
      if (!cleanUrl.startsWith('http://') && !cleanUrl.startsWith('https://')) {
        cleanUrl = 'https://' + cleanUrl.replace(/^https?:\/*/, '');
      }
      const cleanSitekey = sitekey.trim();

      const engines = [
        {
          engine: 'bycf',
          run: async () => {
            const token = await bycf.turnstileMin(cleanUrl, cleanSitekey);
            return token || null;
          }
        },
        {
          engine: 'ikyyxd',
          run: async () => {
            const url = `https://api.ikyyxd.my.id/bypass/turnstile-cf-min?url=${encodeURIComponent(cleanUrl)}&sitekey=${encodeURIComponent(cleanSitekey)}`;
            const { data } = await axios.get(url, { timeout: 45000 });

            if (!data) return null;
            const token = data.token || data.result?.token || data.data?.token || null;
            return token;
          }
        }
      ];

      const errors = [];

      for (const { engine, run } of engines) {
        try {
          const token = await run();

          if (!token) {
            throw new Error(`Engine ${engine} tidak mengembalikan token`);
          }

          return res.json({
            status: true,
            engine_used: engine,
            result: {
              target_url: cleanUrl,
              sitekey: cleanSitekey,
              token
            }
          });
        } catch (err) {
          errors.push({ engine, message: err.message || String(err) });
          continue;
        }
      }

      return res.status(500).json({
        status: false,
        error: "Semua engine gagal memproses bypass Turnstile",
        details: errors
      });
    }
  }
];
