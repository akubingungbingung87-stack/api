const axios = require('axios');

const IZEN_SITEKEY = '0x4AAAAAADNEi_2N24gpQqY0';
const TURNSTILE_API = 'https://api.ikyyxd.my.id/bypass/turnstile-cf-min';
const IZEN_BASE = 'https://izen.lol';

async function getCaptchaToken() {
  const url = `${TURNSTILE_API}?url=${encodeURIComponent(IZEN_BASE)}&sitekey=${IZEN_SITEKEY}`;
  const { data } = await axios.get(url, { timeout: 45000 });

  const token = data?.result?.token || data?.token || null;
  if (!data?.status || !token) {
    throw new Error('Gagal mendapatkan captcha token: ' + JSON.stringify(data));
  }
  return token;
}

async function bypassIzen(targetUrl) {
  const captchaToken = await getCaptchaToken();

  const { data } = await axios.post(`${IZEN_BASE}/api/bypass`, {
    url: targetUrl,
    captchaToken
  }, {
    headers: { 'Content-Type': 'application/json' },
    timeout: 45000
  });

  return data;
}

module.exports = [
  {
    name: "Bypass Izen Lol",
    desc: "Bypass a target URL through Izen Lol's bypass service, automatically solving the Cloudflare Turnstile captcha required by the site before submitting the request.",
    category: "Bypass",
    method: "GET",
    parameters: {
      apikey: { type: "string", required: true },
      url: { type: "string", required: true }
    },
    path: "/api/bypass/izen",
    async run(req, res) {
      const apikey = req.apiKeyInput || req.query?.apikey || req.body?.apikey;
      const targetUrl = req.query?.url || req.body?.url;

      if (!global.apikey || !global.apikey.includes(apikey)) {
        return res.status(403).json({ status: false, error: "Apikey invalid" });
      }

      if (!targetUrl || typeof targetUrl !== 'string' || !targetUrl.trim()) {
        return res.status(400).json({ status: false, error: "Parameter 'url' target wajib diisi!" });
      }

      let cleanUrl = decodeURIComponent(targetUrl).trim();
      if (!cleanUrl.startsWith('http://') && !cleanUrl.startsWith('https://')) {
        cleanUrl = 'https://' + cleanUrl.replace(/^https?:\/*/, '');
      }

      try {
        const result = await bypassIzen(cleanUrl);

        return res.json({
          status: true,
          result
        });
      } catch (err) {
        return res.status(500).json({
          status: false,
          error: err.message || "Gagal memproses bypass Izen Lol"
        });
      }
    }
  }
];