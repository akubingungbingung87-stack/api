const HARI_LIBUR_2026 = [
  { tanggal: '2026-01-01', nama: 'Tahun Baru Masehi 2026', jenis: 'Libur Nasional' },
  { tanggal: '2026-01-16', nama: 'Isra Mikraj Nabi Muhammad SAW', jenis: 'Libur Nasional' },
  { tanggal: '2026-02-16', nama: 'Cuti Tahun Baru Imlek 2577 Kongzili', jenis: 'Cuti Bersama' },
  { tanggal: '2026-02-17', nama: 'Tahun Baru Imlek 2577 Kongzili', jenis: 'Libur Nasional' },
  { tanggal: '2026-03-18', nama: 'Cuti Hari Suci Nyepi Tahun Baru Saka 1948', jenis: 'Cuti Bersama' },
  { tanggal: '2026-03-19', nama: 'Hari Suci Nyepi Tahun Baru Saka 1948', jenis: 'Libur Nasional' },
  { tanggal: '2026-03-20', nama: 'Cuti Hari Raya Idulfitri 1447 Hijriah', jenis: 'Cuti Bersama' },
  { tanggal: '2026-03-21', nama: 'Hari Raya Idulfitri 1447 Hijriah', jenis: 'Libur Nasional' },
  { tanggal: '2026-03-22', nama: 'Hari Raya Idulfitri 1447 Hijriah', jenis: 'Libur Nasional' },
  { tanggal: '2026-03-23', nama: 'Cuti Hari Raya Idulfitri 1447 Hijriah', jenis: 'Cuti Bersama' },
  { tanggal: '2026-03-24', nama: 'Cuti Hari Raya Idulfitri 1447 Hijriah', jenis: 'Cuti Bersama' },
  { tanggal: '2026-04-03', nama: 'Wafat Yesus Kristus', jenis: 'Libur Nasional' },
  { tanggal: '2026-04-05', nama: 'Hari Paskah', jenis: 'Libur Nasional' },
  { tanggal: '2026-05-01', nama: 'Hari Buruh Internasional', jenis: 'Libur Nasional' },
  { tanggal: '2026-05-14', nama: 'Kenaikan Yesus Kristus', jenis: 'Libur Nasional' },
  { tanggal: '2026-05-15', nama: 'Cuti Kenaikan Yesus Kristus', jenis: 'Cuti Bersama' },
  { tanggal: '2026-05-27', nama: 'Hari Raya Iduladha 1447 Hijriah', jenis: 'Libur Nasional' },
  { tanggal: '2026-05-28', nama: 'Cuti Hari Raya Iduladha 1447 Hijriah', jenis: 'Cuti Bersama' },
  { tanggal: '2026-05-31', nama: 'Hari Raya Waisak 2570', jenis: 'Libur Nasional' },
  { tanggal: '2026-06-01', nama: 'Hari Lahir Pancasila', jenis: 'Libur Nasional' },
  { tanggal: '2026-06-16', nama: 'Tahun Baru Islam 1448 Hijriah', jenis: 'Libur Nasional' },
  { tanggal: '2026-08-17', nama: 'Hari Kemerdekaan Republik Indonesia', jenis: 'Libur Nasional' },
  { tanggal: '2026-08-25', nama: 'Maulid Nabi Muhammad SAW', jenis: 'Libur Nasional' },
  { tanggal: '2026-12-24', nama: 'Cuti Hari Raya Natal', jenis: 'Cuti Bersama' },
  { tanggal: '2026-12-25', nama: 'Hari Raya Natal', jenis: 'Libur Nasional' }
];

const HARI_LIBUR_BY_YEAR = {
  2026: HARI_LIBUR_2026
};

const NAMA_HARI = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
const NAMA_BULAN = [
  'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
  'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
];

function buildBulan(tahun, bulanIndex, liburList) {
  const totalHariDalamBulan = new Date(tahun, bulanIndex + 1, 0).getDate();
  const firstDayOffset = new Date(tahun, bulanIndex, 1).getDay();
  const listHari = [];
  let jumlahTanggalMerahBulan = 0;

  for (let d = 1; d <= totalHariDalamBulan; d++) {
    const tglObj = new Date(tahun, bulanIndex, d);
    const dayOfWeek = tglObj.getDay();
    const strHari = NAMA_HARI[dayOfWeek];
    const strFormat = `${tahun}-${String(bulanIndex + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;

    const eventMatch = liburList.find(item => item.tanggal === strFormat);
    const isMinggu = dayOfWeek === 0;
    const isTanggalMerah = isMinggu || Boolean(eventMatch);

    if (isTanggalMerah) jumlahTanggalMerahBulan++;

    listHari.push({
      tanggal: d,
      hari: strHari,
      day_of_week: dayOfWeek,
      is_tanggal_merah: isTanggalMerah,
      is_minggu: isMinggu,
      keterangan: eventMatch ? eventMatch.nama : (isMinggu ? 'Minggu' : null),
      jenis: eventMatch ? eventMatch.jenis : (isMinggu ? 'Libur Akhir Pekan' : null)
    });
  }

  return {
    bulan: NAMA_BULAN[bulanIndex],
    nomor_bulan: bulanIndex + 1,
    tahun,
    offset_awal: firstDayOffset,
    total_hari: totalHariDalamBulan,
    total_tanggal_merah: jumlahTanggalMerahBulan,
    daftar_tanggal: listHari
  };
}

function getKalenderBulan(tahun, bulan) {
  const liburList = HARI_LIBUR_BY_YEAR[tahun] || [];
  const bulanData = buildBulan(tahun, bulan - 1, liburList);

  return {
    ...bulanData,
    data_libur_akurat: !!HARI_LIBUR_BY_YEAR[tahun],
    catatan: HARI_LIBUR_BY_YEAR[tahun]
      ? null
      : `Daftar hari libur nasional resmi untuk tahun ${tahun} belum tersedia di sistem ini. Hanya hari Minggu yang ditandai sebagai tanggal merah.`
  };
}

module.exports = [
  {
    name: "Kalender Indonesia",
    desc: "Get the Indonesian calendar for a specific month, including national holidays, joint leave days (cuti bersama), and total red dates. Defaults to the current real-time year.",
    category: "Information",
    method: "GET",
    parameters: {
      apikey: { type: "string", required: true },
      bulan: {
        type: "select",
        required: true,
        selection: ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"],
        value: String(new Date().getMonth() + 1)
      }
    },
    path: "/api/info/kalender",
    async run(req, res) {
      const apikey = req.apiKeyInput || req.query?.apikey || req.body?.apikey;
      const bulanInput = req.query?.bulan || req.body?.bulan;

      if (!global.apikey || !global.apikey.includes(apikey)) {
        return res.status(403).json({ status: false, error: "Apikey invalid" });
      }

      const bulan = parseInt(bulanInput, 10);
      if (!bulan || bulan < 1 || bulan > 12) {
        return res.status(400).json({ status: false, error: "Parameter 'bulan' wajib diisi angka 1-12" });
      }

      const tahun = new Date().getFullYear();

      try {
        const result = getKalenderBulan(tahun, bulan);
        return res.json({ status: true, result });
      } catch (err) {
        return res.status(500).json({ status: false, error: err.message || "Gagal mengambil data kalender" });
      }
    }
  }
];
