const axios = require('axios');

const BASE_URL = 'https://magma.esdm.go.id';
const LIST_PATH = '/v1/gunung-api/informasi-letusan';
const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

const STATUS_LABELS = {
  1: 'Level I (Normal)',
  2: 'Level II (Waspada)',
  3: 'Level III (Siaga)',
  4: 'Level IV (Awas)'
};

const MONTHS = {
  januari: 1, februari: 2, maret: 3, april: 4, mei: 5, juni: 6,
  juli: 7, agustus: 8, september: 9, oktober: 10, november: 11, desember: 12
};

function cleanText(html) {
  return String(html || '')
    .replace(/<[^>]*>/g, '')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#039;/g, "'")
    .replace(/\s+/g, ' ')
    .trim();
}

function parseIndonesianDate(text) {
  const m = String(text || '').match(/(\d{1,2})\s+([A-Za-z]+)\s+(\d{4})/);
  if (!m) return null;
  const month = MONTHS[m[2].toLowerCase()];
  if (!month) return null;
  return { day: Number(m[1]), month, year: Number(m[3]) };
}

function parseLocalTime(text) {
  const m = String(text || '').match(/(\d{1,2}):(\d{2})\s*(WIB|WITA|WIT)/);
  if (!m) return null;
  return { hhmm: `${String(Number(m[1])).padStart(2, '0')}:${m[2]}`, tz: m[3] };
}

function combineDateTime(date, time) {
  if (!date || !time) return null;
  const [h, mi] = time.hhmm.split(':').map(Number);
  const p = (n) => String(n).padStart(2, '0');
  return `${date.year}-${p(date.month)}-${p(date.day)}T${p(h)}:${p(mi)}`;
}

function parseHomepageVolcanoes(html) {
  const m = html.match(/var\s+markersGunungApi\s*=\s*(\[[\s\S]*?\])\s*[,;]/) || html.match(/var\s+markersGunungApi\s*=\s*(\[[\s\S]*?\])/);
  if (!m) return [];
  try {
    const raw = JSON.parse(m[1]);
    return raw.filter((it) => it && it.ga_code).map((it) => ({
      code: String(it.ga_code),
      name: it.ga_nama_gapi || '',
      latitude: it.ga_lat_gapi ? Number(it.ga_lat_gapi) : null,
      longitude: it.ga_lon_gapi ? Number(it.ga_lon_gapi) : null,
      elevation: it.ga_elev_gapi ? Number(it.ga_elev_gapi) : null,
      province: it.ga_prov_gapi || null,
      city: it.ga_kab_gapi || null,
      status: Number(it.ga_status || 0),
      status_label: STATUS_LABELS[Number(it.ga_status)] || 'Unknown',
      has_vona: Boolean(it.has_vona)
    }));
  } catch (_) {
    return [];
  }
}

function parseListPage(html) {
  const eruptions = [];
  const chunks = html.split(/<div class="timeline-item/).slice(1);
  let currentDateLabel = null;

  for (const chunk of chunks) {
    if (/<p class="timeline-date">/.test(chunk)) {
      const dm = chunk.match(/<p class="timeline-date">([\s\S]*?)<\/p>/);
      if (dm) currentDateLabel = cleanText(dm[1]);
      continue;
    }

    const titleM = chunk.match(/<p class="timeline-title">\s*<a[^>]*>([\s\S]*?)<\/a>/);
    if (!titleM) continue;

    const timeM = chunk.match(/<div class="timeline-time">\s*<small>([\s\S]*?)<\/small>/);
    const authorM = chunk.match(/<p class="timeline-author">[\s\S]*?<a[^>]*>([\s\S]*?)<\/a>/);
    const textM = chunk.match(/<p class="timeline-text">([\s\S]*?)<\/p>/);
    const imageM = chunk.match(/<a\s+href="([^"]*)"\s+data-lightbox="file-set"/);
    const detailM = chunk.match(/<a\s+href="([^"]*\/show)"[^>]*class="btn btn-sm btn-outline-primary"/);

    const time = parseLocalTime(timeM ? cleanText(timeM[1]) : '');
    const date = parseIndonesianDate(currentDateLabel || '');
    const detailUrl = detailM ? detailM[1] : null;
    const idMatch = detailUrl ? detailUrl.match(/([0-9a-f-]{36})/i) : null;

    eruptions.push({
      id: idMatch ? idMatch[1] : null,
      volcano_name: cleanText(titleM[1]),
      description: textM ? cleanText(textM[1]) : '',
      local_time: combineDateTime(date, time),
      timezone: time ? time.tz : null,
      date_label: currentDateLabel,
      author: authorM ? cleanText(authorM[1]) : null,
      image_url: imageM && imageM[1] ? imageM[1] : null,
      detail_url: detailUrl
    });
  }
  return eruptions;
}

async function fetchEruptionDetail(id) {
  if (!id) return null;
  try {
    const res = await axios.get(`${BASE_URL}${LIST_PATH}/${id}/show`, {
      headers: { 'User-Agent': USER_AGENT },
      timeout: 10000
    });
    const html = res.data;
    const recM = html.match(/<p class="blog-text">([\s\S]*?)<\/p>/);
    const codeM = html.match(/MAG_CODE='([A-Z0-9]+)'/);
    const centerM = html.match(/center:\s*\[(-?[\d.]+),\s*(-?[\d.]+)\]/);

    let recommendation = null;
    if (recM) {
      recommendation = cleanText(recM[1]).replace(/^rekomendasi\s*/i, '').trim();
    }

    return {
      volcano_code: codeM ? codeM[1] : null,
      recommendation,
      coordinates: centerM ? { latitude: Number(centerM[1]), longitude: Number(centerM[2]) } : null
    };
  } catch (_) {
    return null;
  }
}

module.exports = {
  name: "Info Erupsi Terkini",
  category: "Information",
  desc: "Otomatis mengambil data letusan dan erupsi gunung api terkini di Indonesia secara real-time dari MAGMA ESDM lengkap beserta rekomendasi dan koordinat.",
  path: "/api/info/magma",
  method: "GET",
  parameters: {
    apikey: {
      type: "string",
      required: true
    }
  },
  run: async (req, res) => {
    const apikey = req.apiKeyInput || req.query?.apikey || req.body?.apikey || req.headers['x-apikey'];

    if (!global.apikey || !global.apikey.includes(apikey)) {
      return res.status(403).json({
        status: false,
        message: "Apikey invalid atau tidak ditemukan"
      });
    }

    try {
      const [listRes, homeRes] = await Promise.all([
        axios.get(`${BASE_URL}${LIST_PATH}`, {
          headers: { 'User-Agent': USER_AGENT },
          timeout: 20000
        }),
        axios.get(`${BASE_URL}/`, {
          headers: { 'User-Agent': USER_AGENT },
          timeout: 20000
        })
      ]);

      const activeVolcanoes = parseHomepageVolcanoes(homeRes.data);
      const rawEruptions = parseListPage(listRes.data);

      const enrichedEruptions = await Promise.all(
        rawEruptions.slice(0, 10).map(async (item) => {
          if (!item.id) return item;
          const extra = await fetchEruptionDetail(item.id);
          if (extra) {
            return {
              ...item,
              volcano_code: extra.volcano_code,
              coordinates: extra.coordinates,
              recommendation: extra.recommendation
            };
          }
          return item;
        })
      );

      return res.status(200).json({
        status: true,
        data: {
          updated_at: new Date().toISOString(),
          total_recent_eruptions: enrichedEruptions.length,
          recent_eruptions: enrichedEruptions,
          monitored_volcanoes_count: activeVolcanoes.length,
          volcano_status_summary: activeVolcanoes.filter(v => v.status > 1)
        }
      });
    } catch (err) {
      return res.status(500).json({
        status: false,
        error: err.message || "Gagal mengambil data erupsi dari server MAGMA ESDM"
      });
    }
  }
};
