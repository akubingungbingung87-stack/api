const axios = require('axios');
const crypto = require('crypto');

const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
const BASE_URL = "https://notrack.ai";

const notrackSessions = new Map();

async function notrackChat({
  prompt,
  inputChatId = null,
  persona = "normal",
  mode = "usual"
}) {
  const sessionKey = inputChatId || crypto.randomUUID();
  const sessionData = notrackSessions.get(sessionKey) || {
    session_id: crypto.randomUUID(),
    chat_id: null
  };

  const cookieStr = `uid=${sessionData.session_id}`;

  const payload = {
    user_input: prompt.trim(),
    mode: mode || "usual",
    model: "C",
    persona: persona || "normal",
    max_turns: 10,
    chat_id: sessionData.chat_id,
    attachments: [],
    regenerate: false,
    edit: false,
    edit_mid: null,
    via: "text"
  };

  const res = await axios.post(`${BASE_URL}/api/dispatch`, payload, {
    headers: {
      "User-Agent": UA,
      "Content-Type": "application/json",
      Origin: BASE_URL,
      Referer: `${BASE_URL}/id/chat`,
      Cookie: cookieStr,
      Accept: "text/event-stream"
    },
    responseType: "stream",
    timeout: 35000
  });

  let fullAnswer = "";
  let returnedChatId = sessionData.chat_id;

  await new Promise((resolve, reject) => {
    let hasError = false;

    res.data.on("data", (chunk) => {
      const lines = chunk.toString().split("\n");
      for (const line of lines) {
        if (line.startsWith("data: ")) {
          try {
            const evt = JSON.parse(line.slice(6));
            if (evt.type === "chat_meta" && evt.chat_id) {
              returnedChatId = evt.chat_id;
            } else if (evt.type === "delta" && evt.chunk) {
              fullAnswer += evt.chunk;
            } else if ((evt.type === "message" || evt.type === "consensus") && evt.content) {
              fullAnswer = evt.content;
            } else if (evt.type === "error") {
              hasError = true;
              reject(new Error(evt.content || "Terjadi kesalahan dari NoTrack AI"));
            }
          } catch (e) {}
        }
      }
    });

    res.data.on("end", () => {
      if (!hasError) resolve();
    });

    res.data.on("error", (err) => {
      if (!hasError) reject(err);
    });
  });

  if (!fullAnswer.trim()) {
    throw new Error("NoTrack AI tidak memberikan respon jawaban");
  }

  sessionData.chat_id = returnedChatId;
  notrackSessions.set(sessionKey, sessionData);

  return {
    response: fullAnswer.trim(),
    chatId: sessionKey
  };
}

module.exports = [
  {
    name: "NoTrack AI",
    desc: "Asisten AI cerdas dan privat tanpa pelacakan berbasis NoTrack AI",
    category: "AI",
    method: "GET",
    parameters: {
      apikey: { type: "string", required: true },
      prompt: { type: "string", required: true },
      chatId: { type: "string", required: false }
    },
    path: "/api/ai/notrack",
    async run(req, res) {
      const apikey = req.apiKeyInput || req.query.apikey || req.body?.apikey;
      const prompt = req.query.prompt || req.body?.prompt;
      const chatId = req.query.chatId || req.body?.chatId || null;

      if (!global.apikey.includes(apikey)) {
        return res.status(403).json({ status: false, error: "Apikey invalid" });
      }

      if (!prompt || !prompt.trim()) {
        return res.status(400).json({ status: false, error: "Parameter prompt pertanyaan wajib diisi" });
      }

      try {
        const result = await notrackChat({
          prompt,
          inputChatId: chatId
        });

        return res.json({
          status: true,
          result: {
            prompt: prompt.trim(),
            response: result.response,
            chatId: result.chatId
          }
        });
      } catch (error) {
        return res.status(500).json({
          status: false,
          error: error.message || "Gagal mendapatkan respon dari NoTrack AI"
        });
      }
    }
  }
];
