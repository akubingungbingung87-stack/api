const axios = require('axios');
const FormData = require('form-data');
const crypto = require('crypto');
const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');

const API_BASE = 'https://api.unwatermark.ai/api/web/v1/photo-editor-nano-banana';
const HEADERS_COMMON = {
  'accept-language': 'en-GB,en;q=0.9,id-ID;q=0.8,id;q=0.7,en-US;q=0.6',
  'origin': 'https://unwatermark.ai',
  'referer': 'https://unwatermark.ai/',
  'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36'
};

function stableSerial(apikey) {
  return crypto.createHash('sha256').update(`unwatermark:${apikey}`).digest('hex').slice(0, 16);
}

async function createJob(buffer, filename, prompt, serial) {
  const form = new FormData();
  form.append('target_images', buffer, { contentType: 'image/jpeg', filename });
  form.append('prompt', prompt);
  form.append('ratio', 'match_input_image');

  const res = await axios.post(`${API_BASE}/create-job`, form, {
    headers: {
      ...form.getHeaders(),
      ...HEADERS_COMMON,
      'Product-Code': '067003',
      'Product-Serial': serial
    },
    timeout: 60000,
    validateStatus: () => true
  });

  const jobId = res.data?.result?.job_id;
  if (!jobId) {
    throw new Error(`Gagal membuat job (${res.status}): ${JSON.stringify(res.data).slice(0, 300)}`);
  }
  return jobId;
}

async function getJob(taskId) {
  const res = await axios.get(`${API_BASE}/get-job/${taskId}`, {
    headers: HEADERS_COMMON,
    timeout: 20000
  });
  return res.data;
}

async function pollJob(taskId, { maxAttempts = 40, intervalMs = 2000 } = {}) {
  for (let i = 0; i < maxAttempts; i++) {
    await new Promise(r => setTimeout(r, intervalMs));
    const data = await getJob(taskId);
    const status = data?.result?.status;

    if (status === 1) return data;
    if (status === 2 || status === 3) {
      throw new Error(`Proses gagal di sisi layanan: ${JSON.stringify(data).slice(0, 300)}`);
    }
  }
  throw new Error('Timeout menunggu hasil (80 detik)');
}

function extractImageUrl(result) {
  const r = result?.result || {};
  const candidates = [r.output, r.output_images, r.images, r.result_images, r.url, r.image_url];
  for (const c of candidates) {
    if (!c) continue;
    if (typeof c === 'string') return c;
    if (Array.isArray(c) && c.length) return c[0];
  }
  return null;
}

module.exports = [
  {
    name: "Nano Banana V3",
    desc: "Edit an uploaded image using a text prompt via the Nano Banana model on unwatermark.ai. Subject to the upstream provider's daily usage limit.",
    category: "AI",
    method: "POST",
    parameters: {
      apikey: { type: "string", required: true },
      image: { type: "file", required: true },
      prompt: { type: "string", required: true }
    },
    path: "/api/ai/nanobananav3",
    async run(req, res) {
      const apikey = req.apiKeyInput || req.query?.apikey || req.body?.apikey;
      const prompt = req.query?.prompt || req.body?.prompt;
      const uploadedFile = req.files && req.files.length > 0 ? req.files[0] : null;

      if (!global.apikey || !global.apikey.includes(apikey)) {
        return res.status(403).json({ status: false, error: "Apikey invalid" });
      }

      if (!uploadedFile || !uploadedFile.path) {
        return res.status(400).json({ status: false, error: "Wajib mengunggah file gambar (form-data: image)" });
      }

      if (!prompt || !prompt.trim()) {
        if (fs.existsSync(uploadedFile.path)) {
          try { await fsp.unlink(uploadedFile.path); } catch (e) {}
        }
        return res.status(400).json({ status: false, error: "Parameter 'prompt' wajib diisi!" });
      }

      const tempPath = uploadedFile.path;

      try {
        const buffer = fs.readFileSync(tempPath);
        const filename = uploadedFile.originalname || path.basename(tempPath);
        const serial = stableSerial(apikey);

        const jobId = await createJob(buffer, filename, prompt.trim(), serial);
        const result = await pollJob(jobId);
        const imageUrl = extractImageUrl(result);

        if (tempPath && fs.existsSync(tempPath)) {
          try { await fsp.unlink(tempPath); } catch (e) {}
        }

        if (!imageUrl) {
          return res.status(500).json({ status: false, error: "Proses selesai tetapi URL gambar hasil tidak ditemukan" });
        }

        return res.json({
          status: true,
          result: {
            job_id: jobId,
            prompt: prompt.trim(),
            image: imageUrl
          }
        });
      } catch (err) {
        if (tempPath && fs.existsSync(tempPath)) {
          try { await fsp.unlink(tempPath); } catch (e) {}
        }
        return res.status(500).json({
          status: false,
          error: err.message || "Gagal memproses edit gambar"
        });
      }
    }
  }
];
