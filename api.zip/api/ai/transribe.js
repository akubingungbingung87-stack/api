const axios = require('axios');
const crypto = require('crypto');
const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const { execFile } = require('child_process');
const { promisify } = require('util');
const execFileAsync = promisify(execFile);

const SUPABASE_URL = 'https://bgcrcrsosqswpseimvvx.supabase.co';
const SUPABASE_ANON = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJnY3JjcnNvc3Fzd3BzZWltdnZ4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mjg2NTcwOTgsImV4cCI6MjA0NDIzMzA5OH0.VH_PR47VlkvE5kDZv8Ch6H-zUGDr4mSZ9Wr5KvQ9ixc';
const API = 'https://api.uniscribe.co';

const UA = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36';

const BASE_HEADERS = {
  'User-Agent': UA,
  Origin: 'https://www.uniscribe.co',
  Referer: 'https://www.uniscribe.co/',
  'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7'
};

const MIME = {
  mp3: 'audio/mpeg',
  wav: 'audio/wav',
  m4a: 'audio/mp4',
  ogg: 'audio/ogg',
  opus: 'audio/ogg',
  webm: 'audio/webm',
  mp4: 'video/mp4'
};

const DEFAULT_LANG = 'id';

const MAX_FILE_SIZE = 50 * 1024 * 1024;
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

async function anonymousSignup() {
  const res = await axios.post(
    `${SUPABASE_URL}/auth/v1/signup`,
    { data: {}, gotrue_meta_security: {} },
    {
      headers: {
        ...BASE_HEADERS,
        apikey: SUPABASE_ANON,
        Authorization: `Bearer ${SUPABASE_ANON}`,
        'Content-Type': 'application/json;charset=UTF-8',
        'x-client-info': 'supabase-js-web/2.45.4',
        'x-supabase-api-version': '2024-01-01'
      },
      timeout: 60000
    }
  );

  return res.data?.access_token || null;
}

async function getDuration(filePath) {
  try {
    const { stdout } = await execFileAsync('ffprobe', [
      '-v', 'error',
      '-show_entries', 'format=duration',
      '-of', 'csv=p=0',
      filePath
    ], { timeout: 15000 });

    const duration = parseFloat(stdout.trim());
    return Number.isFinite(duration) ? duration : 0;
  } catch (e) {
    return 0;
  }
}

async function transcribe({ buffer, filePath, filename, ext, lang }) {
  const duration = await getDuration(filePath);
  const md5 = crypto.createHash('md5').update(buffer).digest('base64');

  const token = await anonymousSignup();
  if (!token) throw new Error('Gagal mendapatkan sesi dari layanan transkripsi');

  const api = axios.create({
    baseURL: API,
    headers: {
      ...BASE_HEADERS,
      Authorization: `Bearer ${token}`,
      Accept: 'application/json, text/plain, */*'
    },
    timeout: 120000
  });

  await api.get('/user/limits');
  await api.get('/upload/provider-policy').catch(() => null);

  const signed = await api.post('/upload/generate-signed-url', {
    filename,
    fileType: ext,
    fileSize: buffer.length,
    contentMd5Base64: md5,
    duration,
    forceUpload: true,
    languageCode: lang,
    transcriptionType: 'transcript',
    enableSpeakerDiarization: false,
    enableGlossary: false,
    providerHint: 'r2',
    premiumModelEnabled: false
  });

  const data = signed.data?.data || signed.data || {};
  const uploadUrl = data.preSignedUrl || data.signedUrl || data.uploadUrl || data.url;
  const id = data.transcriptionFileId || data.transcriptionId || data.id;

  if (!uploadUrl || !id) {
    throw new Error('Signed URL atau ID transkripsi tidak ditemukan dari layanan sumber');
  }

  await axios.put(uploadUrl, buffer, {
    headers: {
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Content-Length': buffer.length
    },
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
    timeout: 120000
  });

  await api.patch(`/transcriptions/${id}`, {
    summaryTemplate: 'none',
    summaryLanguageCode: lang
  });

  await api.post('/upload/complete', { transcriptionFileId: id });
  await api.post('/tasks/transcription', { transcriptionFileId: id });

  for (let i = 0; i < 60; i++) {
    await sleep(3000);

    const detail = await api.get(`/transcriptions/${id}`);
    const d = detail.data?.data || detail.data || {};
    const status = String(d.status || d.state || '').toLowerCase();

    if (['completed', 'complete', 'done', 'success', 'finished'].includes(status)) {
      return { id, duration, detail: d };
    }

    if (['failed', 'error', 'cancelled', 'canceled'].includes(status)) {
      throw new Error('Transkripsi gagal diproses oleh layanan sumber');
    }
  }

  throw new Error('Timeout menunggu hasil transkripsi (3 menit)');
}

function extractText(d) {
  const text =
    d.transcript ||
    d.text ||
    d.transcription ||
    d.content ||
    d.result ||
    d.data?.transcript ||
    d.data?.text ||
    d.data?.transcription;

  return typeof text === 'string' && text.trim() ? text.trim() : null;
}

module.exports = [
  {
    name: "Audio & Video Transcription",
    desc: "Transcribe speech from an uploaded audio or video file (MP3, WAV, M4A, OGG, OPUS, WEBM, MP4) into text using AI speech recognition. Default and only supported language is Indonesian (id).",
    category: "AI",
    method: "POST",
    parameters: {
      apikey: { type: "string", required: true },
      file: { type: "file", required: true }
    },
    path: "/api/ai/transcribe",
    async run(req, res) {
      const apikey = req.apiKeyInput || req.query?.apikey || req.body?.apikey;
      const uploadedFile = req.files && req.files.length > 0 ? req.files[0] : null;

      if (!global.apikey || !global.apikey.includes(apikey)) {
        return res.status(403).json({ status: false, error: "Apikey invalid" });
      }

      if (!uploadedFile || !uploadedFile.path) {
        return res.status(400).json({ status: false, error: "Wajib mengunggah file audio/video (form-data: file)" });
      }

      const tempPath = uploadedFile.path;
      const cleanup = async () => {
        if (tempPath && fs.existsSync(tempPath)) {
          try { await fsp.unlink(tempPath); } catch (e) {}
        }
      };

      const filename = uploadedFile.originalname || path.basename(tempPath);
      const ext = path.extname(filename).slice(1).toLowerCase();

      if (!MIME[ext]) {
        await cleanup();
        return res.status(400).json({
          status: false,
          error: `Format file tidak didukung. Gunakan salah satu: ${Object.keys(MIME).join(', ')}`
        });
      }

      if (uploadedFile.size && uploadedFile.size > MAX_FILE_SIZE) {
        await cleanup();
        return res.status(400).json({ status: false, error: "Ukuran file maksimal 50 MB" });
      }

      const lang = DEFAULT_LANG;

      try {
        const buffer = fs.readFileSync(tempPath);
        const { id, duration, detail } = await transcribe({ buffer, filePath: tempPath, filename, ext, lang });
        await cleanup();

        const text = extractText(detail);

        if (!text) {
          return res.status(500).json({
            status: false,
            error: "Transkripsi selesai tetapi teks hasil tidak ditemukan pada respons layanan sumber",
            raw: detail
          });
        }

        return res.json({
          status: true,
          result: {
            id,
            language: lang,
            duration_seconds: duration || null,
            text
          }
        });
      } catch (err) {
        await cleanup();

        let message = err.message || "Gagal memproses transkripsi";
        if (err.response) {
          const body = typeof err.response.data === 'string' ? err.response.data : JSON.stringify(err.response.data);
          message = `Layanan sumber membalas ${err.response.status}: ${body.slice(0, 300)}`;
        }

        return res.status(500).json({ status: false, error: message });
      }
    }
  }
];
