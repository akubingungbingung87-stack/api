const axios = require('axios');

const API = "https://api.rewind.ai";
const WEB = "https://rewind.ai";
const UA = "Mozilla/5.0 (Linux; Android 13; SM-A536E) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36";

const MODELS = {
  "qwen": "qwen/qwen-2.5-7b-instruct",
  "mistral": "mistralai/mistral-7b-instruct",
  "llama": "meta-llama/llama-3.1-8b-instruct",
  "gemma": "google/gemma-2-9b-it"
};

const MODEL_KEYS = Object.keys(MODELS);
const DEFAULT_MODEL = "qwen/qwen-2.5-7b-instruct";
const API_KEY = process.env.REWIND_API_KEY || "";

const client = axios.create({
  timeout: 60000,
  headers: {
    "User-Agent": UA,
    "Accept": "application/json, text/event-stream, */*",
    "Accept-Language": "id-ID,id;q=0.9,en;q=0.8",
    "Content-Type": "application/json",
    "Origin": WEB,
    "Referer": WEB + "/chat/"
  },
  validateStatus: s => s < 600
});

function resolveModel(input) {
  if (!input) return DEFAULT_MODEL;
  const k = String(input).toLowerCase().trim();
  if (MODELS[k]) return MODELS[k];
  if (Object.values(MODELS).includes(input)) return input;
  return DEFAULT_MODEL;
}

async function rewindChat(prompt, modelId) {
  const headers = {};
  if (API_KEY) headers.Authorization = "Bearer " + API_KEY;

  const res = await client.post(API + "/v1/chat/completions/", {
    model: modelId,
    messages: [{ role: "user", content: prompt }],
    stream: true
  }, {
    responseType: "stream",
    headers
  });

  if (res.status >= 400) {
    throw new Error(`Rewind API Error: HTTP ${res.status}`);
  }

  return new Promise((resolve, reject) => {
    let buffer = "";
    let text = "";
    let done = false;

    const handleLine = line => {
      const trimmed = line.trim();
      if (!trimmed || done) return;
      if (trimmed === "data: [DONE]" || trimmed === "[DONE]") { 
        done = true; 
        return; 
      }
      let payload = trimmed;
      if (payload.startsWith("data:")) payload = payload.slice(5).trim();
      if (!payload) return;
      try {
        const obj = JSON.parse(payload);
        const delta = obj.choices?.[0]?.delta?.content || obj.choices?.[0]?.message?.content || "";
        if (delta) text += delta;
      } catch (_) {}
    };

    res.data.on("data", chunk => {
      buffer += chunk.toString("utf8");
      const lines = buffer.split("\n");
      buffer = lines.pop();
      for (const l of lines) handleLine(l);
    });

    res.data.on("end", () => {
      if (buffer) handleLine(buffer);
      resolve(text.trim());
    });

    res.data.on("error", reject);
  });
}

module.exports = {
  name: "Rewind AI",
  category: "AI",
  desc: "High-performance AI chat powered by Rewind AI with multi-model support including Qwen, Mistral, Llama, and Gemma.",
  path: "/api/ai/rewind",
  method: "GET",
  parameters: {
    apikey: {
      type: "string",
      required: true
    },
    prompt: {
      type: "string",
      required: true
    },
    model: {
      type: "select",
      required: false,
      value: "qwen",
      selection: MODEL_KEYS
    }
  },
  run: async (req, res) => {
    try {
      const apiKey = req.apiKeyInput || req.query.apikey || req.body?.apikey;
      const prompt = req.query?.prompt || req.body?.prompt;
      const modelInput = req.query?.model || req.body?.model || "qwen";

      if (!apiKey || !global.apikey || !global.apikey.includes(apiKey)) {
        return res.status(403).json({
          status: false,
          message: "Apikey invalid atau tidak ditemukan"
        });
      }

      if (!prompt || !prompt.trim()) {
        return res.status(400).json({
          status: false,
          message: "Parameter 'prompt' wajib diisi!"
        });
      }

      const activeModel = resolveModel(modelInput);
      const answer = await rewindChat(prompt, activeModel);

      return res.status(200).json({
        status: true,
        result: {
          text: answer,
          model: activeModel
        }
      });
    } catch (err) {
      return res.status(500).json({
        status: false,
        error: err.message || "Gagal mendapatkan respon dari Rewind AI"
      });
    }
  }
};