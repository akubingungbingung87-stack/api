const axios = require('axios');
const fs = require('fs');
const fsp = require('fs/promises');

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

async function unblurImage(buffer) {
  const fileId = Date.now().toString();

  const actionRes = await axios.post(
    'https://unblurimg.ai/',
    JSON.stringify(['image/jpeg', buffer.length, fileId]),
    {
      headers: {
        'Next-Action': 'f5c9f94f5b370b337d1195b4e3e09f3fc73ce571',
        'Content-Type': 'text/plain;charset=UTF-8',
        'User-Agent': UA
      },
      timeout: 30000
    }
  );

  const matchUrl = actionRes.data.match(/"url":"(https:\/\/[^"]+)"/);
  const matchKey = actionRes.data.match(/"key":"([^"]+)"/);
  if (!matchUrl || !matchKey) {
    throw new Error('Gagal mendapatkan upload presigned URL dari unblurimg.ai');
  }

  const putUrl = matchUrl[1].replace(/\\u0026/g, '&');
  const objectKey = matchKey[1];

  await axios.put(putUrl, buffer, {
    headers: { 'Content-Type': 'image/jpeg' },
    timeout: 60000
  });

  const processRes = await axios.post(
    'https://unblurimg.ai/api/smart-tools/unblur-image',
    { originImageUrl: objectKey },
    {
      headers: {
        'Content-Type': 'application/json',
        'Origin': 'https://unblurimg.ai',
        'Referer': 'https://unblurimg.ai/',
        'User-Agent': UA
      },
      timeout: 60000
    }
  );

  if (processRes.data?.code !== 0 || !processRes.data?.data?.generatedImageUrl) {
    throw new Error(processRes.data?.message || 'Gagal memproses unblur gambar');
  }

  return {
    original: processRes.data.data.originImageUrl,
    result: processRes.data.data.generatedImageUrl
  };
}

module.exports = [
  {
    name: "Unblur Image AI",
    desc: "Enhance and sharpen a blurry uploaded image using AI, returning both the original uploaded reference and the enhanced result image URL.",
    category: "AI",
    method: "POST",
    parameters: {
      apikey: { type: "string", required: true },
      image: { type: "file", required: true }
    },
    path: "/api/ai/unblurimage",
    async run(req, res) {
      const apikey = req.apiKeyInput || req.query?.apikey || req.body?.apikey;
      const uploadedFile = req.files && req.files.length > 0 ? req.files[0] : null;

      if (!global.apikey || !global.apikey.includes(apikey)) {
        return res.status(403).json({ status: false, error: "Apikey invalid" });
      }

      if (!uploadedFile || !uploadedFile.path) {
        return res.status(400).json({ status: false, error: "Wajib mengunggah file gambar (form-data: image)" });
      }

      const tempPath = uploadedFile.path;

      try {
        const buffer = fs.readFileSync(tempPath);
        const result = await unblurImage(buffer);

        if (tempPath && fs.existsSync(tempPath)) {
          try { await fsp.unlink(tempPath); } catch (e) {}
        }

        return res.json({ status: true, result });
      } catch (err) {
        if (tempPath && fs.existsSync(tempPath)) {
          try { await fsp.unlink(tempPath); } catch (e) {}
        }
        return res.status(500).json({
          status: false,
          error: err.message || "Gagal memproses unblur gambar"
        });
      }
    }
  }
];
