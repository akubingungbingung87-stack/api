const axios = require('axios');
const crypto = require('crypto');
const fs = require('fs');

const config = {
  baseUrl: "https://apiv1.deepfakemaker.io/api",
  sSalt: "NHGNy5YFz7HeFb",
  publicKey: "-----BEGIN PUBLIC KEY-----\nMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDa2oPxMZe71V4dw2r8rHWt59gH\nW5INRmlhepe6GUanrHykqKdlIB4kcJiu8dHC/FJeppOXVoKz82pvwZCmSUrF/1yr\nrnmUDjqUefDu8myjhcbio6CnG5TtQfwN2pz3g6yHkLgp8cFfyPSWwyOCMMMsTU9s\nsnOjvdDb4wiZI8x3UwIDAQAB\n-----END PUBLIC KEY-----",
  headers: {
    "Access-Control-Allow-Credentials": "true",
    "Content-Type": "application/json",
    "User-Agent": "Mozilla/5.0 (Android 15; Mobile; SM-F958; rv:130.0) Gecko/130.0 Firefox/130.0",
    "Referer": "https://deepfakemaker.io/nano-banana-ai/"
  }
};

const createRandomStr = (length) => {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  return Array.from(crypto.randomBytes(length), (b) => chars[b % chars.length]).join("");
};

const getSecurityParams = (appId) => {
  const t = Math.floor(Date.now() / 1000).toString();
  const nonce = crypto.randomUUID();
  const tempAesKey = createRandomStr(16);
  const secretKey = crypto.publicEncrypt(
    { key: config.publicKey, padding: crypto.constants.RSA_PKCS1_PADDING },
    Buffer.from(tempAesKey)
  ).toString("base64");

  const dataToSign = `${appId}:${config.sSalt}:${t}:${nonce}:${secretKey}`;
  const cipher = crypto.createCipheriv("aes-128-cbc", Buffer.from(tempAesKey, "utf8"), Buffer.from(tempAesKey, "utf8"));
  const sign = cipher.update(dataToSign, "utf8", "base64") + cipher.final("base64");

  return { app_id: appId, t, nonce, sign, secret_key: secretKey };
};

const delay = (ms) => new Promise((res) => setTimeout(res, ms));

async function processNanoBanana(promptText, imagePath) {
  const imageBuffer = fs.readFileSync(imagePath);
  const userId = createRandomStr(64).toLowerCase();
  const fileHash = crypto.createHash("sha256").update(imageBuffer).digest("hex");
  const filename = `${createRandomStr(32)}_${Date.now()}.jpg`;

  const uploadSignRes = await axios.post(
    `${config.baseUrl}/user/v2/upload-sign`,
    { filename, hash: fileHash, user_id: userId },
    { params: getSecurityParams("ai_df"), headers: config.headers }
  );

  const fileSignData = uploadSignRes.data?.data;
  if (!fileSignData?.url) throw new Error("Gagal mendapatkan link upload storage internal.");

  await axios.put(fileSignData.url, imageBuffer, {
    headers: { "content-type": "image/jpeg", "content-length": imageBuffer.length }
  });

  const taskRes = await axios.post(
    `${config.baseUrl}/replicate/v1/free/nano/banana/task`,
    {
      prompt: promptText,
      platform: "nano_banana",
      images: [`https://cdn.deepfakemaker.io/${fileSignData.object_name}`],
      output_format: "png",
      user_id: userId
    },
    { params: getSecurityParams("ai_df"), headers: config.headers }
  );

  const taskData = taskRes.data?.data;
  if (!taskData) throw new Error(taskRes.data?.msg || "Gagal membuat task antrean gambar.");

  let resultImageUrl = null;
  let retries = 25;
  while (!resultImageUrl && retries > 0) {
    await delay(2500);
    const pollParams = { ...getSecurityParams("ai_df"), user_id: userId, ...taskData };
    const checkRes = await axios.get(`${config.baseUrl}/replicate/v1/free/nano/banana/task`, {
      params: pollParams,
      headers: config.headers
    });

    if (checkRes.data?.msg === "success" && checkRes.data?.data?.generate_url) {
      resultImageUrl = checkRes.data.data.generate_url;
      break;
    }
    retries--;
  }

  if (!resultImageUrl) throw new Error("Waktu proses melebihi batas (Timeout)");
  return resultImageUrl;
}

module.exports = {
  name: "Nano Banana V2",
  category: "AI",
  desc: "Transform and edit image visuals intelligently based on prompt instructions powered by Nano Banana AI",
  path: "/api/ai/nanobananav2",
  method: "POST",
  parameters: {
    apikey: { type: "string", required: true },
    prompt: { type: "string", required: true },
    image: { type: "file", required: true }
  },
  run: async (req, res) => {
    const apikey = req.apiKeyInput || req.query?.apikey || req.body?.apikey || req.headers['x-apikey'];
    const prompt = req.body?.prompt || req.query?.prompt;
    const file = req.files && req.files.length > 0 ? req.files[0] : null;

    if (!global.apikey || !global.apikey.includes(apikey)) {
      return res.status(403).json({
        status: false,
        error: "Apikey invalid atau tidak ditemukan"
      });
    }

    if (!prompt || typeof prompt !== 'string' || !prompt.trim()) {
      return res.status(400).json({
        status: false,
        error: "Parameter teks 'prompt' wajib diisi!"
      });
    }

    if (!file || !file.path) {
      return res.status(400).json({
        status: false,
        error: "File foto 'image' wajib diunggah!"
      });
    }

    const tempFilePath = file.path;

    try {
      const generatedImageUrl = await processNanoBanana(prompt.trim(), tempFilePath);

      return res.json({
        status: true,
        result: {
          prompt: prompt.trim(),
          image_result: generatedImageUrl
        }
      });
    } catch (err) {
      return res.status(500).json({
        status: false,
        error: err.message || "Terjadi kesalahan saat memproses gambar Nano Banana"
      });
    } finally {
      if (fs.existsSync(tempFilePath)) {
        try {
          fs.unlinkSync(tempFilePath);
        } catch (_) {}
      }
    }
  }
};