const https = require('https');
const http = require('http');

const FIREBASE_API_KEY = 'AIzaSyBErm8x-SafC9cHAQevNE4GUbKo2PDfAQg';
const GENERATE_URL = 'https://europe-west1-vidio-8a128.cloudfunctions.net/generateImage';
const SYNC_URL = 'https://us-central1-vidio-8a128.cloudfunctions.net/syncDailyCoins';
const UPLOAD_URL = 'https://api.haidarxd.my.id/api/v1/tools/img-upload';
const TEMPMAIL = 'https://tempmailhaidar.vercel.app';

const STYLES = [
  'NO_STYLE', '3D_MODEL', 'ANIMAL_SPIRIT', 'ANIME', 'BARBIECORE', 'CARTOON',
  'CINEMATIC', 'COLORFUL', 'CYBERPUNK', 'DISNEY', 'FANTASY', 'GHIBLI',
  'LANDSCAPE_16_9', 'LANDSCAPE_4_3', 'LEGO_HOGWARTS', 'MANGA', 'NEONPUNK',
  'OIL_PAINTING', 'PHOTOGRAPHIC', 'PIXELS', 'PIXEL_ART', 'PORTRAIT_9_16', 'REALISM'
];

function httpReq(url, opts = {}) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const mod = u.protocol === 'https:' ? https : http;
    const req = mod.request(url, { 
      method: opts.method || 'GET', 
      headers: opts.headers || {}, 
      timeout: 120000 
    }, res => {
      let data = '';
      res.on('data', d => data += d);
      res.on('end', () => resolve({ 
        status: res.statusCode, 
        text: data, 
        json: () => JSON.parse(data) 
      }));
    });
    req.on('error', reject);
    req.on('timeout', () => { 
      req.destroy(); 
      reject(new Error('Koneksi timeout ke server AI')); 
    });
    if (opts.body) req.write(opts.body);
    req.end();
  });
}

async function generateImagen(prompt, style = 'NO_STYLE') {
  const chosenStyle = STYLES.includes(style.toUpperCase()) ? style.toUpperCase() : 'NO_STYLE';

  const mailResp = await httpReq(`${TEMPMAIL}/api/create`);
  const email = mailResp.json().email;
  if (!email) throw new Error('Gagal mendapatkan email sementara');

  const password = 'Vf' + Math.random().toString(36).slice(2, 10) + '!1';
  const signupResp = await httpReq(`https://www.googleapis.com/identitytoolkit/v3/relyingparty/signupNewUser?key=${FIREBASE_API_KEY}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password, clientType: 'CLIENT_TYPE_ANDROID' })
  });

  const signup = signupResp.json();
  if (signup.error) throw new Error(signup.error.message || 'Gagal membuat sesi pengguna');

  const token = signup.idToken;
  const headers = { 
    Authorization: `Bearer ${token}`, 
    'Content-Type': 'application/json; charset=utf-8' 
  };

  await httpReq(SYNC_URL, { 
    method: 'POST', 
    headers, 
    body: JSON.stringify({ data: null }) 
  });

  const genResp = await httpReq(GENERATE_URL, {
    method: 'POST',
    headers,
    body: JSON.stringify({
      data: {
        width: 512,
        height: 512,
        style: chosenStyle,
        seed: Math.floor(Math.random() * 999999999),
        prompt: prompt.trim()
      }
    })
  });

  const genData = genResp.json();
  if (genData.error) throw new Error(genData.error.message || 'Gagal memproses gambar');
  if (!genData.result?.image) throw new Error('Gambar tidak ditemukan dalam respon');

  const imgBuf = Buffer.from(genData.result.image, 'base64');
  const filename = `img_${Date.now()}_${chosenStyle}.jpg`;

  const boundary = '----VF' + Date.now();
  const body = Buffer.concat([
    Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="${filename}"\r\nContent-Type: image/jpeg\r\n\r\n`),
    imgBuf,
    Buffer.from(`\r\n--${boundary}--\r\n`)
  ]);

  const uploadResp = await httpReq(UPLOAD_URL, {
    method: 'POST',
    headers: {
      'Content-Type': `multipart/form-data; boundary=${boundary}`,
      'Content-Length': body.length
    },
    body
  });

  const uploadData = uploadResp.json();
  const publicUrl = uploadData?.data?.url || uploadData?.url || null;

  return {
    prompt: prompt.trim(),
    style: chosenStyle,
    image_url: publicUrl,
    size_kb: Math.round(imgBuf.length / 1024)
  };
}

module.exports = {
  name: "Imagen AI",
  category: "AI",
  desc: "Generate high-quality AI artwork and illustrations with 23 unique artistic styles",
  path: "/api/ai/imagenai",
  method: "GET",
  parameters: {
    apikey: { 
      type: "string", 
      required: true 
    },
    prompt: { 
      type: "string", 
      required: true 
    },
    style: {
      type: "select",
      required: false,
      value: "NO_STYLE",
      selection: STYLES
    }
  },
  run: async (req, res) => {
    const apiKey = req.apiKeyInput || req.query.apikey || req.body?.apikey;
    if (!apiKey || !global.apikey.includes(apiKey)) {
      return res.status(403).json({ 
        status: false, 
        message: "Apikey invalid atau tidak ditemukan" 
      });
    }

    const prompt = req.query?.prompt || req.body?.prompt;
    const style = req.query?.style || req.body?.style || "NO_STYLE";

    if (!prompt || !prompt.trim()) {
      return res.status(400).json({ 
        status: false, 
        message: "Parameter 'prompt' wajib diisi!" 
      });
    }

    try {
      const result = await generateImagen(prompt, style);
      return res.status(200).json({
        status: true,
        result: result
      });
    } catch (err) {
      return res.status(500).json({
        status: false,
        error: err.message || "Gagal mengenerate gambar dari Imagen AI"
      });
    }
  }
};
