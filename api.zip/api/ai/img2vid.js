const axios = require('axios');
const FormData = require('form-data');
const { HttpsProxyAgent } = require('https-proxy-agent');

const PROXY_LIST_URL = 'https://api.ikyyxd.my.id/v2l/proxy-free/ikyy-xsample';

async function fetchProxyList() {
    try {
        const res = await axios.get(PROXY_LIST_URL, { timeout: 5000 });
        if (Array.isArray(res.data) && res.data.length > 0) {
            return res.data;
        }
        return [];
    } catch {
        return [];
    }
}

function createRandomProxyAgent(proxyList) {
    if (!proxyList || proxyList.length === 0) return null;
    
    const randomIndex = Math.floor(Math.random() * proxyList.length);
    const randomProxy = proxyList[randomIndex];
    const [host, port, username, password] = randomProxy.split(':');

    const proxyUrl = `http://${username}:${password}@${host}:${port}`;
    return new HttpsProxyAgent(proxyUrl);
}

async function getImageBuffer(input, proxyAgent) {
    if (Buffer.isBuffer(input)) return input;
    
    if (typeof input === 'string' && input.startsWith('http')) {
        const response = await axios.get(input, { 
            responseType: 'arraybuffer',
            httpsAgent: proxyAgent || undefined,
            httpAgent: proxyAgent || undefined,
            timeout: 10000
        });
        return Buffer.from(response.data, 'binary');
    }
    throw new Error('Input image harus berupa URL http/https!');
}

async function generateVideoFromImage({
    image,
    prompt,
    model = 'wan-2.2-5b-fast',
    aspectRatio = '16:9',
    pollIntervalMs = 3000,
    maxRetries = 5
}) {
    const proxyList = await fetchProxyList();

    let proxyAgent = null;
    let submitRes = null;
    let imageBuffer = null;

    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            proxyAgent = createRandomProxyAgent(proxyList);

            if (!imageBuffer) {
                imageBuffer = await getImageBuffer(image, proxyAgent);
            }

            const form = new FormData();
            form.append('model', model);
            form.append('prompt', prompt);
            form.append('aspectRatio', aspectRatio);
            form.append('image', imageBuffer, {
                filename: 'input_image.jpg',
                contentType: 'image/jpeg'
            });

            submitRes = await axios.post('https://videogeneratorai.io/api/video/generate', form, {
                httpsAgent: proxyAgent || undefined,
                httpAgent: proxyAgent || undefined,
                timeout: 15000,
                headers: {
                    ...form.getHeaders(),
                    'Origin': 'https://videogeneratorai.io',
                    'Referer': 'https://videogeneratorai.io/',
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36'
                }
            });

            if (submitRes.data?.code === 0 && submitRes.data?.data?.taskId) {
                break;
            }
        } catch (err) {
            if (attempt === maxRetries) {
                return { status: false, msg: `Gagal setelah ${maxRetries}x percobaan proxy: ${err.message}` };
            }
        }
    }

    if (!submitRes?.data?.data?.taskId) {
        return { status: false, msg: 'Gagal mendapatkan Task ID dari server AI' };
    }

    const taskId = submitRes.data.data.taskId;

    while (true) {
        try {
            const statusRes = await axios.get(`https://videogeneratorai.io/api/video/status`, {
                params: { taskId },
                httpsAgent: proxyAgent || undefined,
                httpAgent: proxyAgent || undefined,
                timeout: 15000,
                headers: {
                    'Origin': 'https://videogeneratorai.io',
                    'Referer': 'https://videogeneratorai.io/',
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36'
                }
            });

            const taskData = statusRes.data?.data;
            const currentStatus = taskData?.status;

            if (currentStatus === 'success' && taskData?.videoUrl) {
                return {
                    status: true,
                    taskId: taskData.taskId,
                    model: taskData.model,
                    videoUrl: taskData.videoUrl
                };
            }

            if (currentStatus === 'failed' || currentStatus === 'error') {
                return {
                    status: false,
                    msg: `Proses render gagal di server: ${taskData?.message || 'Unknown error'}`
                };
            }

        } catch (err) {
            proxyAgent = createRandomProxyAgent(proxyList);
        }

        await new Promise(resolve => setTimeout(resolve, pollIntervalMs));
    }
}

module.exports = [
  {
    name: "AI Image to Video",
    desc: "Generate animasi video dari gambar dan prompt teks berbasis Wan-Fast AI",
    category: "AI",
    method: "GET",
    parameters: {
      apikey: { 
        type: "string", 
        required: true 
      },
      url: { 
        type: "string", 
        required: true
      },
      prompt: { 
        type: "string", 
        required: true
      },
      aspectRatio: {
        type: "select",
        required: false,
        selection: ["16:9", "9:16", "1:1"],
        value: "16:9"
      }
    },
    path: "/api/ai/img2vid",
    async run(req, res) {
      const apikey = req.apiKeyInput || req.query.apikey || req.body?.apikey;
      const imageUrl = req.query.url || req.body?.url;
      const prompt = req.query.prompt || req.body?.prompt;
      const aspectRatio = req.query.aspectRatio || req.body?.aspectRatio || "16:9";

      if (!global.apikey.includes(apikey)) {
        return res.status(403).json({ status: false, error: "Apikey invalid" });
      }

      if (!imageUrl) {
        return res.status(400).json({ status: false, error: "Parameter 'url' gambar wajib diisi" });
      }

      if (!prompt) {
        return res.status(400).json({ status: false, error: "Parameter 'prompt' wajib diisi" });
      }

      try {
        const result = await generateVideoFromImage({
          image: imageUrl,
          prompt: prompt,
          aspectRatio: aspectRatio
        });

        if (!result.status) {
          return res.status(500).json({
            status: false,
            error: result.msg || "Gagal membuat video dari gambar"
          });
        }

        return res.json({
          status: true,
          result: {
            prompt: prompt,
            taskId: result.taskId,
            model: result.model,
            videoUrl: result.videoUrl
          }
        });

      } catch (error) {
        return res.status(500).json({
          status: false,
          error: error.message || "Terjadi kesalahan internal pada server"
        });
      }
    }
  }
];