const crypto = require('crypto');
const WebSocket = require('ws');

const FREEGEN_URL = 'https://freegen.app';
const TURNSTILE_SITEKEY = '0x4AAAAAAET28I6VoO9ZJWXk';
const BYPASS_URL = `https://api.ikyyxd.my.id/bypass/turnstile-cf-min?url=${encodeURIComponent(FREEGEN_URL)}&sitekey=${TURNSTILE_SITEKEY}`;
const SESSION_URL = 'https://prompt-signer.freegen.app/session';
const SIGNER_URL = 'https://prompt-signer.freegen.app';
const GENERATOR_URL = 'https://image-generator.freegen.app';
const WEBSOCKET_URL = 'wss://websocket-bridge.freegen.app/ws';

async function solveTurnstile() {
  const res = await fetch(BYPASS_URL);
  const json = await res.json();
  if (!json.status || !json.result?.token) throw new Error('Gagal solve turnstile');
  return json.result.token;
}

async function getSession() {
  const token = await solveTurnstile();
  const res = await fetch(SESSION_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ turnstile_token: token })
  });
  if (!res.ok) throw new Error(`session_http_${res.status}`);
  const data = await res.json();
  if (!data.session) throw new Error('session_missing');
  return data.session;
}

async function signPrompt(prompt, session) {
  const res = await fetch(SIGNER_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ prompt, session })
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `signer_http_${res.status}`);
  }
  return res.json();
}

async function requestGeneration(prompt, ts, sig, session, ratioId, imageData) {
  const body = { prompt, ts, sig, session, ratio_id: ratioId || '4:3' };
  if (imageData) body.image_data = imageData;
  const res = await fetch(GENERATOR_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(json.error || `generator_http_${res.status}`);
  return json;
}

async function createWebSocketAuth(jobId) {
  const timestamp = Math.floor(Date.now() / 1000);
  const message = jobId + timestamp;
  const hashHex = crypto.createHash('sha256').update(message).digest('hex');
  return Buffer.from(hashHex).toString('base64').substring(0, 20) + ':' + timestamp;
}

function waitForResult(jobId) {
  return new Promise(async (resolve, reject) => {
    try {
      const auth = await createWebSocketAuth(jobId);
      const ws = new WebSocket(WEBSOCKET_URL);
      const timeout = setTimeout(() => {
        ws.close();
        reject(new Error('Timeout menunggu hasil.'));
      }, 300000);

      ws.on('open', () => {
        ws.send(JSON.stringify({ type: 'subscribe', job_id: jobId, auth }));
      });

      ws.on('message', (data) => {
        const message = JSON.parse(data.toString());
        if (message.type === 'result') {
          clearTimeout(timeout);
          ws.close();
          resolve(message.image_data);
        } else if (message.type === 'error') {
          clearTimeout(timeout);
          ws.close();
          reject(new Error(message.message || 'Gagal generate.'));
        }
      });

      ws.on('error', () => {
        clearTimeout(timeout);
        reject(new Error('WebSocket error.'));
      });
    } catch (err) {
      reject(err);
    }
  });
}

async function top4top(files) {
  const formData = new FormData();
  for (let i = 0; i < 10; i++) {
    const fieldName = `file_${i}_`;
    if (files[i]) {
      formData.append(fieldName, new Blob([files[i].buffer]), files[i].filename);
    } else {
      formData.append(fieldName, '');
    }
  }
  formData.append('submitr', '[ رفع الملفات ]');
  const res = await fetch('https://top4top.io/index.php', {
    method: 'POST',
    headers: {
      'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36'
    },
    body: formData
  });
  const html = await res.text();
  const anchorRegex = /<a\s+onclick="window\.open\(this\.href,'_blank'\);return false;"\s+href="(.*?)"/gi;
  let matches = [...html.matchAll(anchorRegex)];
  let links = matches.map(m => m[1]);
  if (links.length === 0) {
    const urlRegex = /https?:\/\/[a-z0-9.]*top4top\.io\/[^\s"'<>]+\.(?:jpg|jpeg|png|gif|webp)/gi;
    const urlMatches = [...html.matchAll(urlRegex)];
    links = [...new Set(urlMatches.map(m => m[0]))];
  }
  if (links.length === 0) {
    throw new Error(`Gagal mendapatkan link. HTML snippet: ${html.slice(0, 500)}`);
  }
  return links;
}

function toBuffer(imageDataOrUrl) {
  const match = imageDataOrUrl.match(/^data:image\/(\w+);base64,(.+)$/);
  if (match) {
    const ext = match[1] === 'jpeg' ? 'jpg' : match[1];
    return { buffer: Buffer.from(match[2], 'base64'), ext };
  }
  return null;
}

async function uploadResult(imageDataOrUrl) {
  const decoded = toBuffer(imageDataOrUrl);
  let buffer, ext;
  if (decoded) {
    buffer = decoded.buffer;
    ext = decoded.ext;
  } else {
    const res = await fetch(imageDataOrUrl);
    buffer = Buffer.from(await res.arrayBuffer());
    ext = 'jpg';
  }
  const filename = `freegen_${Date.now()}.${ext}`;
  const links = await top4top([{ buffer, filename }]);
  return links[0];
}

async function generateImage(prompt, ratioId) {
  const session = await getSession();
  const { ts, sig } = await signPrompt(prompt, session);
  const result = await requestGeneration(prompt, ts, sig, session, ratioId);
  if (result.image_data_url) return result.image_data_url;
  if (result.job_id) return await waitForResult(result.job_id);
  throw new Error('Response tidak dikenali.');
}

module.exports = [
  {
    name: "Text to Image V2",
    desc: "Generate high quality images from text prompt via Freegen AI",
    category: "AI",
    method: "GET",
    parameters: {
      apikey: { type: "string", required: true },
      prompt: { type: "string", required: true },
      ratio: { type: "string", required: false }
    },
    path: "/api/ai/text2img-v2",
    async run(req, res) {
      const apikey = req.apiKeyInput || req.query.apikey || req.body?.apikey;
      const prompt = req.query.prompt || req.body?.prompt;
      const ratio = req.query.ratio || req.body?.ratio || "4:3";

      if (!global.apikey.includes(apikey)) {
        return res.status(403).json({
          status: false,
          error: "Apikey invalid"
        });
      }

      if (!prompt) {
        return res.status(400).json({
          status: false,
          error: "Parameter 'prompt' wajib diisi"
        });
      }

      try {
        const imageRaw = await generateImage(prompt, ratio);
        const uploadedUrl = await uploadResult(imageRaw);

        return res.json({
          status: true,
          result: {
            prompt: prompt,
            ratio: ratio,
            url: uploadedUrl
          }
        });
      } catch (error) {
        return res.status(500).json({
          status: false,
          error: error.message || "Terjadi kesalahan pada server AI"
        });
      }
    }
  }
];
