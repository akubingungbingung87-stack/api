const axios = require("axios");

const BASE = "https://deep-seek.ai";
const CHAT_URL = BASE + "/chat";
const UA = "Mozilla/5.0 (Linux; Android 13; SM-A536E) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36";

const MODELS = {
  "v4": "deepseek/deepseek-v4-flash",
  "r1": "deepseek/deepseek-r1",
  "v3": "deepseek/deepseek-v3.2"
};

const DEFAULT_MODEL = MODELS["v4"];

let cookieJar = "";
let csrfToken = "";

function updateCookie(setCookie) {
  if (!setCookie) return;
  const list = Array.isArray(setCookie) ? setCookie : [setCookie];
  for (const c of list) {
    const kv = c.split(";")[0].trim();
    if (!kv) continue;
    const name = kv.split("=")[0];
    const parts = cookieJar.split("; ").filter(x => x && !x.startsWith(name + "="));
    parts.push(kv);
    cookieJar = parts.join("; ");
  }
}

async function initSession() {
  const res = await axios.get(CHAT_URL, {
    timeout: 25000,
    headers: {
      "User-Agent": UA,
      "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
      "Accept-Language": "id-ID,id;q=0.9,en;q=0.8"
    },
    validateStatus: s => s < 600,
    transformResponse: [v => v]
  });

  if (res.status !== 200) throw new Error("HTTP " + res.status + " saat inisialisasi sesi");
  updateCookie(res.headers["set-cookie"]);

  const html = String(res.data);
  const m = html.match(/<meta\s+name=["']csrf-token["']\s+content=["']([^"']+)["']/i);
  if (!m) throw new Error("CSRF token tidak ditemukan");
  csrfToken = m[1];
  return { csrfToken, cookieJar };
}

function extractDelta(obj) {
  if (!obj || typeof obj !== "object") return "";
  const c = obj.choices?.[0];
  return (
    c?.delta?.content || c?.message?.content || c?.text || obj.delta || obj.content || obj.text || obj.response || ""
  );
}

async function chat(messages, model = DEFAULT_MODEL) {
  if (!csrfToken) await initSession();

  let res;
  try {
    res = await axios.post(BASE + "/api/chat", { model, messages }, {
      timeout: 180000,
      responseType: "stream",
      headers: {
        "User-Agent": UA,
        "Accept": "text/event-stream, application/json",
        "Accept-Language": "id-ID,id;q=0.9,en;q=0.8",
        "Content-Type": "application/json",
        "X-CSRF-TOKEN": csrfToken,
        "Origin": BASE,
        "Referer": CHAT_URL,
        "Cookie": cookieJar
      },
      validateStatus: s => s < 600
    });
  } catch (err) {
    csrfToken = "";
    throw err;
  }

  if (res.status === 403 || res.status === 419) {
    csrfToken = "";
    await initSession();
    return chat(messages, model);
  }

  if (res.status >= 400) {
    let body = "";
    for await (const c of res.data) body += c;
    let msg = body;
    try {
      const parsed = JSON.parse(body);
      msg = parsed.error || parsed.message || body;
      if (parsed.limit_type) msg += " (limit: " + parsed.limit_type + ")";
    } catch (_) {}
    if (res.status === 429) throw new Error("Rate limit: " + msg);
    throw new Error("HTTP " + res.status + ": " + msg);
  }

  return new Promise((resolve, reject) => {
    let buffer = "";
    let accumulated = "";

    const handleLine = line => {
      const trimmed = line.trim();
      if (!trimmed) return;
      if (trimmed.startsWith("data:")) {
        const payload = trimmed.slice(5).trim();
        if (!payload || payload === "[DONE]") return;
        try {
          const obj = JSON.parse(payload);
          const delta = extractDelta(obj);
          if (delta) accumulated += delta;
        } catch (_) {
          accumulated += payload;
        }
      } else if (trimmed.startsWith("event:") || trimmed.startsWith(":")) {
        return;
      } else {
        try {
          const obj = JSON.parse(trimmed);
          const delta = extractDelta(obj);
          if (delta) accumulated += delta;
        } catch (_) {
          accumulated += trimmed;
        }
      }
    };

    res.data.on("data", chunk => {
      buffer += chunk.toString("utf8");
      const lines = buffer.split("\n");
      buffer = lines.pop();
      for (const line of lines) handleLine(line);
    });

    res.data.on("end", () => {
      if (buffer) handleLine(buffer);
      resolve(accumulated.trim());
    });

    res.data.on("error", reject);
  });
}

function resolveModel(input) {
  if (!input) return DEFAULT_MODEL;
  const key = String(input).toLowerCase().trim();
  return MODELS[key] || DEFAULT_MODEL;
}

module.exports = {
  name: "DeepSeek AI",
  desc: "High-performance AI assistant for general chat, coding tasks, and deep reasoning powered by DeepSeek",
  category: "AI",
  path: "/api/ai/deepseek",
  method: "GET",
  parameters: {
    apikey: { type: "string", required: true },
    query: { type: "string", required: true },
    model: {
      type: "select",
      required: false,
      selection: ["v4", "r1", "v3"],
      value: "v4"
    },
    prompt: { type: "string", required: false }
  },
  async run(req, res, next) {
    try {
      const apikey = req.apiKeyInput || req.query.apikey || req.body?.apikey;
      const query = req.query.query || req.body?.query || req.query.text || req.body?.text;
      const modelInput = req.query.model || req.body?.model || "v4";
      const systemPrompt = req.query.prompt || req.body?.prompt;

      if (!global.apikey || !global.apikey.includes(apikey)) {
        return res.status(403).json({ status: false, error: "Apikey invalid" });
      }

      if (!query || !query.trim()) {
        return res.status(400).json({ status: false, error: "Parameter 'query' wajib diisi!" });
      }

      const selectedModel = resolveModel(modelInput);
      const messages = [];

      if (systemPrompt && systemPrompt.trim()) {
        messages.push({ role: "system", content: systemPrompt.trim() });
      }
      messages.push({ role: "user", content: query.trim() });

      const reply = await chat(messages, selectedModel);

      return res.json({
        status: true,
        model: selectedModel,
        result: reply
      });
    } catch (err) {
      return res.status(500).json({
        status: false,
        error: err.message || "Terjadi kesalahan saat memproses DeepSeek AI"
      });
    }
  }
};