const axios = require('axios');

const BASE_URL = 'https://m.21cineplex.com';

const client = axios.create({
  baseURL: BASE_URL,
  timeout: 15000,
  headers: {
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
    'Accept': 'application/json, text/html, */*',
    'Referer': 'https://m.21cineplex.com/',
    'Content-Type': 'application/json'
  }
});

async function cities(defaultCityId = 10) {
  const res = await client.post('/api/theater?type=getCityList', { city_id: defaultCityId });
  if (res.data?.data?.is_success) {
    return res.data.data.value || [];
  }
  throw new Error('Gagal mengambil daftar kota');
}

async function nowPlaying(cityId = 10) {
  const res = await client.get(`/api/movies?type=now-playing&city_id=${cityId}`);
  if (res.data?.data?.is_success) {
    return (res.data.data.value?.content || []).map(m => ({
      id: m.parent_movie_id || m.movie_id,
      title: m.title,
      rating: m.rating,
      age_limit: m.age_limit,
      duration: m.duration,
      genre: m.genre,
      director: m.director,
      writer: m.writer,
      producer: m.producer,
      actors: m.player,
      poster: m.movie_image,
      trailer: m.trailer,
      is_now_playing: m.is_now_playing,
      synopsis: m.synopsis
    }));
  }
  throw new Error('Gagal mengambil film yang sedang tayang');
}

async function upcoming() {
  const res = await client.get('/api/movies?type=upcoming');
  if (res.data?.data?.is_success) {
    return (res.data.data.value?.content || []).map(m => ({
      id: m.parent_movie_id || m.movie_id,
      title: m.title,
      rating: m.rating,
      age_limit: m.age_limit,
      duration: m.duration,
      genre: m.genre,
      director: m.director,
      writer: m.writer,
      producer: m.producer,
      actors: m.player,
      poster: m.movie_image,
      trailer: m.trailer,
      synopsis: m.synopsis
    }));
  }
  throw new Error('Gagal mengambil film yang akan datang');
}

async function detail(movieId) {
  const res = await client.get(`/api/movies?type=getDetail&id=${movieId}`);
  if (res.data?.data?.is_success) {
    const d = res.data.data.value?.content;
    return {
      id: d.movie_id || d.parent_movie_id || d.master_id,
      title: d.title,
      short_title: d.short_title,
      duration: d.duration,
      genre: d.genre,
      rating: d.rating,
      age_limit: d.age_limit,
      movie_type: d.movie_type,
      director: d.director,
      writer: d.writer,
      producer: d.producer,
      actors: d.player,
      poster: d.movie_image,
      trailer: d.movie_trailer,
      synopsis: d.description,
      is_dolby: d.is_dolby,
      published_date: d.published_date,
      sales_date: d.sales_date
    };
  }
  throw new Error('Film tidak ditemukan');
}

async function search(query, cityId = 10) {
  const [npData, upData] = await Promise.all([nowPlaying(cityId), upcoming()]);
  const all = [...npData, ...upData];
  const unique = Array.from(new Map(all.map(m => [m.id, m])).values());

  const q = query.toLowerCase().trim();
  return unique.filter(m => {
    const title = (m.title || '').toLowerCase();
    const genre = (m.genre || '').toLowerCase();
    const actors = (m.actors || '').toLowerCase();
    const director = (m.director || '').toLowerCase();
    const id = (m.id || '').toLowerCase();

    return title.includes(q) || genre.includes(q) || actors.includes(q) || director.includes(q) || id.includes(q);
  });
}

module.exports = [
  {
    name: "Cinema XXI Cities",
    desc: "Get the list of cities with Cinema XXI theaters in Indonesia.",
    category: "Search",
    method: "GET",
    parameters: {
      apikey: { type: "string", required: true },
      cityId: { type: "string", required: false }
    },
    path: "/api/search/xxi-cities",
    async run(req, res) {
      const apikey = req.apiKeyInput || req.query?.apikey || req.body?.apikey;
      const cityId = parseInt(req.query?.cityId || req.body?.cityId || '10', 10);

      if (!global.apikey || !global.apikey.includes(apikey)) {
        return res.status(403).json({ status: false, error: "Apikey invalid" });
      }

      try {
        const data = await cities(cityId);
        return res.json({ status: true, total: data.length, result: data });
      } catch (err) {
        return res.status(500).json({ status: false, error: err.message || "Gagal mengambil daftar kota" });
      }
    }
  },
  {
    name: "Cinema XXI Now Playing",
    desc: "Get the list of movies currently playing in Cinema XXI theaters by city.",
    category: "Search",
    method: "GET",
    parameters: {
      apikey: { type: "string", required: true },
      cityId: { type: "string", required: false }
    },
    path: "/api/search/xxi-nowplaying",
    async run(req, res) {
      const apikey = req.apiKeyInput || req.query?.apikey || req.body?.apikey;
      const cityId = parseInt(req.query?.cityId || req.body?.cityId || '10', 10);

      if (!global.apikey || !global.apikey.includes(apikey)) {
        return res.status(403).json({ status: false, error: "Apikey invalid" });
      }

      try {
        const data = await nowPlaying(cityId);
        return res.json({ status: true, city_id: cityId, total: data.length, result: data });
      } catch (err) {
        return res.status(500).json({ status: false, error: err.message || "Gagal mengambil film yang sedang tayang" });
      }
    }
  },
  {
    name: "Cinema XXI Upcoming",
    desc: "Get the list of upcoming movies to be released in Cinema XXI theaters.",
    category: "Search",
    method: "GET",
    parameters: {
      apikey: { type: "string", required: true }
    },
    path: "/api/search/xxi-upcoming",
    async run(req, res) {
      const apikey = req.apiKeyInput || req.query?.apikey || req.body?.apikey;

      if (!global.apikey || !global.apikey.includes(apikey)) {
        return res.status(403).json({ status: false, error: "Apikey invalid" });
      }

      try {
        const data = await upcoming();
        return res.json({ status: true, total: data.length, result: data });
      } catch (err) {
        return res.status(500).json({ status: false, error: err.message || "Gagal mengambil film yang akan datang" });
      }
    }
  },
  {
    name: "Cinema XXI Detail",
    desc: "Get full details of a movie including cast, director, synopsis, poster, and trailer by movie ID.",
    category: "Search",
    method: "GET",
    parameters: {
      apikey: { type: "string", required: true },
      id: { type: "string", required: true }
    },
    path: "/api/search/xxi-detail",
    async run(req, res) {
      const apikey = req.apiKeyInput || req.query?.apikey || req.body?.apikey;
      const id = req.query?.id || req.body?.id;

      if (!global.apikey || !global.apikey.includes(apikey)) {
        return res.status(403).json({ status: false, error: "Apikey invalid" });
      }
      if (!id || !String(id).trim()) {
        return res.status(400).json({ status: false, error: "Parameter 'id' wajib diisi!" });
      }

      try {
        const data = await detail(id);
        return res.json({ status: true, result: data });
      } catch (err) {
        return res.status(500).json({ status: false, error: err.message || "Gagal mengambil detail film" });
      }
    }
  },
  {
    name: "Cinema XXI Search",
    desc: "Search for movies in Cinema XXI by title, actor, director, or genre.",
    category: "Search",
    method: "GET",
    parameters: {
      apikey: { type: "string", required: true },
      query: { type: "string", required: true },
      cityId: { type: "string", required: false }
    },
    path: "/api/search/xxi-search",
    async run(req, res) {
      const apikey = req.apiKeyInput || req.query?.apikey || req.body?.apikey;
      const query = req.query?.query || req.body?.query;
      const cityId = parseInt(req.query?.cityId || req.body?.cityId || '10', 10);

      if (!global.apikey || !global.apikey.includes(apikey)) {
        return res.status(403).json({ status: false, error: "Apikey invalid" });
      }
      if (!query || !query.trim()) {
        return res.status(400).json({ status: false, error: "Parameter 'query' wajib diisi!" });
      }

      try {
        const data = await search(query, cityId);
        return res.json({ status: true, query, total: data.length, result: data });
      } catch (err) {
        return res.status(500).json({ status: false, error: err.message || "Gagal mencari film" });
      }
    }
  }
];
