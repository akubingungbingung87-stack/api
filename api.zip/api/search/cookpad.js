const axios = require('axios');
const cheerio = require('cheerio');

const client = axios.create({
  baseURL: 'https://cookpad.com',
  timeout: 15000,
  headers: {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept-Language': 'id-ID,id;q=0.9,en;q=0.8'
  }
});

async function searchRecipes(query, page = 1) {
  const { data } = await client.get(`/id/cari/${encodeURIComponent(query)}`, {
    params: page > 1 ? { page } : undefined
  });
  const $ = cheerio.load(data);
  const results = [];

  $('#search-recipes-list > li[id^="recipe_"]').each((_, el) => {
    const $el = $(el);
    const id = ($el.attr('id') || '').replace('recipe_', '');
    if (!id) return;

    const title = $el.find('a.block-link__main').first().text().trim().replace(/\s+/g, ' ');
    if (!title) return;

    const author = $el.find('img[alt][title]').last().attr('alt')
      || $el.find('span.break-all span').last().text().trim()
      || null;

    const duration = $el.find('.mise-icon-time').parent().find('.mise-icon-text').first().text().trim() || null;
    const servings = $el.find('.mise-icon-user').parent().find('.mise-icon-text').first().text().trim() || null;

    const ingredientsPreview = [];
    const ingText = $el.find('[data-ingredients-redesign-target="ingredients"] .line-clamp-2').text() || '';
    ingText.split('•').forEach(t => {
      const clean = t.trim();
      if (clean && clean.length > 1) ingredientsPreview.push(clean);
    });

    const image = $el.find('img[src*="cpcdn.com/recipes"]').attr('src') || null;

    results.push({
      id,
      title,
      author,
      duration,
      servings,
      ingredientsPreview: ingredientsPreview.slice(0, 8),
      image,
      url: `https://cookpad.com/id/resep/${id}`
    });
  });

  return results;
}

async function getRecipeDetail(idOrUrl) {
  const id = String(idOrUrl).match(/(\d+)/)?.[1] || idOrUrl;
  const { data } = await client.get(`/id/resep/${id}`);
  const $ = cheerio.load(data);
  let recipe = null;

  $('script[type="application/ld+json"]').each((_, el) => {
    try {
      const json = JSON.parse($(el).html());
      if (json['@type'] === 'Recipe') recipe = json;
    } catch (e) {}
  });

  if (!recipe) throw new Error('Resep tidak ditemukan');

  return {
    id,
    title: recipe.name,
    description: recipe.description || '',
    image: Array.isArray(recipe.image) ? recipe.image[0] : recipe.image,
    author: recipe.author?.name || '',
    authorUrl: recipe.author?.url || '',
    yield: recipe.recipeYield || '',
    cuisine: recipe.recipeCuisine || '',
    datePublished: recipe.datePublished || '',
    ingredients: (recipe.recipeIngredient || []).map(i => i.trim()).filter(Boolean),
    steps: (recipe.recipeInstructions || []).map(s => {
      let images = [];
      if (Array.isArray(s.image)) images = s.image;
      else if (s.image) images = [s.image];
      return { text: s.text || s, images };
    }),
    link: `https://cookpad.com/id/resep/${id}`
  };
}

module.exports = [
  {
    name: "Cookpad Search",
    desc: "Search for recipes on Cookpad by keyword, returning title, author, cooking duration, servings, ingredient preview, and thumbnail for each result.",
    category: "Search",
    method: "GET",
    parameters: {
      apikey: { type: "string", required: true },
      query: { type: "string", required: true },
      page: { type: "string", required: false }
    },
    path: "/api/search/cookpad",
    async run(req, res) {
      const apikey = req.apiKeyInput || req.query?.apikey || req.body?.apikey;
      const query = req.query?.query || req.body?.query;
      const page = parseInt(req.query?.page || req.body?.page || '1', 10);

      if (!global.apikey || !global.apikey.includes(apikey)) {
        return res.status(403).json({ status: false, error: "Apikey invalid" });
      }
      if (!query || !query.trim()) {
        return res.status(400).json({ status: false, error: "Parameter 'query' wajib diisi!" });
      }

      try {
        const result = await searchRecipes(query.trim(), page);
        return res.json({ status: true, total: result.length, result });
      } catch (err) {
        return res.status(500).json({ status: false, error: err.message || "Gagal mencari resep di Cookpad" });
      }
    }
  },
  {
    name: "Cookpad Recipe Detail",
    desc: "Get full recipe details from Cookpad including ingredients, step-by-step instructions with images, servings, and author info, by recipe ID or URL.",
    category: "Search",
    method: "GET",
    parameters: {
      apikey: { type: "string", required: true },
      id: { type: "string", required: true }
    },
    path: "/api/search/cookpad-detail",
    async run(req, res) {
      const apikey = req.apiKeyInput || req.query?.apikey || req.body?.apikey;
      const id = req.query?.id || req.body?.id;

      if (!global.apikey || !global.apikey.includes(apikey)) {
        return res.status(403).json({ status: false, error: "Apikey invalid" });
      }
      if (!id || !String(id).trim()) {
        return res.status(400).json({ status: false, error: "Parameter 'id' wajib diisi! (ID resep atau URL Cookpad)" });
      }

      try {
        const result = await getRecipeDetail(id.trim());
        return res.json({ status: true, result });
      } catch (err) {
        return res.status(500).json({ status: false, error: err.message || "Gagal mengambil detail resep" });
      }
    }
  }
];
