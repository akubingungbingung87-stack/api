const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const axios = require('axios');
const FormData = require('form-data');

const AUDD_TOKEN = 'ee4483428d62e7ec5804ab47cb896496';

async function identifyAudio(buffer, filename) {
  const form = new FormData();
  form.append('file', buffer, filename);
  form.append('api_token', AUDD_TOKEN);
  form.append('return', 'spotify,apple_music');

  const res = await axios.post('https://api.audd.io/', form, {
    headers: form.getHeaders(),
    timeout: 30000
  });

  const data = res.data;
  if (data.status !== 'success') {
    throw new Error(data.error?.error_message || 'Gagal mendeteksi audio');
  }

  return data.result || null;
}

module.exports = [
  {
    name: "Song Finder",
    desc: "Identify a song's title, artist, album, and release date from an audio or video sample using AudD music recognition.",
    category: "Search",
    method: "POST",
    parameters: {
      apikey: {
        type: "string",
        required: true
      },
      file: {
        type: "file",
        required: true
      }
    },
    path: "/api/search/songfinder",
    async run(req, res) {
      const apikey = req.apiKeyInput || req.query?.apikey || req.body?.apikey;
      const uploadedFile = req.files && req.files.length > 0 ? req.files[0] : null;

      if (!global.apikey.includes(apikey)) {
        return res.status(403).json({ status: false, error: "Apikey invalid" });
      }

      if (!uploadedFile || !uploadedFile.path) {
        return res.status(400).json({ status: false, error: "Wajib mengunggah file audio/video (form-data: file)" });
      }

      const tempPath = uploadedFile.path;

      try {
        const buffer = fs.readFileSync(tempPath);
        const filename = uploadedFile.originalname || path.basename(tempPath);
        const track = await identifyAudio(buffer, filename);

        if (tempPath && fs.existsSync(tempPath)) {
          try { await fsp.unlink(tempPath); } catch (e) {}
        }

        if (!track) {
          return res.status(404).json({ status: false, error: "Lagu tidak ditemukan / tidak terdeteksi" });
        }

        return res.json({
          status: true,
          result: {
            title: track.title || null,
            artist: track.artist || null,
            album: track.album || null,
            release_date: track.release_date || null,
            spotify_url: track.spotify?.external_urls?.spotify || null,
            apple_music_url: track.apple_music?.url || null
          }
        });

      } catch (err) {
        if (tempPath && fs.existsSync(tempPath)) {
          try { await fsp.unlink(tempPath); } catch (e) {}
        }
        const code = err.response?.status || 500;
        return res.status(code).json({
          status: false,
          error: err.message || "Gagal mendeteksi audio"
        });
      }
    }
  }
];
