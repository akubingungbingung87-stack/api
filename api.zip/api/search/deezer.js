const axios = require('axios');

const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36';

async function searchDeezer(query, limit = 10) {
  if (!query) throw new Error('Parameter query pencarian diperlukan.');
  const res = await axios.get('https://api.deezer.com/search', {
    params: { q: query, limit },
    headers: { 'User-Agent': USER_AGENT },
    timeout: 15000
  });

  const data = res.data;
  return (data.data || []).map((t) => ({
    id: t.id,
    title: t.title,
    artist: t.artist?.name || '',
    album: t.album?.title || '',
    duration: t.duration,
    link: t.link,
    thumbnail: t.album?.cover_big || t.album?.cover || ''
  }));
}

module.exports = {
  name: "Deezer Search",
  category: "Search",
  desc: "Cari daftar lagu, nama musisi/artis, album, dan link track resmi dari Deezer.",
  path: "/api/search/deezer",
  method: "GET",
  parameters: {
    apikey: {
      type: "string",
      required: true
    },
    query: {
      type: "string",
      required: true
    }
  },
  run: async (req, res) => {
    const apiKey = req.apiKeyInput || req.query.apikey || req.body?.apikey;
    const query = req.query?.query || req.body?.query;

    if (!apiKey || !global.apikey || !global.apikey.includes(apiKey)) {
      return res.status(403).json({
        status: false,
        message: "Apikey invalid atau tidak ditemukan"
      });
    }

    if (!query || !query.trim()) {
      return res.status(400).json({
        status: false,
        message: "Parameter 'query' wajib diisi!"
      });
    }

    try {
      const results = await searchDeezer(query.trim());
      return res.status(200).json({
        status: true,
        result: results
      });
    } catch (err) {
      return res.status(500).json({
        status: false,
        error: err.message || "Gagal melakukan pencarian lagu di Deezer"
      });
    }
  }
};