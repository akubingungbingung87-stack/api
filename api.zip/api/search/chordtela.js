const axios = require('axios');
const cheerio = require('cheerio');

const BASE_URL = 'https://www.chordtela.com';

const DEFAULT_HEADERS = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
  'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7'
};

async function fetchPage(targetUrl, timeout = 15000) {
  try {
    const res = await axios.get(targetUrl, {
      headers: DEFAULT_HEADERS,
      timeout: timeout
    });
    if (res.data && typeof res.data === 'string' && !res.data.includes('Attention Required! | Cloudflare')) {
      return res.data;
    }
    throw new Error('Cloudflare challenge detected');
  } catch (err) {
    const fallbackUrl = `https://r.jina.ai/${targetUrl}`;
    const res = await axios.get(fallbackUrl, {
      headers: {
        'X-Return-Format': 'html'
      },
      timeout: timeout + 5000
    });
    return res.data;
  }
}

function getSectionForChar(char) {
  const c = (char || '').toLowerCase();
  if (/[ab]/.test(c)) return 'a-b';
  if (/[cd]/.test(c)) return 'c-d';
  if (/[ef]/.test(c)) return 'e-f';
  if (/[gh]/.test(c)) return 'g-h';
  if (/[ij]/.test(c)) return 'i-j';
  if (/[kl]/.test(c)) return 'k-l';
  if (/[mn]/.test(c)) return 'm-n';
  if (/[op]/.test(c)) return 'o-p';
  if (/[qr]/.test(c)) return 'q-r';
  if (/[st]/.test(c)) return 's-t';
  if (/[uv]/.test(c)) return 'u-v';
  if (/[wx]/.test(c)) return 'w-x';
  if (/[yz]/.test(c)) return 'y-z';
  return '0-9';
}

async function findSongUrl(songQuery) {
  const q = songQuery.trim();
  if (q.startsWith('http')) return q;

  const words = q.split(/\s+/);
  const candidateArtists = [];
  let trackTitle = q;

  try {
    const itunesRes = await axios.get(
      `https://itunes.apple.com/search?term=${encodeURIComponent(q)}&entity=song&limit=10`,
      { timeout: 5000 }
    );
    if (itunesRes.data && itunesRes.data.results && Array.isArray(itunesRes.data.results)) {
      for (const item of itunesRes.data.results) {
        if (item.artistName && !candidateArtists.includes(item.artistName)) {
          candidateArtists.push(item.artistName);
        }
        if (item.trackName && trackTitle === q) {
          trackTitle = item.trackName;
        }
      }
    }
  } catch (_) {}

  if (!candidateArtists.includes(q)) candidateArtists.push(q);
  if (words.length > 1) {
    candidateArtists.push(words.slice(0, 2).join(' '));
    candidateArtists.push(words[0]);
  }

  for (const artistName of candidateArtists) {
    if (!artistName || artistName.length < 2) continue;
    const firstChar = artistName.trim().charAt(0);
    const section = getSectionForChar(firstChar);

    try {
      const dirHtml = await fetchPage(`${BASE_URL}/chord-gitar-${section}`);
      const $dir = cheerio.load(dirHtml);

      const aLower = artistName.toLowerCase();
      let artistPageUrl = '';

      $dir('a[href*="/chord/"], a[href*="/kumpulan-chord/"]').each((_, el) => {
        const text = $dir(el).text().trim().toLowerCase();
        const href = $dir(el).attr('href');
        if (!href) return;
        if (text === aLower || text.includes(aLower) || aLower.includes(text)) {
          artistPageUrl = href;
          return false;
        }
      });

      if (artistPageUrl) {
        const artistHtml = await fetchPage(artistPageUrl);
        const $artist = cheerio.load(artistHtml);

        let bestSongUrl = null;
        let bestScore = 0;
        const songKeywords = words.filter(w => !aLower.includes(w.toLowerCase()) && w.length >= 2);

        $artist('a[href*=".html"]').each((_, el) => {
          const songText = $artist(el).text().trim().toLowerCase();
          const href = $artist(el).attr('href');
          if (!href || !href.match(/\/\d{4}\/\d{2}\//)) return;

          let score = 0;
          if (trackTitle && songText.includes(trackTitle.toLowerCase())) {
            score += 50;
          }
          if (songText.includes(q.toLowerCase())) {
            score += 40;
          }
          for (const kw of songKeywords) {
            if (songText.includes(kw.toLowerCase())) {
              score += 20;
            }
          }
          if (songKeywords.length === 0 && score === 0) {
            score = 1;
          }

          if (score > bestScore) {
            bestScore = score;
            bestSongUrl = href;
          }
        });

        if (bestSongUrl && bestScore > 0) {
          return bestSongUrl;
        }
      }
    } catch (_) {}
  }

  return null;
}

async function getChord(songUrl) {
  if (!songUrl || typeof songUrl !== 'string') {
    throw new Error('Parameter songUrl harus berupa string URL yang valid.');
  }

  const cleanUrl = songUrl.trim();
  const html = await fetchPage(cleanUrl);
  const $ = cheerio.load(html);

  const rawTitle = $('h1.entry-title, h1.post-title, h1').first().text().trim();
  const cleanTitle = rawTitle
    .replace(/©?ChordTela\.com/gi, '')
    .replace(/Kunci Gitar/gi, '')
    .replace(/Chord Dasar/gi, '')
    .trim();

  let artist = $('.breadcrumb-item a').eq(1).text().trim();
  if (!artist || artist.toLowerCase() === 'home') {
    const parts = cleanTitle.split('-');
    artist = parts.length > 1 ? parts[0].trim() : '';
  }

  const pre = $('div.telabox pre, .entry-content pre').first();
  if (!pre.length) {
    throw new Error('Struktur chord (<pre>) tidak ditemukan pada halaman ini.');
  }

  pre.find('script, style, iframe').remove();

  let capo = null;
  pre.find('b, span').each((_, el) => {
    const t = $(el).text().trim();
    if (/capo/i.test(t)) {
      capo = t;
    }
  });

  const chordsSet = new Set();
  pre.find('a.tbi-tooltip').each((_, el) => {
    const chordName = $(el).clone().children().remove().end().text().trim();
    if (chordName) chordsSet.add(chordName);
  });

  const preChord = pre.clone();
  preChord.find('a.tbi-tooltip span').remove();
  let fullChordText = preChord.text().trim();
  fullChordText = fullChordText.replace(/<iframe[\s\S]*?<\/iframe>/gi, '').trim();

  let easyChord = fullChordText;
  let originalChord = null;
  const splitRegex = /(?:[-=\s]*===ORIGINAL CHORD===*[-=\s]*|[-=\s]*\|\|\s*sebelum di sederhanakan[\s\S]*?\|\|[-=\s]*)/i;
  if (splitRegex.test(fullChordText)) {
    const parts = fullChordText.split(splitRegex);
    easyChord = parts[0].trim();
    originalChord = parts[1] ? parts[1].trim() : null;
  }

  if (easyChord.toLowerCase().startsWith(cleanTitle.toLowerCase())) {
    easyChord = easyChord.slice(cleanTitle.length).trim();
  }
  if (originalChord && originalChord.toLowerCase().startsWith(cleanTitle.toLowerCase())) {
    originalChord = originalChord.slice(cleanTitle.length).trim();
  }

  const lyricsLines = easyChord.split('\n')
    .map(line => {
      const trimmed = line.trim();
      if (/capo/i.test(trimmed)) return '';
      if (/<iframe/i.test(trimmed) || /youtube\.com/i.test(trimmed)) return '';
      if (/^[-=|_~]{2,}/.test(trimmed)) return '';
      if (/^(intro|outro|interlude|solo|bridge|musik)\s*[:.]/i.test(trimmed)) return '';

      const chordTokens = trimmed.split(/\s+/);
      const isAllChords = chordTokens.length > 0 && chordTokens.every(token => {
        const cleanToken = token.replace(/[-.:~[\]()0-9x\/]/gi, '');
        return cleanToken === '' || chordsSet.has(cleanToken);
      });
      if (isAllChords) return '';
      return trimmed;
    })
    .filter(line => line.length > 0);

  const cleanLyrics = lyricsLines.join('\n').replace(/\n{3,}/g, '\n\n').trim();

  return {
    title: cleanTitle,
    artist: artist || null,
    url: cleanUrl,
    capo: capo,
    chords_used: Array.from(chordsSet),
    chord: easyChord,
    original_chord: originalChord,
    lyrics: cleanLyrics
  };
}

async function getChordBySong(songNameOrUrl) {
  if (!songNameOrUrl || typeof songNameOrUrl !== 'string') {
    throw new Error('Nama lagu atau URL wajib diisi.');
  }

  const query = songNameOrUrl.trim();
  if (query.startsWith('http')) {
    return await getChord(query);
  }

  const foundUrl = await findSongUrl(query);
  if (!foundUrl) {
    throw new Error(`Lagu "${query}" tidak ditemukan di Chordtela.`);
  }

  return await getChord(foundUrl);
}

module.exports = {
  name: "ChordTela Search",
  category: "Search",
  desc: "Search guitar chords and song lyrics from ChordTela",
  path: "/api/search/chordtela",
  method: "GET",
  parameters: {
    apikey: { type: "string", required: true },
    q: { type: "string", required: true }
  },
  run: async (req, res) => {
    const apiKey = req.apiKeyInput || req.query.apikey || req.body?.apikey;
    if (!apiKey || !global.apikey.includes(apiKey)) {
      return res.status(403).json({ status: false, message: "Apikey invalid atau tidak ditemukan" });
    }

    const query = req.query?.q || req.body?.q;

    if (!query || !query.trim()) {
      return res.status(400).json({
        status: false,
        message: "Parameter 'q' wajib diisi!"
      });
    }

    try {
      const data = await getChordBySong(query);
      return res.status(200).json({
        status: true,
        result: data
      });
    } catch (err) {
      return res.status(500).json({
        status: false,
        error: err.message || "Gagal mengambil chord lagu"
      });
    }
  }
};
