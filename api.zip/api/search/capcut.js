const axios = require('axios');

const PROXY_API = 'https://api.ikyyxd.my.id/v2l/proxy-free/ikyy-xsample';
const BASE_URL = 'https://www.capcut.com';
const API_ENDPOINT = '/kep/api/getSimilarTemplates';

let proxies = [];

async function fetchProxies() {
  try {
    const res = await axios.get(PROXY_API, { timeout: 10000 });
    if (!Array.isArray(res.data)) throw new Error('Format proxy tidak valid');
    proxies = res.data.filter(p => typeof p === 'string' && p.trim().split(':').length === 4);
    if (proxies.length === 0) throw new Error('Tidak ada proxy yang valid ditemukan');
    return proxies;
  } catch (err) {
    throw new Error(`Gagal memuat proxy: ${err.message}`);
  }
}

function getRandomProxyConfig() {
  const p = proxies[Math.floor(Math.random() * proxies.length)];
  const [host, port, user, pass] = p.trim().split(':');
  return {
    str: p,
    ip: host,
    config: {
      host,
      port: parseInt(port),
      auth: { username: user, password: pass },
      protocol: 'http'
    }
  };
}

async function searchTemplates(keyword, size = 10, language = 'en', regionCode = 'US', proxyData) {
  const client = axios.create({
    baseURL: BASE_URL,
    proxy: proxyData.config,
    timeout: 20000,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
      'Accept': '*/*',
      'Content-Type': 'application/json',
      'Origin': BASE_URL,
      'Referer': `${BASE_URL}/template`,
      'Sec-Fetch-Dest': 'empty',
      'Sec-Fetch-Mode': 'cors',
      'Sec-Fetch-Site': 'same-origin'
    }
  });

  const payload = {
    keyword: keyword,
    tabs: ["video"],
    language: language,
    regionCode: regionCode,
    size: size
  };

  const res = await client.post(API_ENDPOINT, payload);

  if (res.data.status !== 1000 || !res.data.data?.videoTemplateList) {
    throw new Error(`API CapCut Error: ${JSON.stringify(res.data)}`);
  }

  const templates = res.data.data.videoTemplateList.videoTemplates || [];

  return templates.map(t => ({
    template_id: t.templateId,
    title: t.title,
    description: t.titleDesc,
    use_count: t.useCount,
    like_count: t.likeCount,
    comment_count: t.commentCount,
    duration: t.templateDuration,
    cover_url: t.coverUrl,
    video_url: t.videoUrl,
    structured_data: t.structuredData || null
  }));
}

module.exports = {
  name: "Capcut Search",
  desc: "Search and discover trending CapCut video templates by keyword",
  category: "Search",
  path: "/api/search/capcut",
  method: "GET",
  parameters: {
    apikey: { type: "string", required: true },
    query: { type: "string", required: true },
    size: { type: "number", required: false, value: 10 }
  },
  async run(req, res, next) {
    try {
      const apikey = req.apiKeyInput || req.query.apikey || req.body?.apikey;
      const query = req.query.query || req.body?.query;
      const size = parseInt(req.query.size || req.body?.size) || 10;

      if (!global.apikey || !global.apikey.includes(apikey)) {
        return res.status(403).json({ status: false, error: "Apikey invalid" });
      }

      if (!query) {
        return res.status(400).json({ status: false, error: "Parameter 'query' wajib diisi!" });
      }

      if (!proxies.length) {
        await fetchProxies();
      }

      let success = false;
      let lastError = '';
      let results = [];

      for (let i = 0; i < 5; i++) {
        let proxyData;
        try {
          proxyData = getRandomProxyConfig();
        } catch {
          continue;
        }

        try {
          results = await searchTemplates(query, size, 'en', 'US', proxyData);
          success = true;
          break;
        } catch (err) {
          lastError = err.message;
        }
      }

      if (success) {
        return res.json({
          status: true,
          result: {
            query: query,
            total: results.length,
            data: results
          }
        });
      } else {
        return res.status(502).json({
          status: false,
          error: `Gagal mengambil data dari CapCut: ${lastError}`
        });
      }
    } catch (err) {
      const errorMsg = err.message || "Terjadi kesalahan pada server";
      return res.status(500).json({
        status: false,
        error: errorMsg
      });
    }
  }
};
