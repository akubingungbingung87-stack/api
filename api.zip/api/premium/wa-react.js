const BASE_URL = 'https://reaction-whatsapp.edgeone.dev';

async function sendReaction(userToken, emoji, link) {
  const res = await fetch(`${BASE_URL}/react`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      Authorization: `Bearer ${userToken}`
    },
    body: JSON.stringify({
      emoji: emoji || "✅",
      link: link
    })
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return await res.json();
}

module.exports = {
  name: "WhatsApp Channel React",
  category: "Premium",
  desc: "Send automated emoji reactions to WhatsApp channels via token authorization",
  path: "/api/premium/whatsapp-react",
  method: "GET",
  parameters: {
    apikey: { type: "string", required: true },
    link: { type: "string", required: true },
    emoji: { type: "string", required: false },
    token: { type: "string", required: true }
  },
  run: async (req, res) => {
    const apiKey = req.apiKeyInput || req.query.apikey || req.body?.apikey;
    if (!apiKey || !global.apikey.includes(apiKey)) {
      return res.status(403).json({ status: false, message: "Apikey invalid atau tidak ditemukan" });
    }

    const link = req.query?.link || req.body?.link;
    const emoji = req.query?.emoji || req.body?.emoji || "✅";
    const token = req.query?.token || req.body?.token;

    if (!token || !token.trim()) {
      return res.status(400).json({ status: false, message: "Parameter 'token' wajib diisi!" });
    }
    if (!link || !link.trim()) {
      return res.status(400).json({ status: false, message: "Parameter 'link' wajib diisi!" });
    }

    try {
      const result = await sendReaction(token.trim(), emoji.trim(), link.trim());
      return res.status(200).json({ status: true, result });
    } catch (err) {
      return res.status(500).json({ status: false, error: err.message || "Gagal memproses reaksi WhatsApp" });
    }
  }
};