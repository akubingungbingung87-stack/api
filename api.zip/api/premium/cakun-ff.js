const crypto = require('crypto');

const app_id = 100067;
const secret = '2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3';
const host = 'https://100067.connect.garena.com';
const ua = 'GarenaMSDK/4.0.42(NEO G12 ;Android 17;in;ID;app 1.130.1 2019121040;)';

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

const post = async (path, body, headers = {}) => {
  const res = await fetch(`${host}${path}`, {
    method: 'POST',
    headers: { 'User-Agent': ua, 'Content-Type': 'application/json; charset=utf-8', ...headers },
    body: JSON.stringify(body)
  });
  const text = await res.text();
  if (text.startsWith('<')) throw new Error('Rate limit Garena. Cooling down...');
  return JSON.parse(text);
};

async function createGuest() {
  const password = crypto.randomBytes(32).toString('hex').toUpperCase();
  const regBody = { app_id, client_type: 2, password, source: 2 };
  const sig = crypto.createHmac('sha256', secret).update(JSON.stringify(regBody)).digest('hex');

  const reg = await post('/api/v2/oauth/guest:register', regBody, { Authorization: `Signature ${sig}` });
  if (reg.code !== 0 || !reg.data?.uid) throw new Error(reg.error || 'Register failed');

  const uid = reg.data.uid;
  const grant = await post('/api/v2/oauth/guest/token:grant', {
    client_id: app_id,
    client_secret: secret,
    client_type: 2,
    password,
    response_type: 'token',
    uid
  });
  if (grant.code !== 0 || !grant.data?.access_token) throw new Error(grant.error || 'Grant failed');

  return { uid, password, open_id: grant.data.open_id, access_token: grant.data.access_token };
}

module.exports = {
  name: "Free Fire Guest Account",
  category: "Premium",
  desc: "Generate Free Fire guest accounts with bulk creation support",
  path: "/api/premium/freefire",
  method: "GET",
  parameters: {
    apikey: { type: "string", required: true },
    count: { type: "string", required: false }
  },
  run: async (req, res) => {
    const apiKey = req.apiKeyInput || req.query.apikey || req.body?.apikey;
    if (!apiKey || !global.apikey.includes(apiKey)) {
      return res.status(403).json({ status: false, message: "Apikey invalid atau tidak ditemukan" });
    }

    const countInput = req.query?.count || req.body?.count || 1;
    const count = Math.min(Math.max(parseInt(countInput, 10) || 1, 1), 10);

    const accounts = [];
    try {
      for (let i = 0; i < count; i++) {
        const acc = await createGuest();
        accounts.push(acc);
        if (i < count - 1) {
          await sleep(1000);
        }
      }

      return res.status(200).json({
        status: true,
        total: accounts.length,
        result: count === 1 ? accounts[0] : accounts
      });
    } catch (err) {
      if (accounts.length > 0) {
        return res.status(200).json({
          status: true,
          total: accounts.length,
          partial: true,
          result: count === 1 ? accounts[0] : accounts,
          warning: err.message
        });
      }

      return res.status(500).json({
        status: false,
        error: err.message || "Gagal membuat akun guest Free Fire"
      });
    }
  }
};