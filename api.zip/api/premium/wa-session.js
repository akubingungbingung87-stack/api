const BASE_URL = 'https://reaction-whatsapp.edgeone.dev';

async function connectSession(method, number) {
  if (method === "qr") {
    const res = await fetch(`${BASE_URL}/qr`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" }
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  }

  if (method === "pair") {
    const cleanNumber = String(number || '').replace(/[^0-9]/g, '');
    const res = await fetch(`${BASE_URL}/pair`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({ phoneNumber: cleanNumber })
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  }

  throw new Error("Method tidak valid. Pilih antara: 'pair' atau 'qr'.");
}

module.exports = {
  name: "WhatsApp Session Connect",
  category: "Premium",
  desc: "Generate QR code or pairing code for WhatsApp session authentication",
  path: "/api/premium/whatsapp-session",
  method: "GET",
  parameters: {
    apikey: { type: "string", required: true },
    method: {
      type: "select",
      required: true,
      selection: ["pair", "qr"],
      value: "pair"
    },
    phone: { 
      type: "string", 
      required: false
    }
  },
  run: async (req, res) => {
    const apiKey = req.apiKeyInput || req.query.apikey || req.body?.apikey;
    if (!apiKey || !global.apikey.includes(apiKey)) {
      return res.status(403).json({ status: false, message: "Apikey invalid atau tidak ditemukan" });
    }

    const method = (req.query?.method || req.body?.method || "pair").toLowerCase();
    const phone = req.query?.phone || req.body?.phone;

    try {
      if (method === "qr") {
        const result = await connectSession("qr");
        return res.status(200).json({ status: true, method: "qr", result });
      }

      if (method === "pair") {
        if (!phone || !phone.trim()) {
          return res.status(400).json({ status: false, message: "Parameter 'phone' wajib diisi untuk pairing code!" });
        }
        const result = await connectSession("pair", phone);
        return res.status(200).json({ status: true, method: "pair", result });
      }

      return res.status(400).json({ status: false, message: "Method tidak dikenali. Gunakan 'pair' atau 'qr'." });
    } catch (err) {
      return res.status(500).json({ status: false, error: err.message || "Gagal memproses sesi WhatsApp" });
    }
  }
};
