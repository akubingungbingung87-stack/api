const axios = require('axios');

module.exports = [
  {
    name: "React Channel WhatsApp",
    desc: "Send emoji reactions to specific WhatsApp channel posts",
    category: "Premium",
    method: "GET",
    parameters: {
      apikey: { type: "string", required: true },
      url: { type: "string", required: true },
      reaction: { type: "string", required: true }
    },
    path: "/api/premium/reactchl",
    async run(req, res) {
      const apikey = req.apiKeyInput || req.query.apikey || req.body?.apikey;
      const targetUrl = req.query.url || req.body?.url;
      const reaction = req.query.reaction || req.body?.reaction;

      if (!global.apikey.includes(apikey)) {
        return res.status(403).json({ 
          status: false, 
          error: "Apikey invalid" 
        });
      }

      if (!targetUrl) {
        return res.status(400).json({ 
          status: false, 
          error: "Parameter 'url' wajib diisi! Gunakan link pesan channel (contoh: https://whatsapp.com/channel/xxx/5)" 
        });
      }

      if (!reaction) {
        return res.status(400).json({ 
          status: false, 
          error: "Parameter 'reaction' wajib diisi! Berisi emoji pisahkan dengan koma (maksimal 4 emoji)." 
        });
      }

      try {
        const targetApi = `https://apiii-xrina.vercel.app/tools/rch?url=${encodeURIComponent(targetUrl)}&reaction=${encodeURIComponent(reaction)}&apikey=Rin-rch`;

        const response = await axios.get(targetApi, {
          timeout: 15000,
          headers: {
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36'
          }
        });

        const { creator, ...cleanData } = response.data || {};

        if (response.data?.status === false) {
          return res.status(400).json({
            status: false,
            message: response.data.message || "Gagal memproses reaksi channel",
            missing: response.data.missing || undefined
          });
        }

        return res.json({
          status: true,
          result: cleanData
        });

      } catch (error) {
        return res.status(500).json({
          status: false,
          error: error.response?.data?.message || error.message || "Terjadi kesalahan pada server provider"
        });
      }
    }
  }
];