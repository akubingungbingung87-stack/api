const axios = require('axios');

const API_URL = 'https://nftoken.zone.id/api/auto-generate';

async function fetchNetflixToken() {
  const response = await axios.post(API_URL, {}, {
    headers: {
      'Content-Type': 'application/json',
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      'Accept': 'application/json'
    },
    timeout: 20000
  });

  if (!response.data?.success || !response.data?.token) {
    throw new Error('Gagal mendapatkan respon token dari server Netflix');
  }

  return {
    token: response.data.token,
    expiry: response.data.expiry,
    profile: response.data.profile,
    links: response.data.links,
    type: response.data.type
  };
}

module.exports = {
  name: "Netflix Token Generator",
  category: "Premium",
  desc: "Generate random Netflix premium login token",
  path: "/api/premium/nftoken",
  method: "GET",
  parameters: {
    apikey: { type: "string", required: true }
  },
  run: async (req, res) => {
    const apiKey = req.apiKeyInput || req.query.apikey || req.body?.apikey;
    if (!apiKey || !global.apikey.includes(apiKey)) {
      return res.status(403).json({ status: false, message: "Apikey invalid atau tidak ditemukan" });
    }

    try {
      const result = await fetchNetflixToken();
      return res.status(200).json({
        status: true,
        result: result
      });
    } catch (err) {
      return res.status(500).json({
        status: false,
        error: err.message || "Gagal mengenerate token Netflix"
      });
    }
  }
};