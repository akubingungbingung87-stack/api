const axios = require('axios');
const crypto = require('crypto');
const CryptoJS = require('crypto-js');
const os = require('os');
const path = require('path');
const fsp = require('fs/promises');
const fs = require('fs');
const FormData = require('form-data');

const PUBLIC_KEY = `-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCwlO+boC6cwRo3UfXVBadaYwcX
0zKS2fuVNY2qZ0dgwb1NJ+/Q9FeAosL4ONiosD71on3PVYqRUlL5045mvH2K9i8b
AFVMEip7E6RMK6tKAAif7xzZrXnP1GZ5Rijtqdgwh+YmzTo39cuBCsZqK9oEoeQ3
r/myG9S+9cR5huTuFQIDAQAB
-----END PUBLIC KEY-----`;

const APP_ID = "aifaceswap";
const U_ID = "1H5tRtzsBkqXcaJ";
const FN_NAME = "cloth-change";
const BRAND_KEY = "8f3f0c7387123ae0";

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function generateRandomString(len) {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let res = "";
  for (let i = 0; i < len; i++) res += chars.charAt(Math.floor(Math.random() * chars.length));
  return res;
}

function aesenc(data, key) {
  const k = CryptoJS.enc.Utf8.parse(key);
  const encrypted = CryptoJS.AES.encrypt(data, k, { iv: k, mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7 });
  return encrypted.toString();
}

function rsaenc(data) {
  const buffer = Buffer.from(data, 'utf8');
  const encrypted = crypto.publicEncrypt({ key: PUBLIC_KEY, padding: crypto.constants.RSA_PKCS1_PADDING }, buffer);
  return encrypted.toString('base64');
}

function gencryptoheaders(type, fp = null) {
  const e = new Date();
  const n = Math.floor(new Date(e.getUTCFullYear(), e.getUTCMonth(), e.getUTCDate(), e.getUTCHours(), e.getUTCMinutes(), e.getUTCSeconds()).getTime() / 1000);
  const r = crypto.randomUUID();
  const i = generateRandomString(16);
  const fingerPrint = fp || crypto.randomBytes(16).toString('hex');
  const s = rsaenc(i);
  let signStr = (type === 'upload') ? `${APP_ID}:${r}:${s}` : `${APP_ID}:${U_ID}:${n}:${r}:${s}`;
  return {
    'fp': fingerPrint,
    'fp1': aesenc(`${APP_ID}:${fingerPrint}`, i),
    'x-guide': s,
    'x-sign': aesenc(signStr, i),
    'x-code': Date.now().toString(),
    'Origin': 'https://live3d.io',
    'Referer': 'https://live3d.io/',
    'theme-version': '83EmcUoQTUv50LhNx0VrdcK8rcGexcP35FcZDcpgWsAXEyO4xqL5shCY6sFIWB2Q',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36'
  };
}

const deepNudeAPI = {
  upload: async (imageUrl) => {
    const tmpFile = path.join(os.tmpdir(), `dn_${Date.now()}_${generateRandomString(6)}.jpg`);
    try {
      const res = await axios({
        url: imageUrl,
        method: 'GET',
        responseType: 'stream',
        timeout: 30000,
        headers: { 'User-Agent': 'Mozilla/5.0' }
      });

      await new Promise((resolve, reject) => {
        const writer = fs.createWriteStream(tmpFile);
        res.data.pipe(writer);
        writer.on('finish', resolve);
        writer.on('error', reject);
      });

      const cryptoHeaders = gencryptoheaders('upload');
      const form = new FormData();
      form.append('file', fs.createReadStream(tmpFile), { filename: 'image.jpg', contentType: 'image/jpeg' });
      form.append('fn_name', FN_NAME);
      form.append('request_from', '9');
      form.append('origin_from', BRAND_KEY);

      const response = await axios.post('https://app-v1.live3d.io/aitools/upload-img', form, {
        headers: { ...cryptoHeaders, ...form.getHeaders() },
        maxBodyLength: Infinity,
        maxContentLength: Infinity,
        timeout: 35000
      });

      try { await fsp.unlink(tmpFile); } catch {}

      if (response.data?.code === 200 && response.data.data?.path) {
        return { imgPath: response.data.data.path, fp: cryptoHeaders.fp };
      }
      throw new Error(response.data?.message || 'Gagal upload image ke Live3D');
    } catch (e) {
      try { await fsp.unlink(tmpFile); } catch {}
      throw e;
    }
  },

  createTask: async (imagePath, fp) => {
    const cryptoHeaders = gencryptoheaders('create', fp);
    const payload = {
      fn_name: FN_NAME,
      call_type: 3,
      data: "",
      input: {
        source_image: imagePath,
        prompt: "best quality, naked, nude, uncensored",
        cloth_type: "full_outfits",
        request_from: 9,
        type: 1
      },
      request_from: 9,
      origin_from: BRAND_KEY
    };

    const response = await axios.post('https://app-v1.live3d.io/aitools/of/create', payload, {
      headers: { ...cryptoHeaders, 'Content-Type': 'application/json' },
      timeout: 30000
    });

    if (response.data?.code === 200 && response.data.data?.task_id) {
      return response.data.data.task_id;
    }
    throw new Error(response.data?.message || 'Gagal membuat task antrean Live3D');
  },

  checkStatus: async (taskId, fp) => {
    const cryptoHeaders = gencryptoheaders('check', fp);
    const payload = {
      task_id: taskId,
      fn_name: FN_NAME,
      call_type: 3,
      consume_type: 0,
      request_from: 9,
      origin_from: BRAND_KEY
    };

    const response = await axios.post('https://app-v1.live3d.io/aitools/of/check-status', payload, {
      headers: { ...cryptoHeaders, 'Content-Type': 'application/json' },
      timeout: 30000
    });

    if (response.data?.code === 200 && response.data.data?.status === 2) {
      return {
        status: 'success',
        url: 'https://temp.live3d.io/' + response.data.data.result_image
      };
    }
    return { status: 'pending' };
  },

  process: async (imageUrl) => {
    const { imgPath, fp } = await deepNudeAPI.upload(imageUrl);
    const taskId = await deepNudeAPI.createTask(imgPath, fp);

    for (let i = 0; i < 25; i++) {
      await sleep(4000);
      const res = await deepNudeAPI.checkStatus(taskId, fp);
      if (res.status === 'success') return res;
    }
    throw new Error('Pemrosesan gambar terlalu lama (timeout)');
  }
};

module.exports = {
  name: "Remove Clothes",
  desc: "Remove clothes from image using AI via direct Image URL",
  category: "Premium",
  method: "GET",
  path: "/api/prem/tonaked",
  parameters: {
    apikey: { 
      type: "string", 
      required: true
    },
    url: { 
      type: "string", 
      required: true 
    }
  },
  async run(req, res) {
    try {
      const apikey = req.apiKeyInput || req.query.apikey || req.body?.apikey || req.headers['x-apikey'];
      const targetImageUrl = req.query.url || req.body?.url;

      if (!global.apikey || !global.apikey.includes(apikey)) {
        return res.status(403).json({ status: false, error: "Apikey invalid" });
      }

      if (!targetImageUrl || !targetImageUrl.trim().startsWith('http')) {
        return res.status(400).json({ status: false, error: "Parameter 'url' gambar wajib diisi dan berupa link valid!" });
      }

      const processResult = await deepNudeAPI.process(targetImageUrl.trim());

      return res.json({
        status: true,
        result: {
          input_url: targetImageUrl,
          result_url: processResult.url
        }
      });
    } catch (err) {
      return res.status(500).json({
        status: false,
        error: err.message || "Gagal memproses gambar"
      });
    }
  }
};
