const axios = require('axios');
const cheerio = require('cheerio');
const crypto = require('crypto');

const BASE_URL = "https://temp-mail.app";

const sessionStore = new Map();
const SESSION_TTL = 30 * 60 * 1000;

function cleanupSessions() {
  const now = Date.now();
  for (const [id, s] of sessionStore.entries()) {
    if (now - s.lastUsed > SESSION_TTL) sessionStore.delete(id);
  }
}

async function apiRequest(path, params, sessionCookie, visitorId) {
  const res = await axios.get(`${BASE_URL}${path}`, {
    params,
    headers: {
      'Accept': '*/*',
      'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36',
      'Cache-Control': 'no-cache',
      'Visitor-Id': visitorId,
      'Cookie': sessionCookie || ''
    },
    timeout: 15000
  });

  const setCookie = res.headers['set-cookie'];
  const newCookie = setCookie ? setCookie.join('; ') : sessionCookie;

  return { data: res.data, cookie: newCookie };
}

function parseEmailContent(htmlString) {
  if (!htmlString) return { clean_text: "", links: [] };

  const $ = cheerio.load(htmlString);
  const links = [];
  $('a[href]').each((i, elem) => {
    const href = $(elem).attr('href');
    if (href && (href.startsWith('http://') || href.startsWith('https://'))) {
      links.push(href);
    }
  });

  $('script, style').remove();
  const cleanText = $('body').text().replace(/\n\s*\n/g, '\n').trim();

  return { clean_text: cleanText, links };
}

module.exports = [
  {
    name: "Temp Mail - Generate",
    desc: "Generate a new temporary/disposable email address valid for 24 hours. Returns a session_id used to check the inbox afterward.",
    category: "Tools",
    method: "GET",
    parameters: {
      apikey: { type: "string", required: true }
    },
    path: "/api/tools/tempmail-generate",
    async run(req, res) {
      const apikey = req.apiKeyInput || req.query?.apikey || req.body?.apikey;

      if (!global.apikey || !global.apikey.includes(apikey)) {
        return res.status(403).json({ status: false, error: "Apikey invalid" });
      }

      cleanupSessions();

      try {
        const visitorId = crypto.randomUUID();
        const { data, cookie } = await apiRequest('/api/mail/address', {
          refresh: 'true', expire: '1440', part: 'main'
        }, '', visitorId);

        if (!data.address) {
          throw new Error('Gagal generate alamat email');
        }

        const sessionId = crypto.randomUUID();
        sessionStore.set(sessionId, {
          cookie,
          visitorId,
          email: data.address,
          lastUsed: Date.now()
        });

        return res.json({
          status: true,
          result: {
            email: data.address,
            session_id: sessionId,
            expires_in_minutes: 1440
          }
        });
      } catch (err) {
        return res.status(500).json({ status: false, error: err.message || "Gagal membuat email sementara" });
      }
    }
  },
  {
    name: "Temp Mail - Check Inbox",
    desc: "Check the inbox of a previously generated temporary email using its session_id, returning parsed message content and extracted links.",
    category: "Tools",
    method: "GET",
    parameters: {
      apikey: { type: "string", required: true },
      session_id: { type: "string", required: true }
    },
    path: "/api/tools/tempmail-inbox",
    async run(req, res) {
      const apikey = req.apiKeyInput || req.query?.apikey || req.body?.apikey;
      const sessionId = req.query?.session_id || req.body?.session_id;

      if (!global.apikey || !global.apikey.includes(apikey)) {
        return res.status(403).json({ status: false, error: "Apikey invalid" });
      }
      if (!sessionId || !sessionStore.has(sessionId)) {
        return res.status(400).json({ status: false, error: "Parameter 'session_id' tidak valid atau sudah kedaluwarsa. Generate email baru terlebih dahulu." });
      }

      const stored = sessionStore.get(sessionId);
      stored.lastUsed = Date.now();

      try {
        const { data, cookie } = await apiRequest('/api/mail/list', { part: 'main' }, stored.cookie, stored.visitorId);
        stored.cookie = cookie;

        const messages = data.message || [];
        const detailedMessages = messages.map(msg => {
          const parsed = parseEmailContent(msg.content);
          return {
            id: msg.id,
            from: msg.fromName || msg.fromAddress,
            subject: msg.subject,
            date: msg.date,
            preview: msg.preview,
            clean_content: parsed.clean_text,
            extracted_links: parsed.links
          };
        });

        return res.json({
          status: true,
          result: {
            email: stored.email,
            message_count: detailedMessages.length,
            messages: detailedMessages
          }
        });
      } catch (err) {
        return res.status(500).json({ status: false, error: err.message || "Gagal mengambil inbox" });
      }
    }
  }
];