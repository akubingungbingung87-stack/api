const axios = require('axios');
const FormData = require('form-data');

const BASE = "https://shz.al";

async function uploadToShz(buffer, filename = "gtts.mp3") {
  const form = new FormData();
  form.append("c", buffer, { filename });
  form.append("e", "7d");

  const res = await axios.post(BASE, form, {
    headers: {
      ...form.getHeaders(),
      "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36",
      "Accept": "*/*",
      "Origin": BASE,
      "Referer": `${BASE}/`
    },
    timeout: 60000,
    maxBodyLength: Infinity,
    maxContentLength: Infinity
  });

  const data = typeof res.data === "string" ? JSON.parse(res.data) : res.data;
  const rawUrl = data?.url || null;
  if (!rawUrl) throw new Error("Gagal mengupload audio ke shz.al");

  const name = new URL(rawUrl).pathname.replace(/^\/+/, "");
  return `${BASE}/d/${name}`;
}

async function googleTTS(text) {
  const url = `https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=id&q=${encodeURIComponent(text)}`;
  const { data } = await axios.get(url, {
    responseType: 'arraybuffer',
    headers: { 'User-Agent': 'Mozilla/5.0' },
    timeout: 60000
  });
  return Buffer.from(data);
}

module.exports = {
  name: "Google Text To Speech",
  desc: "Ubah teks menjadi suara/audio MP3 Bahasa Indonesia via Google Translate",
  category: "Tools",
  path: "/api/tools/gtts",
  method: "GET",
  parameters: {
    apikey: { type: "string", required: true },
    text: { type: "string", required: true }
  },
  async run(req, res, next) {
    const apikey = req.apiKeyInput || req.query.apikey || req.body?.apikey;
    const text = req.query.text || req.body?.text;

    if (!global.apikey || !global.apikey.includes(apikey)) {
      return res.status(403).json({ status: false, error: "Apikey invalid" });
    }

    if (!text) {
      return res.status(400).json({
        status: false,
        error: "Parameter 'text' wajib diisi!"
      });
    }

    try {
      const audioBuffer = await googleTTS(text);
      
      let audioUrl = null;
      try {
        audioUrl = await uploadToShz(audioBuffer, `gtts-${Date.now()}.mp3`);
      } catch (e) {
        audioUrl = null;
      }

      if (audioUrl) {
        return res.json({
          status: true,
          result: {
            text: text,
            result_url: audioUrl
          }
        });
      }

      res.setHeader("Content-Type", "audio/mpeg");
      return res.send(audioBuffer);
    } catch (err) {
      return res.status(500).json({
        status: false,
        error: err.message || "Gagal memproses audio TTS"
      });
    }
  }
};