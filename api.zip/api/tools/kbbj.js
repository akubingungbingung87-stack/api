const axios = require('axios');
const cheerio = require('cheerio');

const HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
    'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
    'Accept-Encoding': 'gzip, deflate, br',
    'Connection': 'keep-alive',
    'Cache-Control': 'max-age=0',
    'Sec-Ch-Ua': '"Google Chrome";v="129", "Not=A?Brand";v="8", "Chromium";v="129"',
    'Sec-Ch-Ua-Mobile': '?0',
    'Sec-Ch-Ua-Platform': '"Windows"',
    'Sec-Fetch-Dest': 'document',
    'Sec-Fetch-Mode': 'navigate',
    'Sec-Fetch-Site': 'none',
    'Sec-Fetch-User': '?1',
    'Upgrade-Insecure-Requests': '1'
};

async function searchKbbj(query) {
    const searchRes = await axios.get(`https://kbbj.web.id/?q=${encodeURIComponent(query)}`, {
        headers: HEADERS,
        timeout: 30000
    });

    const $search = cheerio.load(searchRes.data);
    
    let targetLink = null;
    $search('.word-list a.kata').each((i, el) => {
        const text = $search(el).text().trim().toLowerCase();
        if (text === query.toLowerCase()) {
            targetLink = $search(el).attr('href');
            return false;
        }
    });

    if (!targetLink) {
        throw new Error(`Kata "${query}" tidak ditemukan dalam hasil pencarian KBBJ.`);
    }

    const fullUrl = targetLink.startsWith('http') ? targetLink : `https://kbbj.web.id${targetLink}`;
    const detailRes = await axios.get(fullUrl, {
        headers: { 
            ...HEADERS, 
            'Referer': 'https://kbbj.web.id/',
            'Sec-Fetch-Site': 'same-origin'
        },
        timeout: 30000
    });

    const $ = cheerio.load(detailRes.data);
    const title = $('.word-title').text().trim();
    const category = $('.word-category').text().trim();
    
    const rawDefinition = $('.definition').clone().children().remove().end().text().trim();
    const definition = rawDefinition.replace(/\s+/g, ' '); 

    const contributor = $('.contributor-name').text().trim();
    const date = $('.contributor-date').text().replace('Pada ', '').trim();

    return {
        kata: title,
        kategori: category || "Umum",
        definisi: definition,
        diusulkan_oleh: contributor || null,
        tanggal: date || null
    };
}

module.exports = {
    name: "KBBJ Search",
    category: "Tools",
    desc: "Pencarian definisi dan kosa kata dalam Kamus Besar Bahasa Jomok (KBBJ).",
    path: "/api/tools/kbbj",
    method: "GET",
    parameters: {
        apikey: {
            type: "string",
            required: true
        },
        query: {
            type: "string",
            required: true
        }
    },
    run: async (req, res) => {
        const apiKey = req.apiKeyInput || req.query.apikey || req.body?.apikey;
        const searchQuery = req.query?.query || req.body?.query;

        if (!apiKey || !global.apikey || !global.apikey.includes(apiKey)) {
            return res.status(403).json({
                status: false,
                message: "Apikey invalid atau tidak ditemukan"
            });
        }

        if (!searchQuery || !searchQuery.trim()) {
            return res.status(400).json({
                status: false,
                message: "Parameter 'query' (kata yang dicari) wajib diisi!"
            });
        }

        try {
            const data = await searchKbbj(searchQuery.trim());

            return res.status(200).json({
                status: true,
                result: data
            });
        } catch (err) {
            const statusCode = err.response?.status === 403 ? 403 : 500;
            return res.status(statusCode).json({
                status: false,
                message: err.message || "Gagal mengambil data dari KBBJ"
            });
        }
    }
};
