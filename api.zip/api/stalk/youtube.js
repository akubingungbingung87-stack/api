const axios = require('axios');

async function stalkYT(username) {
  if (!username.startsWith('@')) {
    username = '@' + username;
  }
  const url = `https://www.youtube.com/${username}`;

  const headers = {
    "accept-language": "en-US,en;q=0.9",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36"
  };

  const response = await axios.get(url, { headers, timeout: 20000 });
  const html = response.data;

  const match = html.match(/var ytInitialData = ({.*?});<\/script>/);
  if (!match) {
    throw new Error("Gagal menemukan data ytInitialData. Pastikan username YouTube valid.");
  }

  const data = JSON.parse(match[1]);
  const metadata = data?.metadata?.channelMetadataRenderer;

  if (!metadata) {
    throw new Error("Channel tidak ditemukan atau format data YouTube berubah.");
  }

  const channelId = metadata.externalId;
  const channelUrl = metadata.channelUrl;
  const title = metadata.title;
  const description = metadata.description;
  const avatar = metadata.avatar?.thumbnails?.[metadata.avatar.thumbnails.length - 1]?.url || "";

  let banner = "";

  function findKey(obj, key) {
    let result = null;
    function search(o) {
      if (o && typeof o === 'object') {
        if (o[key] !== undefined) {
          result = o[key];
          return true;
        }
        for (let k in o) {
          if (search(o[k])) return true;
        }
      }
      return false;
    }
    search(obj);
    return result;
  }

  const bannerImg = findKey(data.header, 'imageBannerViewModel');
  if (bannerImg?.image?.sources) {
    banner = bannerImg.image.sources[bannerImg.image.sources.length - 1].url;
  }

  let subscribers = "0";
  let videos = "0";

  const strData = JSON.stringify(data.header || {});
  const subMatch = strData.match(/"content":"([^"]+ subscribers?)"/i);
  if (subMatch) {
    subscribers = subMatch[1];
  }

  const vidMatch = strData.match(/"content":"([^"]+ videos?)"/i);
  if (vidMatch) {
    videos = vidMatch[1];
  }

  return {
    id: channelId,
    username: username,
    title: title,
    avatar: avatar,
    banner: banner,
    subscribers: subscribers,
    videos: videos,
    description: description,
    channel_url: channelUrl
  };
}

module.exports = {
  name: "YouTube Stalker",
  category: "Stalker",
  desc: "Ambil informasi lengkap profil channel YouTube seperti subscriber, jumlah video, dan banner hanya dengan username.",
  path: "/api/stalker/youtube",
  method: "GET",
  parameters: {
    apikey: {
      type: "string",
      required: true
    },
    username: {
      type: "string",
      required: true
    }
  },
  run: async (req, res) => {
    try {
      const apiKey = req.apiKeyInput || req.query.apikey || req.body?.apikey;
      const username = req.query?.username || req.body?.username;

      if (!apiKey || !global.apikey || !global.apikey.includes(apiKey)) {
        return res.status(403).json({
          status: false,
          message: "Apikey invalid atau tidak ditemukan"
        });
      }

      if (!username || !username.trim()) {
        return res.status(400).json({
          status: false,
          message: "Parameter 'username' wajib diisi!"
        });
      }

      const result = await stalkYT(username.trim());

      return res.status(200).json({
        status: true,
        result: result
      });
    } catch (err) {
      return res.status(500).json({
        status: false,
        error: err.message || "Gagal mengambil data profile YouTube"
      });
    }
  }
};