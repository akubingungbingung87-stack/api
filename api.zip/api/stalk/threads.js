const axios = require('axios');
const cheerio = require('cheerio');

async function stalkThreads(username) {
  const cleanUsername = username.replace(/^@/, '');
  const url = `https://www.threads.net/@${cleanUsername}`;

  const headers = {
    "authority": "www.threads.net",
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
    "accept-language": "en-US,en;q=0.9",
    "sec-ch-ua": "\"Not.A/Brand\";v=\"8\", \"Chromium\";v=\"114\", \"Google Chrome\";v=\"114\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Windows\"",
    "sec-fetch-dest": "document",
    "sec-fetch-mode": "navigate",
    "sec-fetch-site": "none",
    "sec-fetch-user": "?1",
    "upgrade-insecure-requests": "1",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36"
  };

  const response = await axios.get(url, { headers, timeout: 20000 });
  const html = response.data;
  const $ = cheerio.load(html);

  let userData = null;

  $('script[type="application/json"]').each((i, el) => {
    const text = $(el).html();
    if (text && text.includes('follower_count')) {
      try {
        const usernameMatch = text.match(/"username":"([^"]+)"/);
        const pkMatch = text.match(/"pk":"([^"]+)"/);
        const hdPpMatch = text.match(/"hd_profile_pic_version":\{"url":"([^"]+)"/);
        const ppMatch = text.match(/"profile_pic_url":"([^"]+)"/);
        const nameMatch = text.match(/"full_name":"([^"]*)"/);
        const followersMatch = text.match(/"follower_count":(\d+)/);
        const bioMatch = text.match(/"biography":("(?:[^"\\]|\\.)*")/);
        const verifiedMatch = text.match(/"is_verified":(true|false)/);

        if (usernameMatch) {
          let bio = "";
          if (bioMatch) {
            try {
              bio = JSON.parse(bioMatch[1]);
            } catch (e) {
              bio = bioMatch[1];
            }
          }

          let avatar = hdPpMatch ? hdPpMatch[1] : (ppMatch ? ppMatch[1] : "");
          try { avatar = JSON.parse(`"${avatar}"`); } catch (e) {}

          userData = {
            id: pkMatch ? pkMatch[1] : null,
            username: usernameMatch[1],
            full_name: nameMatch ? JSON.parse(`"${nameMatch[1]}"`) : null,
            biography: bio,
            followers: followersMatch ? parseInt(followersMatch[1]) : 0,
            is_verified: verifiedMatch ? verifiedMatch[1] === 'true' : false,
            profile_pic: avatar,
            profile_url: url
          };
        }
      } catch (e) {}
    }
  });

  if (!userData) {
    throw new Error("Data user tidak ditemukan. Pastikan username valid.");
  }

  return userData;
}

module.exports = {
  name: "Threads Stalker",
  category: "Stalker",
  desc: "Ambil informasi profil pengguna Threads seperti nama lengkap, bio, jumlah followers, centang verifikasi, dan foto profil HD hanya dengan username.",
  path: "/api/stalker/threads",
  method: "GET",
  parameters: {
    apikey: {
      type: "string",
      required: true
    },
    username: {
      type: "string",
      required: true
    }
  },
  run: async (req, res) => {
    try {
      const apiKey = req.apiKeyInput || req.query.apikey || req.body?.apikey;
      const username = req.query?.username || req.body?.username;

      if (!apiKey || !global.apikey || !global.apikey.includes(apiKey)) {
        return res.status(403).json({
          status: false,
          message: "Apikey invalid atau tidak ditemukan"
        });
      }

      if (!username || !username.trim()) {
        return res.status(400).json({
          status: false,
          message: "Parameter 'username' wajib diisi!"
        });
      }

      const result = await stalkThreads(username.trim());

      return res.status(200).json({
        status: true,
        result: result
      });
    } catch (err) {
      return res.status(500).json({
        status: false,
        error: err.message || "Gagal mengambil data profil Threads"
      });
    }
  }
};
