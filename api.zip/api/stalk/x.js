const axios = require('axios');
const cheerio = require('cheerio');

async function stalkX(username) {
  const cleanUsername = username.replace(/^@/, '');
  const url = `https://x.com/${cleanUsername}`;

  const headers = {
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
    "accept-language": "en-US,en;q=0.9",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
    "sec-fetch-dest": "document",
    "sec-fetch-mode": "navigate",
    "sec-fetch-site": "none",
    "sec-fetch-user": "?1",
    "upgrade-insecure-requests": "1"
  };

  const response = await axios.get(url, { headers, timeout: 20000 });
  const html = response.data;
  const $ = cheerio.load(html);

  const profile = {
    username: cleanUsername,
    name: "",
    description: "",
    avatar: "",
    avatar_hd: "",
    banner: "",
    banner_hd: "",
    posts: "0",
    joined: "",
    followers: 0,
    following: 0,
    profile_url: url
  };

  $('meta').each((i, el) => {
    const name = $(el).attr('name') || $(el).attr('property');
    const content = $(el).attr('content');

    if (name === 'profile:first_name') profile.name = content;
    if (name === 'description') profile.description = content;
    if (name === 'og:image') {
      profile.avatar = content;
      profile.avatar_hd = content.replace('_200x200', '').replace('_normal', '');
    }
    if (name === 'twitter:image' && content.includes('profile_banners')) {
      profile.banner = content;
      profile.banner_hd = content + "/1500x500";
    }
    if (name === 'twitter:data1') profile.posts = content;
    if (name === 'twitter:data2') profile.joined = content;
  });

  const folMatch = html.match(/followers:(\d+),following:(\d+)/);
  if (folMatch) {
    profile.followers = parseInt(folMatch[1]);
    profile.following = parseInt(folMatch[2]);
  }

  if (!profile.name && profile.followers === 0) {
    throw new Error("Data user tidak ditemukan. Pastikan username valid.");
  }

  return profile;
}

module.exports = {
  name: "Twitter / X Stalker",
  category: "Stalker",
  desc: "Ambil informasi profil pengguna Twitter/X seperti nama, bio, followers, postingan, dan avatar HD hanya dengan username.",
  path: "/api/stalker/twitter",
  method: "GET",
  parameters: {
    apikey: {
      type: "string",
      required: true
    },
    username: {
      type: "string",
      required: true
    }
  },
  run: async (req, res) => {
    try {
      const apiKey = req.apiKeyInput || req.query.apikey || req.body?.apikey;
      const username = req.query?.username || req.body?.username;

      if (!apiKey || !global.apikey || !global.apikey.includes(apiKey)) {
        return res.status(403).json({
          status: false,
          message: "Apikey invalid atau tidak ditemukan"
        });
      }

      if (!username || !username.trim()) {
        return res.status(400).json({
          status: false,
          message: "Parameter 'username' wajib diisi!"
        });
      }

      const result = await stalkX(username.trim());

      return res.status(200).json({
        status: true,
        result: result
      });
    } catch (err) {
      return res.status(500).json({
        status: false,
        error: err.message || "Gagal mengambil data profil Twitter/X"
      });
    }
  }
};
