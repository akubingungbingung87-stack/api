const axios = require('axios');

async function checkWhatsApp(phone) {
  const cleanPhone = String(phone).replace(/[^0-9]/g, '');
  const targetUrl = `https://kyuux-r.indevs.in/api/check-whatsapp2?phone=${cleanPhone}`;

  const res = await axios.get(targetUrl, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      'Accept': 'application/json'
    },
    timeout: 20000
  });

  return res.data;
}

module.exports = {
  name: "WhatsApp Checker V2",
  category: "WhatsApp",
  desc: "Check registration, ban status, and safety info for WhatsApp phone numbers",
  path: "/api/wa/checkv2",
  method: "GET",
  parameters: {
    apikey: { type: "string", required: true },
    phone: { type: "string", required: true }
  },
  run: async (req, res) => {
    const apiKey = req.apiKeyInput || req.query.apikey || req.body?.apikey;
    if (!apiKey || !global.apikey.includes(apiKey)) {
      return res.status(403).json({ status: false, message: "Apikey invalid atau tidak ditemukan" });
    }

    const phone = req.query?.phone || req.body?.phone;

    if (!phone || !phone.trim()) {
      return res.status(400).json({
        status: false,
        message: "Parameter 'phone' wajib diisi!"
      });
    }

    try {
      const result = await checkWhatsApp(phone);
      return res.status(200).json({
        status: true,
        result: result?.data || result
      });
    } catch (err) {
      return res.status(500).json({
        status: false,
        error: err.message || "Gagal melakukan pengecekan nomor WhatsApp"
      });
    }
  }
};
