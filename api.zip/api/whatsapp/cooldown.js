const axios = require('axios');

async function checkCooldown(phone) {
  const cleanPhone = phone.replace(/[^0-9]/g, '');
  const { data } = await axios.get(`https://kyuux-r.indevs.in/api/check-cooldown?phone=${cleanPhone}`, {
    timeout: 15000,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36'
    }
  });
  return data;
}

module.exports = {
  name: "Check WhatsApp Cooldown",
  desc: "Check WhatsApp verification OTP cooldown timers across SMS, Voice, and WhatsApp messages",
  category: "WhatsApp",
  path: "/api/wa/cooldown",
  method: "GET",
  parameters: {
    apikey: { type: "string", required: true },
    phone: { type: "string", required: true }
  },
  async run(req, res, next) {
    try {
      const apikey = req.apiKeyInput || req.query.apikey || req.body?.apikey;
      const phone = req.query.phone || req.body?.phone;

      if (!global.apikey || !global.apikey.includes(apikey)) {
        return res.status(403).json({ status: false, error: "Apikey invalid" });
      }

      if (!phone) {
        return res.status(400).json({ status: false, error: "Parameter 'phone' wajib diisi!" });
      }

      const result = await checkCooldown(phone);

      return res.json({
        status: true,
        result: result.data || result
      });
    } catch (err) {
      const errorMsg = err.response?.data?.message || err.message || "Terjadi kesalahan saat memeriksa cooldown WhatsApp";
      return res.status(500).json({
        status: false,
        error: errorMsg
      });
    }
  }
};
