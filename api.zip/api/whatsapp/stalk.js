const axios = require('axios');

async function stalkWhatsApp(phone) {
  const cleanPhone = phone.replace(/[^0-9]/g, '');
  const { data } = await axios.get(`https://kyuux-r.indevs.in/api/stalk-whatsapp?phone=${cleanPhone}`, {
    timeout: 15000,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36'
    }
  });
  return data;
}

module.exports = {
  name: "Stalk WhatsApp Profile",
  desc: "Stalk and inspect WhatsApp profile details and verified data by phone number",
  category: "WhatsApp",
  path: "/api/wa/stalk",
  method: "GET",
  parameters: {
    apikey: { type: "string", required: true },
    phone: { type: "string", required: true }
  },
  async run(req, res, next) {
    try {
      const apikey = req.apiKeyInput || req.query.apikey || req.body?.apikey;
      const phone = req.query.phone || req.body?.phone;

      if (!global.apikey || !global.apikey.includes(apikey)) {
        return res.status(403).json({ status: false, error: "Apikey invalid" });
      }

      if (!phone) {
        return res.status(400).json({ status: false, error: "Parameter 'phone' wajib diisi!" });
      }

      const result = await stalkWhatsApp(phone);

      return res.json({
        status: true,
        result: result.data || result
      });
    } catch (err) {
      const errorMsg = err.response?.data?.message || err.message || "Terjadi kesalahan saat men-stalk akun WhatsApp";
      return res.status(500).json({
        status: false,
        error: errorMsg
      });
    }
  }
};
