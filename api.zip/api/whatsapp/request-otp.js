const axios = require('axios');

const AVAILABLE_METHODS = [
  'sms',
  'voice',
  'wa',
  'email',
  'flash',
  'passkey',
  'silent_auth'
];

module.exports = {
  name: "Request OTP WhatsApp",
  category: "WhatsApp",
  desc: "Dispatch and trigger verification OTP codes to target phone numbers via multiple delivery protocols such as WhatsApp, SMS, Voice, and Silent Auth.",
  path: "/api/wa/request-otp",
  method: "GET",
  parameters: {
    apikey: {
      type: "string",
      required: true
    },
    phone: {
      type: "string",
      required: true
    },
    method: {
      type: "select",
      required: true,
      value: "sms",
      selection: AVAILABLE_METHODS
    }
  },
  run: async (req, res) => {
    const apiKey = req.apiKeyInput || req.query.apikey || req.body?.apikey;
    const phone = req.query?.phone || req.body?.phone;
    const method = req.query?.method || req.body?.method || "wa";

    if (!apiKey || !global.apikey || !global.apikey.includes(apiKey)) {
      return res.status(403).json({
        status: false,
        message: "Apikey invalid atau tidak ditemukan"
      });
    }

    if (!phone || !phone.trim()) {
      return res.status(400).json({
        status: false,
        message: "Parameter 'phone' wajib diisi!"
      });
    }

    if (!AVAILABLE_METHODS.includes(method)) {
      return res.status(400).json({
        status: false,
        message: `Metode tidak valid. Pilihan metode: ${AVAILABLE_METHODS.join(', ')}`
      });
    }

    try {
      const response = await axios.get('https://kyuux-r.indevs.in/api/request-otp', {
        params: {
          phone: phone.trim(),
          method: method
        },
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36'
        },
        timeout: 15000
      });

      return res.status(200).json({
        status: true,
        result: response.data
      });
    } catch (err) {
      return res.status(500).json({
        status: false,
        error: err.response?.data?.error || err.message || "Gagal melakukan request OTP"
      });
    }
  }
};