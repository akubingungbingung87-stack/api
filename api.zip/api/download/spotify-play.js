const axios = require('axios');

const BASE = 'https://spotsaver.net';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36';

function buildSearchUrl(input) {
  if (/open\.spotify\.com/i.test(input)) {
    return `${BASE}/api/spotify/?url=${encodeURIComponent(input)}`;
  }
  return `${BASE}/api/spotify/?q=${encodeURIComponent(input)}`;
}

async function searchSpotify(input) {
  const res = await axios.get(buildSearchUrl(input), {
    headers: {
      'User-Agent': UA,
      'Referer': `${BASE}/`,
      'Origin': BASE
    },
    timeout: 60000
  });
  return res.data;
}

async function getYoutubeId(title, artist) {
  const res = await axios.post(`${BASE}/api/get-id/`, {
    title,
    artist
  }, {
    headers: {
      'Content-Type': 'application/json',
      'User-Agent': UA,
      'Referer': `${BASE}/`,
      'Origin': BASE
    },
    timeout: 60000
  });
  return res.data;
}

async function getDownloadUrl(videoId, candidateIds, title) {
  const res = await axios.post(`${BASE}/api/download/`, {
    videoId,
    candidateIds: candidateIds || [],
    format: 'mp3',
    title
  }, {
    headers: {
      'Content-Type': 'application/json',
      'User-Agent': UA,
      'Referer': `${BASE}/`,
      'Origin': BASE
    },
    timeout: 60000
  });
  return res.data;
}

module.exports = {
  name: "Spotify Play",
  category: "Downloader",
  desc: "Cari lagu Spotify berdasarkan judul atau tautan lalu unduh dan putar audionya",
  path: "/api/download/spotify-play",
  method: "GET",
  parameters: {
    apikey: { type: "string", required: true },
    query: { type: "string", required: true }
  },
  run: async (req, res) => {
    const apikey = req.apiKeyInput || req.query?.apikey || req.body?.apikey || req.headers['x-apikey'];
    const query = req.query?.query || req.body?.query;

    if (!global.apikey || !global.apikey.includes(apikey)) {
      return res.status(403).json({
        status: false,
        error: "Apikey invalid"
      });
    }

    if (!query || typeof query !== 'string' || !query.trim()) {
      return res.status(400).json({
        status: false,
        error: "Parameter 'query' wajib diisi (judul lagu atau URL Spotify)!"
      });
    }

    try {
      const searchData = await searchSpotify(query.trim());
      const items = searchData?.items || [];

      if (!items.length) {
        return res.status(404).json({
          status: false,
          error: `Lagu tidak ditemukan untuk pencarian: "${query}"`
        });
      }

      const track = items[0];
      const title = track.title || 'Unknown Title';
      const artist = track.artist || 'Unknown Artist';

      let videoId = track.videoId;
      let candidateIds = [];

      if (!videoId) {
        try {
          const idResult = await getYoutubeId(title, artist);
          if (idResult && idResult.success) {
            videoId = idResult.videoId;
            candidateIds = idResult.candidateIds || [];
          }
        } catch (_) {}
      }

      if (!videoId) {
        return res.status(404).json({
          status: false,
          error: "Gagal menemukan sumber video/audio untuk lagu ini"
        });
      }

      const dlResult = await getDownloadUrl(videoId, candidateIds, title);
      const downloadUrl = dlResult?.downloadUrl || dlResult?.url || dlResult?.fileUrl || dlResult?.mediaUrl;

      if (!downloadUrl) {
        return res.status(500).json({
          status: false,
          error: "Gagal mendapatkan tautan download audio"
        });
      }

      return res.json({
        status: true,
        result: {
          title: title,
          artist: artist,
          album: track.album || null,
          duration: track.duration || null,
          thumbnail: track.thumbnail || null,
          preview_url: track.previewUrl || null,
          download_url: downloadUrl
        }
      });
    } catch (err) {
      return res.status(500).json({
        status: false,
        error: err.message || "Gagal memproses lagu Spotify"
      });
    }
  }
};