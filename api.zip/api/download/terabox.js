const axios = require('axios');
const crypto = require('crypto');

const SALT = 'T9do@SM1?xGn5';
const SIGN_PATH = '/api/stream.php';

function generateToken(timestamp) {
  return crypto.createHash('md5').update(SALT + timestamp + SIGN_PATH).digest('hex');
}

async function fetchPlayTerabox(teraboxUrl) {
  const timestamp = Math.floor(Date.now() / 1000);
  const token = generateToken(timestamp);
  const endpoint = `https://playterabox.com/api/fetch-video?token=${token}&t=${timestamp}`;

  const { data } = await axios.post(endpoint, { url: teraboxUrl }, {
    headers: {
      'Accept': '*/*',
      'Content-Type': 'application/json',
      'Origin': 'https://playterabox.com',
      'Referer': 'https://playterabox.com/',
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    },
    timeout: 30000
  });

  if (!data || data.status !== 'success') {
    throw new Error(data?.message || 'Gagal mengekstrak file dari link Terabox');
  }

  return {
    totalFiles: data.total_files,
    totalFolders: data.total_folders,
    files: (data.list || []).map(file => ({
      name: file.name,
      size: file.size_formatted,
      sizeBytes: file.size,
      duration: file.duration,
      quality: file.quality,
      thumbnail: file.thumbnail,
      downloadLink: file.download_link,
      normalDlink: file.normal_dlink,
      fastStreamUrl: file.fast_stream_url,
      subtitleUrl: file.subtitle_url
    }))
  };
}

module.exports = [
  {
    name: "Terabox Downloader",
    desc: "Extract direct download links (up to HD 1080p) and fast stream URLs from a Terabox share link, including file name, size, duration, thumbnail, and subtitle info.",
    category: "Downloader",
    method: "GET",
    parameters: {
      apikey: { type: "string", required: true },
      url: { type: "string", required: true }
    },
    path: "/api/downloader/terabox",
    async run(req, res) {
      const apikey = req.apiKeyInput || req.query?.apikey || req.body?.apikey;
      const url = req.query?.url || req.body?.url;

      if (!global.apikey || !global.apikey.includes(apikey)) {
        return res.status(403).json({ status: false, error: "Apikey invalid" });
      }

      if (!url || typeof url !== 'string' || !url.trim()) {
        return res.status(400).json({ status: false, error: "Parameter 'url' wajib diisi! (link share Terabox)" });
      }

      try {
        const result = await fetchPlayTerabox(url.trim());
        return res.json({ status: true, result });
      } catch (err) {
        const apiErr = err.response
          ? `API Error (${err.response.status}): ${JSON.stringify(err.response.data)}`
          : err.message;

        return res.status(500).json({
          status: false,
          error: apiErr || "Gagal memproses link Terabox"
        });
      }
    }
  }
];