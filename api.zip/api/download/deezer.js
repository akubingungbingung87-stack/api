const axios = require('axios');

const BASE_URL = 'https://deezdownloaders.com';
const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36';

function clean(str) {
  return String(str || '').replace(/['"]/g, '').trim();
}

async function searchDeezer(query) {
  const res = await axios.get('https://api.deezer.com/search', {
    params: { q: query, limit: 1 },
    headers: { 'User-Agent': USER_AGENT },
    timeout: 10000
  });
  return res.data?.data || [];
}

async function expandUrl(url) {
  try {
    const res = await axios.get(`${BASE_URL}/api/expandUrl.php`, {
      params: { url },
      headers: {
        'User-Agent': USER_AGENT,
        Referer: `${BASE_URL}/`
      },
      timeout: 10000
    });
    return res.data?.success && res.data?.url ? res.data.url : url;
  } catch {
    return url;
  }
}

async function normalizeUrl(input) {
  let str = String(input).trim();
  if (/^\d+$/.test(str)) {
    return `https://www.deezer.com/track/${str}`;
  }
  if (str.includes('deezer.page.link')) {
    str = await expandUrl(str);
  }
  if (str.includes('deezer.com')) {
    if (str.includes('?')) str = str.split('?')[0];
    return str;
  }
  const searchResults = await searchDeezer(str);
  if (searchResults.length && searchResults[0].link) {
    return searchResults[0].link;
  }
  return str;
}

async function getTrackInfo(urlOrId) {
  const url = await normalizeUrl(urlOrId);
  const res = await axios.get(`${BASE_URL}/api/track.php`, {
    params: { url },
    headers: {
      'User-Agent': USER_AGENT,
      Referer: `${BASE_URL}/`
    },
    timeout: 15000
  });

  const data = res.data;
  if (!data || !data.name) {
    throw new Error('Track tidak ditemukan atau link tidak didukung.');
  }

  return {
    name: data.name,
    artist: data.artist,
    album: data.album,
    duration: data.duration,
    releaseDate: data.release_date || null,
    thumbnail: data.thumb || null,
    trackPosition: data.track_position || 1,
    url: data.url || url
  };
}

async function downloadTrack(urlOrId, quality = 'MP3_128') {
  const trackInfo = await getTrackInfo(urlOrId);

  const payload = new URLSearchParams({
    name: clean(trackInfo.name),
    artist: clean(trackInfo.artist),
    url: trackInfo.url,
    token: 'none',
    zip_download: 'false',
    quality
  });

  const res = await axios.post(`${BASE_URL}/api/downloader.php`, payload.toString(), {
    headers: {
      'User-Agent': USER_AGENT,
      Referer: `${BASE_URL}/track.php`,
      Origin: BASE_URL,
      'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
      'X-Requested-With': 'XMLHttpRequest'
    },
    timeout: 30000
  });

  const data = res.data;
  if (!data || !data.success || !data.dlink) {
    throw new Error(data?.reason || 'Gagal menghasilkan link unduhan audio dari Deezer.');
  }

  return {
    title: trackInfo.name,
    artist: trackInfo.artist,
    album: trackInfo.album,
    duration: trackInfo.duration,
    thumbnail: trackInfo.thumbnail,
    download_url: data.dlink,
    source_url: trackInfo.url
  };
}

module.exports = {
  name: "Deezer Downloader",
  category: "Downloader",
  desc: "Unduh lagu Deezer berkualitas tinggi menggunakan link Deezer, ID track, atau judul lagu langsung.",
  path: "/api/downloader/deezer",
  method: "GET",
  parameters: {
    apikey: {
      type: "string",
      required: true
    },
    url: {
      type: "string",
      required: true
    },
    quality: {
      type: "select",
      required: false,
      value: "MP3_128",
      selection: ["MP3_128", "MP3_320", "FLAC"]
    }
  },
  run: async (req, res) => {
    const apiKey = req.apiKeyInput || req.query.apikey || req.body?.apikey;
    const url = req.query?.url || req.body?.url;
    const quality = req.query?.quality || req.body?.quality || "MP3_128";

    if (!apiKey || !global.apikey || !global.apikey.includes(apiKey)) {
      return res.status(403).json({
        status: false,
        message: "Apikey invalid atau tidak ditemukan"
      });
    }

    if (!url || !url.trim()) {
      return res.status(400).json({
        status: false,
        message: "Parameter 'url' wajib diisi (link lagu, ID, atau judul lagu)!"
      });
    }

    try {
      const result = await downloadTrack(url.trim(), quality);
      return res.status(200).json({
        status: true,
        result: result
      });
    } catch (err) {
      return res.status(500).json({
        status: false,
        error: err.message || "Gagal mengunduh audio dari Deezer"
      });
    }
  }
};