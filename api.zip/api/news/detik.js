const axios = require('axios');
const cheerio = require('cheerio');

const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36';

async function getDetikNews(limit = 20) {
  const res = await axios.get('https://www.detik.com/', {
    headers: { 'User-Agent': USER_AGENT },
    timeout: 15000
  });

  const $ = cheerio.load(res.data);
  const articles = [];

  $('article.list-content__item, .media__text, .media').each((i, el) => {
    const titleEl = $(el).find('h3.media__title a, .media__title a, a.media__link');
    const title = titleEl.text().trim();
    const url = titleEl.attr('href');
    const time = $(el).find('.media__date, .list-content__date').text().trim() || null;
    const thumbnail = $(el).find('img').attr('src') || $(el).find('img').attr('data-src') || null;

    if (title && url && !articles.some(a => a.url === url)) {
      articles.push({
        title,
        url,
        time,
        thumbnail
      });
    }
  });

  return articles.slice(0, Number(limit) || 20);
}

module.exports = {
  name: "Detikcom Breaking News",
  category: "News",
  desc: "Ambil daftar artikel berita terbaru, terpopuler, dan headline hari ini secara real-time dari Detikcom.",
  path: "/api/news/detik",
  method: "GET",
  parameters: {
    apikey: {
      type: "string",
      required: true
    },
    limit: {
      type: "string",
      required: false,
      example: "20"
    }
  },
  run: async (req, res) => {
    const apiKey = req.apiKeyInput || req.query.apikey || req.body?.apikey;
    const limit = req.query?.limit || req.body?.limit || 20;

    if (!apiKey || !global.apikey || !global.apikey.includes(apiKey)) {
      return res.status(403).json({
        status: false,
        message: "Apikey invalid atau tidak ditemukan"
      });
    }

    try {
      const results = await getDetikNews(limit);
      return res.status(200).json({
        status: true,
        total: results.length,
        result: results
      });
    } catch (err) {
      return res.status(500).json({
        status: false,
        error: err.message || "Gagal mengambil data berita dari Detikcom"
      });
    }
  }
};
