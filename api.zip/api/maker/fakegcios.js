const axios = require('axios');
const { createCanvas, loadImage, GlobalFonts } = require('@napi-rs/canvas');
const { writeFile, mkdir } = require('fs/promises');
const { existsSync } = require('fs');
const { join } = require('path');

const ASSETS_DIR = join(__dirname, '../../src/assets/fakegc');
const FONTS_DIR = join(ASSETS_DIR, 'fonts');
const BG_LOCAL = join(ASSETS_DIR, 'bg_fakegc.jpg');

const BG_URL = 'https://raw.githubusercontent.com/ryyntwx/Image-rinn/refs/heads/main/IMG-20260825-WA0312.jpg';
const FONT_URL = 'https://fonts.gstatic.com/s/inter/v13/UcC73FwrK3iLTeHuS_fvQtMwCp50KnMa1ZL7W0Q5nw.woff2';
const FONT_PATH = join(FONTS_DIR, 'Inter-900.woff2');

let isSetupReady = false;

async function setupAssets() {
  if (isSetupReady) return;

  await mkdir(FONTS_DIR, { recursive: true });

  if (!existsSync(FONT_PATH)) {
    const fRes = await axios.get(FONT_URL, {
      responseType: 'arraybuffer',
      headers: { 'User-Agent': 'Mozilla/5.0' },
      timeout: 15000
    });
    await writeFile(FONT_PATH, Buffer.from(fRes.data));
  }

  try {
    GlobalFonts.registerFromPath(FONT_PATH, 'InterGC');
  } catch {}

  if (!existsSync(BG_LOCAL)) {
    const bgRes = await axios.get(BG_URL, {
      responseType: 'arraybuffer',
      headers: { 'User-Agent': 'Mozilla/5.0' },
      timeout: 15000
    });
    await writeFile(BG_LOCAL, Buffer.from(bgRes.data));
  }

  isSetupReady = true;
}

async function renderFakeGcIos({ name, member, url }) {
  await setupAssets();

  const [bgImg, ppRes] = await Promise.all([
    loadImage(BG_LOCAL),
    axios.get(url, {
      responseType: 'arraybuffer',
      timeout: 15000,
      headers: { 'User-Agent': 'Mozilla/5.0' }
    })
  ]);

  const ppImg = await loadImage(Buffer.from(ppRes.data));

  const canvas = createCanvas(bgImg.width, bgImg.height);
  const ctx = canvas.getContext('2d');

  ctx.drawImage(bgImg, 0, 0, canvas.width, canvas.height);

  ctx.save();
  ctx.beginPath();
  ctx.arc(538, 362, 162, 0, Math.PI * 2, true);
  ctx.closePath();
  ctx.clip();
  ctx.drawImage(ppImg, 538 - 162, 362 - 162, 162 * 2, 162 * 2);
  ctx.restore();

  ctx.fillStyle = '#FFFFFF';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.font = '900 64px InterGC';
  ctx.fillText(name, 540, 602);

  const prefixText = 'Grup • ';
  ctx.font = '500 37px InterGC';
  const prefixWidth = ctx.measureText(prefixText).width;
  const totalWidth = prefixWidth + ctx.measureText(member).width;
  const startX = 548 - totalWidth / 2;

  ctx.fillStyle = '#8E8E93';
  ctx.textAlign = 'left';
  ctx.fillText(prefixText, startX, 684);

  ctx.fillStyle = '#34C759';
  ctx.fillText(member, startX + prefixWidth, 684);

  return canvas.encode('png');
}

module.exports = {
  name: "Fake GC iOS",
  category: "Maker",
  desc: "Generate template profil info grup WhatsApp iOS",
  path: "/api/maker/fakegcios",
  method: "GET",
  parameters: {
    apikey: {
      type: "string",
      required: true
    },
    name: {
      type: "string",
      required: true,
      example: "Nothing"
    },
    member: {
      type: "string",
      required: true,
      example: "2 anggota"
    },
    url: {
      type: "string",
      required: true,
      example: "https://example/xxx.jpg"
    }
  },
  run: async (req, res) => {
    const apiKey = req.apiKeyInput;
    if (!apiKey || !global.apikey.includes(apiKey)) {
      return res.status(403).json({ status: false, message: "Apikey invalid atau tidak ditemukan" });
    }

    const name = req.query?.name || req.body?.name;
    const member = req.query?.member || req.body?.member;
    const url = req.query?.url || req.body?.url;

    if (!name || !member || !url) {
      return res.status(400).json({
        status: false,
        message: "Parameter 'name', 'member', dan 'url' wajib diisi"
      });
    }

    try {
      const imageBuffer = await renderFakeGcIos({ name, member, url });
      res.setHeader('Content-Type', 'image/png');
      return res.send(imageBuffer);
    } catch (err) {
      return res.status(500).json({ status: false, error: err.message });
    }
  }
};