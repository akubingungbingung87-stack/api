const generateFF = require('fake-ff');
const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');

const lobbyList = Array.from({ length: 30 }, (_, i) => String(i + 1));

module.exports = {
  name: "Fake Free Fire Lobby",
  category: "Maker",
  desc: "Buat screenshot custom lobi game Free Fire dengan username dan pilihan tema lobi 1-30",
  path: "/api/maker/fakeff",
  method: "GET",
  parameters: {
    apikey: {
      type: "string",
      required: true
    },
    username: {
      type: "string",
      required: false
    },
    lobby: {
      type: "select",
      required: false,
      selection: lobbyList,
      value: "1"
    }
  },
  run: async (req, res) => {
    const apiKey = req.apiKeyInput;
    if (!apiKey || !global.apikey.includes(apiKey)) {
      return res.status(403).json({ status: false, message: "Apikey invalid atau tidak ditemukan" });
    }

    const username = req.query?.username || req.body?.username || "Player";
    const lobbyInput = req.query?.lobby || req.body?.lobby;
    const lobby = lobbyInput ? parseInt(lobbyInput, 10) : Math.floor(Math.random() * 30) + 1;

    const tmpDir = path.join(process.cwd(), 'tmp');
    if (!fs.existsSync(tmpDir)) {
      fs.mkdirSync(tmpDir, { recursive: true });
    }

    try {
      const generated = await generateFF({
        username: String(username).slice(0, 20),
        lobby: lobby,
        outputDir: tmpDir
      });

      const filePath = path.resolve(generated?.result || path.join(tmpDir, `${username}.png`));

      if (!fs.existsSync(filePath)) {
        return res.status(500).json({ status: false, message: "Gagal membuat gambar lobi Free Fire" });
      }

      const imgBuffer = await fsp.readFile(filePath);

      await fsp.unlink(filePath).catch(() => {});

      res.setHeader('Content-Type', 'image/png');
      return res.send(imgBuffer);
    } catch (err) {
      return res.status(500).json({ status: false, error: err.message });
    }
  }
};