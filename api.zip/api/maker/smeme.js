const axios = require('axios');
const FormData = require('form-data');
const cheerio = require('cheerio');
const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');

async function uploadToTop4Top(input, filename = 'image.jpg') {
  const targetUrl = 'https://top4top.io/index.php';
  const form = new FormData();

  if (typeof input === 'string') {
    if (!fs.existsSync(input)) throw new Error(`File tidak ditemukan: ${input}`);
    form.append('file_0_', fs.createReadStream(input));
  } else if (Buffer.isBuffer(input)) {
    form.append('file_0_', input, { filename });
  } else {
    throw new Error('Input harus berupa path string atau Buffer');
  }

  form.append('submitr', '[ رفع الملفات ]');

  const response = await axios.post(targetUrl, form, {
    headers: {
      ...form.getHeaders(),
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
      'Referer': 'https://top4top.io/',
      'Origin': 'https://top4top.io'
    },
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
    timeout: 30000
  });

  const $ = cheerio.load(response.data);
  const uploadedLinks = [];

  $('input[type="text"]').each((_, el) => {
    const val = $(el).val();
    if (val && (val.includes('top4top.io') || val.includes('http'))) {
      uploadedLinks.push(val.trim());
    }
  });

  if (uploadedLinks.length === 0) {
    throw new Error('Gagal mengupload gambar ke Top4Top');
  }

  const directLink = uploadedLinks.find(link => /\.(jpg|jpeg|png|gif|webp)$/i.test(link));
  return directLink || uploadedLinks[0];
}

function formatMemeText(text) {
  if (!text || text.trim() === '') return '_';
  return text
    .trim()
    .replace(/_/g, '__')
    .replace(/-/g, '--')
    .replace(/ /g, '_')
    .replace(/\?/g, '~q')
    .replace(/%/g, '~p')
    .replace(/#/g, '~h')
    .replace(/\//g, '~s');
}

module.exports = [
  {
    name: "Meme Maker (Smeme)",
    desc: "Generate customizable meme images with top and bottom text overlay from an uploaded picture.",
    category: "Maker",
    method: "POST",
    parameters: {
      apikey: { 
        type: "string", 
        required: true
      },
      file: { 
        type: "file", 
        required: true
      },
      top: { 
        type: "string", 
        required: false
      },
      bottom: { 
        type: "string", 
        required: false
      }
    },
    path: "/api/maker/smeme",
    async run(req, res) {
      const apikey = req.apiKeyInput || req.query?.apikey || req.body?.apikey || req.headers['x-apikey'];
      const top = req.query?.top || req.body?.top || "";
      const bottom = req.query?.bottom || req.body?.bottom || "";

      const uploadedFile = req.file || (req.files && req.files.length > 0 ? req.files[0] : (req.files?.file || null));

      if (!global.apikey || !global.apikey.includes(apikey)) {
        return res.status(403).json({ status: false, error: "Apikey invalid atau tidak ditemukan" });
      }

      let fileBuffer = null;
      let tempPath = null;
      let fileName = `image_${Date.now()}.png`;

      if (uploadedFile) {
        fileName = uploadedFile.originalname || uploadedFile.name || fileName;
        if (uploadedFile.path) {
          tempPath = uploadedFile.path;
          fileBuffer = await fsp.readFile(tempPath);
        } else if (uploadedFile.buffer) {
          fileBuffer = uploadedFile.buffer;
        } else if (uploadedFile.data) {
          fileBuffer = uploadedFile.data;
        }
      }

      if (!fileBuffer) {
        return res.status(400).json({ status: false, error: "Parameter 'file' gambar wajib diupload!" });
      }

      if (!top && !bottom) {
        return res.status(400).json({ status: false, error: "Minimal salah satu teks (top atau bottom) harus diisi" });
      }

      try {
        const imageUrl = await uploadToTop4Top(fileBuffer, fileName);

        const topEncoded = formatMemeText(top);
        const bottomEncoded = formatMemeText(bottom);

        const memeUrl = `https://api.memegen.link/images/custom/${encodeURIComponent(topEncoded)}/${encodeURIComponent(bottomEncoded)}.png?background=${encodeURIComponent(imageUrl)}`;

        if (tempPath && fs.existsSync(tempPath)) {
          try { await fsp.unlink(tempPath); } catch {}
        }

        return res.json({
          status: true,
          result: {
            top_text: top || null,
            bottom_text: bottom || null,
            background_url: imageUrl,
            meme_url: memeUrl
          }
        });
      } catch (err) {
        if (tempPath && fs.existsSync(tempPath)) {
          try { await fsp.unlink(tempPath); } catch {}
        }
        return res.status(500).json({
          status: false,
          error: err.response?.data?.error || err.message || "Terjadi kesalahan saat memproses gambar meme"
        });
      }
    }
  }
];