const generateCard = require('fake-ml');
const fs = require('fs');
const fsp = require('fs/promises');

const VALID_RANKS = ["epic", "glory", "gm", "honor", "imo", "legend", "mawi"];

module.exports = [
  {
    name: "Fake ML Rank Card",
    desc: "Generate a Mobile Legends style rank card image with custom avatar, username, rank badge, and border frame.",
    category: "Maker",
    method: "GET",
    parameters: {
      apikey: { type: "string", required: true },
      avatar: { type: "string", required: false },
      username: { type: "string", required: false },
      rank: {
        type: "select",
        required: false,
        selection: VALID_RANKS,
        value: "imo"
      },
      border: { type: "string", required: false }
    },
    path: "/api/maker/fake-ml",
    async run(req, res) {
      const apikey = req.apiKeyInput || req.query?.apikey || req.body?.apikey;
      const avatar = req.query?.avatar || req.body?.avatar;
      const username = req.query?.username || req.body?.username;
      const rankInput = req.query?.rank || req.body?.rank;
      const borderInput = req.query?.border || req.body?.border;

      if (!global.apikey || !global.apikey.includes(apikey)) {
        return res.status(403).json({ status: false, error: "Apikey invalid" });
      }

      if (username && username.length > 15) {
        return res.status(400).json({ status: false, error: "Parameter 'username' maksimal 15 karakter" });
      }

      const rank = rankInput && VALID_RANKS.includes(rankInput.toLowerCase()) ? rankInput.toLowerCase() : 'imo';

      let border = 0;
      if (borderInput !== undefined) {
        const parsed = parseInt(borderInput, 10);
        if (isNaN(parsed) || parsed < 0) {
          return res.status(400).json({ status: false, error: "Parameter 'border' harus berupa angka >= 0" });
        }
        border = parsed;
      }

      try {
        const options = { rank, border };
        if (avatar) options.avatar = avatar;
        if (username) options.username = username;

        const result = await generateCard(options);

        if (result.status !== 'success' || !result.result) {
          throw new Error(result.message || 'Gagal generate kartu');
        }

        const resultPath = result.result;
        const imageBuffer = fs.readFileSync(resultPath);

        res.setHeader("Content-Type", "image/png");
        res.send(imageBuffer);

        try { await fsp.unlink(resultPath); } catch (e) {}

      } catch (err) {
        return res.status(500).json({
          status: false,
          error: err.message || "Gagal membuat kartu rank"
        });
      }
    }
  }
];
