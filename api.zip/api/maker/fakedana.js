const axios = require('axios');
const { createCanvas, loadImage, GlobalFonts } = require('@napi-rs/canvas');
const { writeFile, mkdir } = require('fs/promises');
const { existsSync } = require('fs');
const { join } = require('path');

const ASSETS_DIR = join(__dirname, '../../src/assets/fakedana');
const FONTS_DIR = join(ASSETS_DIR, 'fonts');
const FONT_PATH = join(FONTS_DIR, 'PlusJakartaSans-SemiBold.ttf');
const BG_LOCAL = join(ASSETS_DIR, 'fkedana.png');
const EYE_LOCAL = join(ASSETS_DIR, 'eye_icon.jpg');

const TTF_URL = 'https://cdn.jsdelivr.net/fontsource/fonts/plus-jakarta-sans@latest/latin-600-normal.ttf';
const BG_URL = 'https://raw.githubusercontent.com/ryyntwx/Image-rinn/refs/heads/main/fkedana.png';
const EYE_URL = 'https://raw.githubusercontent.com/ryyntwx/Image-rinn/refs/heads/main/IMG-20260726-WA1031.jpg';

let isSetupReady = false;

async function setupAssets() {
  if (isSetupReady) return;

  await mkdir(FONTS_DIR, { recursive: true });

  if (!existsSync(FONT_PATH)) {
    const fontRes = await axios.get(TTF_URL, {
      responseType: 'arraybuffer',
      headers: { 'User-Agent': 'Mozilla/5.0' },
      timeout: 15000
    });
    await writeFile(FONT_PATH, Buffer.from(fontRes.data));
  }

  try {
    GlobalFonts.registerFromPath(FONT_PATH, 'DANA');
  } catch {}

  if (!existsSync(BG_LOCAL)) {
    const bgRes = await axios.get(BG_URL, {
      responseType: 'arraybuffer',
      headers: { 'User-Agent': 'Mozilla/5.0' },
      timeout: 15000
    });
    await writeFile(BG_LOCAL, Buffer.from(bgRes.data));
  }

  if (!existsSync(EYE_LOCAL)) {
    const eyeRes = await axios.get(EYE_URL, {
      responseType: 'arraybuffer',
      headers: { 'User-Agent': 'Mozilla/5.0' },
      timeout: 15000
    });
    await writeFile(EYE_LOCAL, Buffer.from(eyeRes.data));
  }

  isSetupReady = true;
}

async function renderFakeDana(nominal) {
  await setupAssets();

  const [bgImg, eyeImg] = await Promise.all([
    loadImage(BG_LOCAL),
    loadImage(EYE_LOCAL)
  ]);

  const canvas = createCanvas(bgImg.width, bgImg.height);
  const ctx = canvas.getContext('2d');

  ctx.drawImage(bgImg, 0, 0, canvas.width, canvas.height);

  const valX = 138;
  const valY = 52;
  const maxFontSize = 37;
  const eyeGap = 7;
  const eyeScale = 1.3;

  const inputSaldo = String(nominal).trim();

  let currentFontSize = maxFontSize;
  const maxAllowedWidth = canvas.width - valX - 100;

  ctx.font = `600 ${currentFontSize}px DANA`;
  let textWidth = ctx.measureText(inputSaldo).width;

  while (textWidth > maxAllowedWidth && currentFontSize > 16) {
    currentFontSize -= 2;
    ctx.font = `600 ${currentFontSize}px DANA`;
    textWidth = ctx.measureText(inputSaldo).width;
  }

  ctx.fillStyle = '#FFFFFF';
  ctx.textAlign = 'left';
  ctx.textBaseline = 'top';
  ctx.fillText(inputSaldo, valX, valY);

  const eyeHeight = currentFontSize * eyeScale;
  const eyeWidth = (eyeImg.width / eyeImg.height) * eyeHeight;
  const eyeX = valX + textWidth + eyeGap;
  const eyeY = valY + (currentFontSize - eyeHeight) / 2;

  ctx.drawImage(eyeImg, eyeX, eyeY, eyeWidth, eyeHeight);

  return canvas.encode('png');
}

module.exports = {
  name: "Fake Saldo Dana",
  category: "Maker",
  desc: "Generate mockup tampilan header saldo aplikasi DANA",
  path: "/api/maker/fakedana",
  method: "GET",
  parameters: {
    apikey: {
      type: "string",
      required: true,
      example: "vinn"
    },
    nominal: {
      type: "string",
      required: true
    }
  },
  run: async (req, res) => {
    const apiKey = req.apiKeyInput;
    if (!apiKey || !global.apikey.includes(apiKey)) {
      return res.status(403).json({ status: false, message: "Apikey invalid atau tidak ditemukan" });
    }

    const nominal = req.query?.nominal || req.body?.nominal;
    if (!nominal) {
      return res.status(400).json({
        status: false,
        message: "Parameter 'nominal' wajib diisi (contoh: 50.000 atau 1.500.000)"
      });
    }

    try {
      const buffer = await renderFakeDana(nominal);
      res.setHeader('Content-Type', 'image/png');
      return res.send(buffer);
    } catch (err) {
      return res.status(500).json({ status: false, error: err.message });
    }
  }
};
