const { createCanvas, GlobalFonts, loadImage } = require('@napi-rs/canvas');
const https = require('https');
const http = require('http');
const path = require('path');
const fs = require('fs');

const ASSETS_DIR = path.join(__dirname, '../../src/assets/iqc');
const FONTS_DIR = path.join(ASSETS_DIR, 'fonts');
const BG_DIR = path.join(ASSETS_DIR, 'backgrounds');

const REMOTE_ASSETS = [
  {
    url: 'https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/main/Font/SFPRODISPLAYREGULAR.OTF',
    dest: path.join(FONTS_DIR, 'SFPRODISPLAYREGULAR.OTF'),
  },
  {
    url: 'https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/main/Font/SFPRODISPLAYSEMIBOLD.ttf',
    dest: path.join(FONTS_DIR, 'SFPRODISPLAYSEMIBOLD.ttf'),
  },
  {
    url: 'https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/main/Image/bg.jpg',
    dest: path.join(BG_DIR, 'bg.jpg'),
  },
];

const WA_COLORS = [
  '#E53935', '#D81B60', '#8E24AA', '#5E35B1',
  '#1E88E5', '#039BE5', '#00897B', '#43A047',
  '#F4511E', '#FB8C00',
];

let colorIndex = 0;
function getNextColor() {
  const color = WA_COLORS[colorIndex % WA_COLORS.length];
  colorIndex = (colorIndex + 1) % WA_COLORS.length;
  return color;
}

const config = {
  canvas: { width: 1920, height: 3413 },
  safeZones: {
    namaAtas: {
      a: 980, b: 1080, c: 250, d: 630,
      fontSize: 55, maxChars: 25,
      font: 'SFProSemiBold', align: 'left',
    },
    foto: {
      a: 1125, b: 1713, c: 240, d: 830,
      radius: 28,
    },
    waktu: {
      a: 1750, b: 1860, c: 233, d: 424,
      fontSize: 45, maxChars: 10,
      font: 'SFProRegular', textColor: '#555555', align: 'center',
    },
    namaBawah: {
      a: 2701, b: 2880, c: 700, d: 1160,
      centerY: 2787,
      fontSize: 67, maxChars: 25,
      font: 'SFProSemiBold', textColor: '#100e0e', align: 'left',
    },
  },
};

function fetchBuffer(url) {
  return new Promise((resolve, reject) => {
    const client = url.startsWith('https') ? https : http;
    client.get(url, { headers: { 'User-Agent': 'Mozilla/5.0' }, timeout: 60000 }, (res) => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode)) {
        return fetchBuffer(res.headers.location).then(resolve).catch(reject);
      }
      if (res.statusCode !== 200) return reject(new Error(`HTTP ${res.statusCode} → ${url}`));
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => resolve(Buffer.concat(chunks)));
      res.on('error', reject);
    }).on('error', reject);
  });
}

let isSetupReady = false;

async function setupAssets() {
  if (isSetupReady) return;

  fs.mkdirSync(FONTS_DIR, { recursive: true });
  fs.mkdirSync(BG_DIR, { recursive: true });

  for (const asset of REMOTE_ASSETS) {
    if (!fs.existsSync(asset.dest) || fs.statSync(asset.dest).size === 0) {
      const buf = await fetchBuffer(asset.url);
      fs.writeFileSync(asset.dest, buf);
    }
  }

  try {
    const semibold = path.join(FONTS_DIR, 'SFPRODISPLAYSEMIBOLD.ttf');
    const regular = path.join(FONTS_DIR, 'SFPRODISPLAYREGULAR.OTF');
    if (fs.existsSync(semibold)) GlobalFonts.registerFromPath(semibold, 'SFProSemiBold');
    if (fs.existsSync(regular)) GlobalFonts.registerFromPath(regular, 'SFProRegular');
  } catch {}

  isSetupReady = true;
}

function roundedClipPath(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

function drawText(ctx, text, zone, textColor) {
  const { a, b, c, d, fontSize, maxChars, font, align, fontWeight, centerY } = zone;

  const str = String(text).slice(0, maxChars);
  const boxW = d - c;
  const boxH = b - a;
  const cy = centerY !== undefined ? centerY : a + boxH / 2;
  const weight = fontWeight || (font === 'SFProSemiBold' ? 'bold' : 'normal');

  let size = fontSize;
  ctx.textBaseline = 'middle';

  while (size > 12) {
    ctx.font = `${weight} ${size}px ${font}`;
    if (ctx.measureText(str).width <= boxW) break;
    size -= 1;
  }

  ctx.font = `${weight} ${size}px ${font}`;
  ctx.fillStyle = textColor;
  ctx.shadowColor = 'transparent';

  if (align === 'center') {
    ctx.textAlign = 'center';
    ctx.fillText(str, c + boxW / 2, cy);
  } else {
    ctx.textAlign = 'left';
    ctx.fillText(str, c, cy);
  }
}

async function drawFoto(ctx, imageSource, zone) {
  const { a, b, c, d, radius } = zone;
  const x = c;
  const y = a;
  const w = d - c;
  const h = b - a;
  const r = radius || 28;

  let img;
  if (Buffer.isBuffer(imageSource)) {
    img = await loadImage(imageSource);
  } else if (typeof imageSource === 'string') {
    if (imageSource.startsWith('http://') || imageSource.startsWith('https://')) {
      const buf = await fetchBuffer(imageSource);
      img = await loadImage(buf);
    } else {
      img = await loadImage(imageSource);
    }
  }

  const imgRatio = img.width / img.height;
  const boxRatio = w / h;

  ctx.save();
  roundedClipPath(ctx, x, y, w, h, r);
  ctx.clip();

  ctx.filter = 'blur(28px)';
  ctx.drawImage(img, x - 40, y - 40, w + 80, h + 80);
  ctx.filter = 'none';

  let fw, fh;
  if (imgRatio > boxRatio) {
    fw = w;
    fh = fw / imgRatio;
  } else {
    fh = h;
    fw = fh * imgRatio;
  }

  ctx.drawImage(img, x + (w - fw) / 2, y + (h - fh) / 2, fw, fh);
  ctx.restore();
}

async function renderIQC(name, time, imageUrl) {
  await setupAssets();

  const namaColor = getNextColor();
  const { width, height } = config.canvas;

  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');

  const bgPath = path.join(BG_DIR, 'bg.jpg');
  if (fs.existsSync(bgPath)) {
    const bgImg = await loadImage(bgPath);
    ctx.drawImage(bgImg, 0, 0, width, height);
  } else {
    ctx.fillStyle = '#f0ece4';
    ctx.fillRect(0, 0, width, height);
  }

  await drawFoto(ctx, imageUrl, config.safeZones.foto);

  drawText(ctx, name, config.safeZones.namaAtas, namaColor);
  drawText(ctx, time, config.safeZones.waktu, config.safeZones.waktu.textColor);
  drawText(ctx, name, config.safeZones.namaBawah, config.safeZones.namaBawah.textColor);

  return canvas.encode('png');
}

module.exports = {
  name: "iPhone Quoted Chat Image",
  category: "Maker",
  desc: "Generate template iPhone Quoted Chat Image WhatsApp iOS",
  path: "/api/maker/iqc-img",
  method: "GET",
  parameters: {
    apikey: {
      type: "string",
      required: true
    },
    name: {
      type: "string",
      required: true,
      example: "Nothing"
    },
    time: {
      type: "string",
      required: true,
      example: "00:00"
    },
    url: {
      type: "string",
      required: true,
      example: "https://example/xxx.jpg"
    }
  },
  run: async (req, res) => {
    const apiKey = req.apiKeyInput;
    if (!apiKey || !global.apikey.includes(apiKey)) {
      return res.status(403).json({ status: false, message: "Apikey invalid atau tidak ditemukan" });
    }

    const name = req.query?.name || req.body?.name;
    const time = req.query?.time || req.body?.time;
    const url = req.query?.url || req.body?.url;

    if (!name || !time || !url) {
      return res.status(400).json({
        status: false,
        message: "Parameter 'name', 'time', dan 'url' wajib diisi!"
      });
    }

    try {
      const imageBuffer = await renderIQC(name, time, url);
      res.setHeader('Content-Type', 'image/png');
      return res.send(imageBuffer);
    } catch (err) {
      return res.status(500).json({ status: false, error: err.message });
    }
  }
};