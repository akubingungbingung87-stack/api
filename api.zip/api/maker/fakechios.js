const axios = require('axios');
const { createCanvas, loadImage, GlobalFonts } = require('@napi-rs/canvas');
const { writeFile, mkdir, stat, unlink } = require('fs/promises');
const { existsSync } = require('fs');
const { join } = require('path');

const ASSETS_DIR = join(__dirname, '../../src/assets/fakech');
const FONTS_DIR = join(ASSETS_DIR, 'fonts');
const BG_LOCAL = join(ASSETS_DIR, 'bg_fakech.png');

const BG_URL = 'https://raw.githubusercontent.com/ryyntwx/Image-rinn/refs/heads/main/153a185e-f1de-4078-8042-fdfc56592c3d.png';

let isSetupReady = false;

async function setupAssets() {
  if (isSetupReady) return;

  await mkdir(FONTS_DIR, { recursive: true });

  const fonts = [
    {
      url: 'https://fonts.gstatic.com/s/inter/v13/UcC73FwrK3iLTeHuS_fvQtMwCp50KnMa1ZL7W0Q5nw.woff2',
      name: 'Inter-Black-900.woff2',
      family: 'InterCH',
      weight: '900'
    },
    {
      url: 'https://fonts.gstatic.com/s/inter/v13/UcC73FwrK3iLTeHuS_fvQtMwCp50KnMa1ZL7W0Q5nw.woff2',
      name: 'Inter-Medium-500.woff2',
      family: 'InterCH',
      weight: '500'
    },
    {
      url: 'https://fonts.gstatic.com/s/inter/v13/UcC73FwrK3iLTeHuS_fvQtMwCp50KnMa1ZL7W0Q5nw.woff2',
      name: 'Inter-Bold-700.woff2',
      family: 'InterCH',
      weight: '700'
    }
  ];

  for (const f of fonts) {
    const fPath = join(FONTS_DIR, f.name);
    let isValid = false;

    if (existsSync(fPath)) {
      try {
        const fileStat = await stat(fPath);
        if (fileStat.size > 2000) isValid = true;
        else await unlink(fPath);
      } catch {}
    }

    if (!isValid) {
      const fRes = await axios.get(f.url, {
        responseType: 'arraybuffer',
        headers: { 'User-Agent': 'Mozilla/5.0' },
        timeout: 60000
      });
      await writeFile(fPath, Buffer.from(fRes.data));
    }

    try {
      GlobalFonts.registerFromPath(fPath, f.family);
    } catch {}
  }

  if (!existsSync(BG_LOCAL)) {
    const bgRes = await axios.get(BG_URL, {
      responseType: 'arraybuffer',
      headers: { 'User-Agent': 'Mozilla/5.0' },
      timeout: 60000
    });
    await writeFile(BG_LOCAL, Buffer.from(bgRes.data));
  }

  isSetupReady = true;
}

async function renderFakeChIos({ name, followers, time, url }) {
  await setupAssets();

  const [bgImg, ppRes] = await Promise.all([
    loadImage(BG_LOCAL),
    axios.get(url, {
      responseType: 'arraybuffer',
      timeout: 60000,
      headers: { 'User-Agent': 'Mozilla/5.0' }
    })
  ]);

  const ppImg = await loadImage(Buffer.from(ppRes.data));

  const canvas = createCanvas(bgImg.width, bgImg.height);
  const ctx = canvas.getContext('2d');

  ctx.drawImage(bgImg, 0, 0, canvas.width, canvas.height);

  const config = {
    pp: { x: 585, y: 622, r: 213 },
    nama: { y: 908, maxSize: 68, maxWidth: 1000 },
    pengikut: { y: 995, size: 45 },
    jam: { x: 116, y: 63, size: 43 }
  };

  const followersText = `${followers} pengikut`;

  ctx.save();
  ctx.beginPath();
  ctx.arc(config.pp.x, config.pp.y, config.pp.r, 0, Math.PI * 2, true);
  ctx.closePath();
  ctx.clip();
  ctx.drawImage(ppImg, config.pp.x - config.pp.r, config.pp.y - config.pp.r, config.pp.r * 2, config.pp.r * 2);
  ctx.restore();

  ctx.fillStyle = '#FFFFFF';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';

  let fontSize = config.nama.maxSize;
  ctx.font = `900 ${fontSize}px InterCH, sans-serif`;

  while (ctx.measureText(name).width > config.nama.maxWidth && fontSize > 14) {
    fontSize -= 2;
    ctx.font = `900 ${fontSize}px InterCH, sans-serif`;
  }
  ctx.fillText(name, canvas.width / 2, config.nama.y);

  ctx.fillStyle = '#8E8E93';
  ctx.font = `500 ${config.pengikut.size}px InterCH, sans-serif`;
  ctx.fillText(followersText, canvas.width / 2, config.pengikut.y);

  ctx.fillStyle = '#FFFFFF';
  ctx.font = `700 ${config.jam.size}px InterCH, sans-serif`;
  ctx.textAlign = 'center';
  ctx.fillText(time, config.jam.x, config.jam.y);

  return canvas.encode('png');
}

module.exports = {
  name: "Fake CH iOS",
  category: "Maker",
  desc: "Generate template profil info saluran WhatsApp iOS",
  path: "/api/maker/fakechios",
  method: "GET",
  parameters: {
    apikey: {
      type: "string",
      required: true
    },
    name: {
      type: "string",
      required: true,
      example: "Nothing"
    },
    followers: {
      type: "string",
      required: true,
      example: "1.000"
    },
    time: {
      type: "string",
      required: true,
      example: "00:00"
    },
    url: {
      type: "string",
      required: true,
      example: "https://example/xxx.jpg"
    }
  },
  run: async (req, res) => {
    const apiKey = req.apiKeyInput;
    if (!apiKey || !global.apikey.includes(apiKey)) {
      return res.status(403).json({ status: false, message: "Apikey invalid atau tidak ditemukan" });
    }

    const name = req.query?.name || req.body?.name;
    const followers = req.query?.followers || req.body?.followers;
    const time = req.query?.time || req.body?.time;
    const url = req.query?.url || req.body?.url;

    if (!name || !followers || !time || !url) {
      return res.status(400).json({
        status: false,
        message: "Parameter 'name', 'followers', 'time', dan 'url' wajib diisi!"
      });
    }

    try {
      const imageBuffer = await renderFakeChIos({ name, followers, time, url });
      res.setHeader('Content-Type', 'image/png');
      return res.send(imageBuffer);
    } catch (err) {
      return res.status(500).json({ status: false, error: err.message });
    }
  }
};