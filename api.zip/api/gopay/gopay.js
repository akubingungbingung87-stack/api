const axios = require('axios');

const BASE_URL = 'https://kyuux-r.indevs.in';
const HEADERS = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
  'Accept': 'application/json'
};

async function fetchGoPay(endpoint, params = {}) {
  const query = new URLSearchParams(params).toString();
  const url = `${BASE_URL}${endpoint}${query ? '?' + query : ''}`;
  const res = await axios.get(url, { headers: HEADERS, timeout: 25000 });
  return res.data;
}

function checkKey(req) {
  const apiKey = req.apiKeyInput || req.query.apikey || req.body?.apikey;
  return Boolean(apiKey && global.apikey.includes(apiKey));
}

module.exports = [
  {
    name: "GoPay Request OTP",
    category: "GoPay",
    desc: "Request login OTP code for GoPay account",
    path: "/api/gopay/request-otp",
    method: "GET",
    parameters: {
      apikey: { type: "string", required: true },
      phone: { type: "string", required: true }
    },
    run: async (req, res) => {
      if (!checkKey(req)) return res.status(403).json({ status: false, message: "Apikey invalid atau tidak ditemukan" });
      const phone = req.query?.phone || req.body?.phone;
      if (!phone) return res.status(400).json({ status: false, message: "Parameter 'phone' wajib diisi!" });

      try {
        const data = await fetchGoPay('/api/gopay/request-otp', { phone });
        return res.status(200).json({ status: true, result: data });
      } catch (err) {
        return res.status(500).json({ status: false, error: err.message || "Gagal request OTP GoPay" });
      }
    }
  },
  {
    name: "GoPay Verify OTP",
    category: "GoPay",
    desc: "Verify GoPay OTP code and retrieve access token",
    path: "/api/gopay/verify-otp",
    method: "GET",
    parameters: {
      apikey: { type: "string", required: true },
      otp: { type: "string", required: true },
      otp_token: { type: "string", required: true }
    },
    run: async (req, res) => {
      if (!checkKey(req)) return res.status(403).json({ status: false, message: "Apikey invalid atau tidak ditemukan" });
      const otp = req.query?.otp || req.body?.otp;
      const otp_token = req.query?.otp_token || req.body?.otp_token;
      if (!otp || !otp_token) return res.status(400).json({ status: false, message: "Parameter 'otp' dan 'otp_token' wajib diisi!" });

      try {
        const data = await fetchGoPay('/api/gopay/verify-otp', { otp, otp_token });
        return res.status(200).json({ status: true, result: data });
      } catch (err) {
        return res.status(500).json({ status: false, error: err.message || "Gagal verifikasi OTP GoPay" });
      }
    }
  },
  {
    name: "GoPay Refresh Token",
    category: "GoPay",
    desc: "Refresh GoPay session token",
    path: "/api/gopay/refresh-token",
    method: "GET",
    parameters: {
      apikey: { type: "string", required: true },
      refresh_token: { type: "string", required: true }
    },
    run: async (req, res) => {
      if (!checkKey(req)) return res.status(403).json({ status: false, message: "Apikey invalid atau tidak ditemukan" });
      const refresh_token = req.query?.refresh_token || req.body?.refresh_token;
      if (!refresh_token) return res.status(400).json({ status: false, message: "Parameter 'refresh_token' wajib diisi!" });

      try {
        const data = await fetchGoPay('/api/gopay/refresh-token', { refresh_token });
        return res.status(200).json({ status: true, result: data });
      } catch (err) {
        return res.status(500).json({ status: false, error: err.message || "Gagal refresh token GoPay" });
      }
    }
  },
  {
    name: "GoPay Transaction History",
    category: "GoPay",
    desc: "Fetch GoPay account transaction history list",
    path: "/api/gopay/history",
    method: "GET",
    parameters: {
      apikey: { type: "string", required: true },
      token: { type: "string", required: true }
    },
    run: async (req, res) => {
      if (!checkKey(req)) return res.status(403).json({ status: false, message: "Apikey invalid atau tidak ditemukan" });
      const token = req.query?.token || req.body?.token;
      if (!token) return res.status(400).json({ status: false, message: "Parameter 'token' wajib diisi!" });

      try {
        const data = await fetchGoPay('/api/gopay/history', { token });
        return res.status(200).json({ status: true, result: data });
      } catch (err) {
        return res.status(500).json({ status: false, error: err.message || "Gagal mengambil riwayat transaksi GoPay" });
      }
    }
  },
  {
    name: "GoPay Payouts",
    category: "GoPay",
    desc: "Fetch GoPay payout details and information",
    path: "/api/gopay/payouts",
    method: "GET",
    parameters: {
      apikey: { type: "string", required: true },
      token: { type: "string", required: true }
    },
    run: async (req, res) => {
      if (!checkKey(req)) return res.status(403).json({ status: false, message: "Apikey invalid atau tidak ditemukan" });
      const token = req.query?.token || req.body?.token;
      if (!token) return res.status(400).json({ status: false, message: "Parameter 'token' wajib diisi!" });

      try {
        const data = await fetchGoPay('/api/gopay/payouts', { token });
        return res.status(200).json({ status: true, result: data });
      } catch (err) {
        return res.status(500).json({ status: false, error: err.message || "Gagal mengambil data payout GoPay" });
      }
    }
  },
  {
    name: "GoPay QRIS Status",
    category: "GoPay",
    desc: "Check payment status of dynamic GoPay QRIS",
    path: "/api/gopay/qris-status",
    method: "GET",
    parameters: {
      apikey: { type: "string", required: true },
      amount: { type: "string", required: true },
      created_at: { type: "string", required: true },
      token: { type: "string", required: true }
    },
    run: async (req, res) => {
      if (!checkKey(req)) return res.status(403).json({ status: false, message: "Apikey invalid atau tidak ditemukan" });
      const amount = req.query?.amount || req.body?.amount;
      const created_at = req.query?.created_at || req.body?.created_at;
      const token = req.query?.token || req.body?.token;

      if (!amount || !created_at || !token) {
        return res.status(400).json({ status: false, message: "Parameter 'amount', 'created_at', dan 'token' wajib diisi!" });
      }

      try {
        const data = await fetchGoPay('/api/gopay/qris/status', { amount, created_at, token });
        return res.status(200).json({ status: true, result: data });
      } catch (err) {
        return res.status(500).json({ status: false, error: err.message || "Gagal mengecek status QRIS GoPay" });
      }
    }
  },
  {
    name: "GoPay QRIS Create",
    category: "GoPay",
    desc: "Generate dynamic GoPay QRIS string with specific nominal",
    path: "/api/gopay/qris-create",
    method: "GET",
    parameters: {
      apikey: { type: "string", required: true },
      amount: { type: "string", required: true },
      static_qr: { type: "string", required: true }
    },
    run: async (req, res) => {
      if (!checkKey(req)) return res.status(403).json({ status: false, message: "Apikey invalid atau tidak ditemukan" });
      const amount = req.query?.amount || req.body?.amount;
      const static_qr = req.query?.static_qr || req.body?.static_qr;

      if (!amount || !static_qr) {
        return res.status(400).json({ status: false, message: "Parameter 'amount' dan 'static_qr' wajib diisi!" });
      }

      try {
        const data = await fetchGoPay('/api/gopay/qris/create', { amount, static_qr });
        return res.status(200).json({ status: true, result: data });
      } catch (err) {
        return res.status(500).json({ status: false, error: err.message || "Gagal membuat QRIS GoPay" });
      }
    }
  }
];