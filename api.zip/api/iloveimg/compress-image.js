const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const crypto = require('crypto');
const axios = require('axios');
const FormData = require('form-data');

const SITE_URL = 'https://www.iloveimg.com/compress-image';
const HEADERS = {
  'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Accept': 'text/html',
  'Accept-Language': 'en-US,en;q=0.5'
};

const SHZ_BASE = "https://shz.al";

function getMime(filename) {
  const ext = path.extname(filename).toLowerCase();
  return { '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png', '.gif': 'image/gif', '.webp': 'image/webp' }[ext] || 'application/octet-stream';
}

async function scrapeSession() {
  const { data: html } = await axios.get(SITE_URL, { headers: HEADERS, timeout: 15000 });
  const token = html.match(/"token"\s*:\s*"([^"]+)"/)?.[1];
  const taskId = html.match(/ilovepdfConfig\.taskId\s*=\s*'([^']+)'/)?.[1];
  const servers = JSON.parse('[' + (html.match(/"servers"\s*:\s*\[([^\]]+)\]/)?.[1] || '') + ']');
  if (!token || !taskId || !servers.length) throw new Error('Gagal mengambil session iloveimg');
  return { token, taskId, servers };
}

async function uploadImage(token, server, taskId, buffer, filename) {
  const form = new FormData();
  form.append('task', taskId);
  form.append('file', buffer, { filename, contentType: getMime(filename) });

  const sUrl = `https://${server}.ilovepdf.com`;
  const { data } = await axios.post(`${sUrl}/v1/upload`, form, {
    headers: { ...form.getHeaders(), 'Authorization': `Bearer ${token}`, 'Origin': 'https://www.iloveimg.com', 'Referer': SITE_URL },
    maxContentLength: Infinity,
    maxBodyLength: Infinity,
    timeout: 60000
  });
  return { sf: data.server_filename, sUrl };
}

async function doProcess(token, sUrl, taskId, sf, name, level) {
  const { data } = await axios.post(`${sUrl}/v1/process`, {
    task: taskId,
    tool: 'compressimage',
    files: [{ server_filename: sf, filename: name }],
    compress_level: level
  }, {
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}`, 'Origin': 'https://www.iloveimg.com', 'Referer': SITE_URL },
    timeout: 60000
  });
  return { outputFilesize: data.output_filesize };
}

async function downloadResult(token, sUrl, taskId) {
  const { data } = await axios.get(`${sUrl}/v1/download/${taskId}`, {
    headers: { 'Authorization': `Bearer ${token}`, 'Origin': 'https://www.iloveimg.com', 'Referer': SITE_URL },
    responseType: 'arraybuffer',
    timeout: 60000
  });
  return Buffer.from(data);
}

async function compressImage(buffer, filename, level) {
  const session = await scrapeSession();
  const { sf, sUrl } = await uploadImage(session.token, session.servers[0], session.taskId, buffer, filename);
  await doProcess(session.token, sUrl, session.taskId, sf, filename, level);
  return await downloadResult(session.token, sUrl, session.taskId);
}

async function uploadToShz(buffer, filename = "compressed.jpg") {
  const form = new FormData();
  form.append("c", buffer, { filename });
  form.append("e", "7d");

  const res = await axios.post(SHZ_BASE, form, {
    headers: {
      ...form.getHeaders(),
      "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36",
      "Accept": "*/*",
      "Origin": SHZ_BASE,
      "Referer": `${SHZ_BASE}/`
    },
    timeout: 60000,
    maxBodyLength: Infinity,
    maxContentLength: Infinity
  });

  const data = typeof res.data === "string" ? JSON.parse(res.data) : res.data;
  const rawUrl = data?.url || null;
  if (!rawUrl) throw new Error("Gagal mengupload hasil gambar ke shz.al");

  const name = new URL(rawUrl).pathname.replace(/^\/+/, "");
  return `${SHZ_BASE}/d/${name}`;
}

function randomFilename(ext = "jpg") {
  return `${crypto.randomBytes(8).toString("hex")}.${ext}`;
}

module.exports = [
  {
    name: "IloveIMG Compress Image",
    desc: "Reduce image file size while preserving visual quality using iloveimg's compression engine, with adjustable compression levels.",
    category: "Tools",
    method: "POST",
    parameters: {
      apikey: {
        type: "string",
        required: true
      },
      file: {
        type: "file",
        required: true
      },
      level: {
        type: "select",
        required: false,
        selection: ["1", "2", "3", "4"],
        value: "1"
      }
    },
    path: "/api/tools/iloveimg-compress",
    async run(req, res) {
      const apikey = req.apiKeyInput || req.query?.apikey || req.body?.apikey;
      const uploadedFile = req.files && req.files.length > 0 ? req.files[0] : null;
      const levelInput = req.query?.level || req.body?.level || "3";
      const level = ["1", "2", "3", "4"].includes(String(levelInput)) ? String(levelInput) : "3";

      if (!global.apikey.includes(apikey)) {
        return res.status(403).json({ status: false, error: "Apikey invalid" });
      }

      if (!uploadedFile || !uploadedFile.path) {
        return res.status(400).json({ status: false, error: "Wajib mengunggah file gambar (form-data: file)" });
      }

      const tempPath = uploadedFile.path;

      try {
        const buffer = fs.readFileSync(tempPath);
        const filename = uploadedFile.originalname || path.basename(tempPath);
        const inputSize = buffer.length;
        const resultBuffer = await compressImage(buffer, filename, level);

        if (tempPath && fs.existsSync(tempPath)) {
          try { await fsp.unlink(tempPath); } catch (e) {}
        }

        const savedPercent = (((inputSize - resultBuffer.length) / inputSize) * 100).toFixed(1);

        let resultUrl = null;
        try {
          resultUrl = await uploadToShz(resultBuffer, randomFilename(path.extname(filename).replace('.', '') || 'jpg'));
        } catch (e) {
          resultUrl = null;
        }

        if (resultUrl) {
          return res.json({
            status: true,
            result: {
              filename: filename,
              level: level,
              original_size_kb: (inputSize / 1024).toFixed(1),
              compressed_size_kb: (resultBuffer.length / 1024).toFixed(1),
              saved_percent: `${savedPercent}%`,
              result_url: resultUrl
            }
          });
        }

        res.setHeader("Content-Type", getMime(filename));
        return res.send(resultBuffer);

      } catch (err) {
        if (tempPath && fs.existsSync(tempPath)) {
          try { await fsp.unlink(tempPath); } catch (e) {}
        }
        const code = err.response?.status || 500;
        return res.status(code).json({
          status: false,
          error: err.message || "Gagal mengompres gambar"
        });
      }
    }
  }
];
