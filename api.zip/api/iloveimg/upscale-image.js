const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const crypto = require('crypto');
const axios = require('axios');
const cheerio = require('cheerio');
const FormData = require('form-data');

const SERVERS = [
  "api1g", "api2g", "api3g", "api8g", "api9g", "api10g", "api11g",
  "api12g", "api13g", "api14g", "api15g", "api16g", "api17g", "api18g",
  "api19g", "api20g", "api21g", "api22g", "api24g", "api25g"
];

const SHZ_BASE = "https://shz.al";

function generateTaskId() {
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789";
  let out = "";
  for (let i = 0; i < 180; i++) {
    out += chars[Math.floor(Math.random() * chars.length)];
  }
  return out;
}

async function getToken() {
  const html = await axios.get("https://www.iloveimg.com/upscale-image");
  const $ = cheerio.load(html.data);

  const script = $("script")
    .filter((_, el) => $(el).html()?.includes("ilovepdfConfig ="))
    .html();
  if (!script) throw new Error("Config tidak ditemukan");

  const jsonStr = script.split("ilovepdfConfig = ")[1].split(";")[0];
  const json = JSON.parse(jsonStr);
  const csrf = $('meta[name="csrf-token"]').attr("content");

  if (!json?.token || !csrf) throw new Error("Token/CSRF gagal diambil");
  return { token: json.token, csrf };
}

async function uploadImage(server, headers, buffer, filename, task) {
  const form = new FormData();
  form.append("name", filename);
  form.append("chunk", "0");
  form.append("chunks", "1");
  form.append("task", task);
  form.append("preview", "1");
  form.append("file", buffer, filename);

  const res = await axios.post(`https://${server}.iloveimg.com/v1/upload`, form, {
    headers: { ...headers, ...form.getHeaders() }
  });
  return res.data;
}

async function upscaleImage(buffer, filename, scale) {
  const task = generateTaskId();
  const { token, csrf } = await getToken();
  const server = SERVERS[Math.floor(Math.random() * SERVERS.length)];

  const headers = {
    Authorization: "Bearer " + token,
    Origin: "https://www.iloveimg.com/",
    Cookie: "_csrf=" + csrf,
    "User-Agent": "Mozilla/5.0"
  };

  const upload = await uploadImage(server, headers, buffer, filename, task);

  const form = new FormData();
  form.append("task", task);
  form.append("server_filename", upload.server_filename);
  form.append("scale", String(scale));

  const res = await axios.post(`https://${server}.iloveimg.com/v1/upscale`, form, {
    headers: { ...headers, ...form.getHeaders() },
    responseType: "arraybuffer"
  });

  return res.data;
}

async function uploadToShz(buffer, filename = "upscale.jpg") {
  const form = new FormData();
  form.append("c", buffer, { filename });
  form.append("e", "7d");

  const res = await axios.post(SHZ_BASE, form, {
    headers: {
      ...form.getHeaders(),
      "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36",
      "Accept": "*/*",
      "Origin": SHZ_BASE,
      "Referer": `${SHZ_BASE}/`
    },
    timeout: 60000,
    maxBodyLength: Infinity,
    maxContentLength: Infinity
  });

  const data = typeof res.data === "string" ? JSON.parse(res.data) : res.data;
  const rawUrl = data?.url || null;
  if (!rawUrl) throw new Error("Gagal mengupload hasil gambar ke shz.al");

  const name = new URL(rawUrl).pathname.replace(/^\/+/, "");
  return `${SHZ_BASE}/d/${name}`;
}

function randomFilename(ext = "jpg") {
  return `${crypto.randomBytes(8).toString("hex")}.${ext}`;
}

module.exports = [
  {
    name: "IloveIMG Upscale Image",
    desc: "Enhance and upscale image resolution up to 2x or 4x using iloveimg's AI-powered upscaling engine while preserving image quality.",
    category: "Tools",
    method: "POST",
    parameters: {
      apikey: {
        type: "string",
        required: true
      },
      file: {
        type: "file",
        required: true
      },
      scale: {
        type: "select",
        required: false,
        selection: ["2", "4"],
        value: "2"
      }
    },
    path: "/api/tools/iloveimg-upscale",
    async run(req, res) {
      const apikey = req.apiKeyInput || req.query?.apikey || req.body?.apikey;
      const uploadedFile = req.files && req.files.length > 0 ? req.files[0] : null;
      const scaleInput = req.query?.scale || req.body?.scale || "2";
      const scale = [2, 4].includes(Number(scaleInput)) ? Number(scaleInput) : 2;

      if (!global.apikey.includes(apikey)) {
        return res.status(403).json({ status: false, error: "Apikey invalid" });
      }

      if (!uploadedFile || !uploadedFile.path) {
        return res.json({ status: false, error: "Wajib mengunggah file gambar (form-data: file)" });
      }

      const tempPath = uploadedFile.path;

      try {
        const buffer = fs.readFileSync(tempPath);
        const filename = uploadedFile.originalname || path.basename(tempPath);
        const resultBuffer = await upscaleImage(buffer, filename, scale);

        if (tempPath && fs.existsSync(tempPath)) {
          try { await fsp.unlink(tempPath); } catch (e) {}
        }

        let resultUrl = null;
        try {
          resultUrl = await uploadToShz(resultBuffer, randomFilename("jpg"));
        } catch (e) {
          resultUrl = null;
        }

        if (resultUrl) {
          return res.json({
            status: true,
            result: {
              filename: filename,
              scale: scale,
              result_url: resultUrl
            }
          });
        }

        res.setHeader("Content-Type", "image/jpeg");
        return res.send(resultBuffer);

      } catch (err) {
        if (tempPath && fs.existsSync(tempPath)) {
          try { await fsp.unlink(tempPath); } catch (e) {}
        }
        const code = err.response?.status || 500;
        return res.status(code).json({
          status: false,
          error: err.message || "Gagal memproses upscale gambar"
        });
      }
    }
  }
];
