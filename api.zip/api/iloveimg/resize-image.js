const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const crypto = require('crypto');
const axios = require('axios');
const FormData = require('form-data');

const SITE_URL = 'https://www.iloveimg.com/resize-image';
const HEADERS = {
  'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
  'Accept-Language': 'en-US,en;q=0.5'
};

const SHZ_BASE = "https://shz.al";

function getMimeType(filename) {
  const ext = path.extname(filename).toLowerCase();
  return { '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png', '.gif': 'image/gif', '.webp': 'image/webp', '.bmp': 'image/bmp' }[ext] || 'application/octet-stream';
}

async function scrapeSession() {
  const { data: html } = await axios.get(SITE_URL, { headers: HEADERS, timeout: 15000 });
  const token = html.match(/"token"\s*:\s*"([^"]+)"/)?.[1];
  const taskId = html.match(/ilovepdfConfig\.taskId\s*=\s*'([^']+)'/)?.[1];
  const servers = JSON.parse('[' + (html.match(/"servers"\s*:\s*\[([^\]]+)\]/)?.[1] || '') + ']');
  if (!token || !taskId || !servers.length) throw new Error('Gagal mengambil session iloveimg');
  return { token, taskId, servers };
}

async function uploadImage(token, server, taskId, buffer, filename) {
  const form = new FormData();
  form.append('task', taskId);
  form.append('file', buffer, { filename, contentType: getMimeType(filename) });

  const serverUrl = `https://${server}.ilovepdf.com`;
  const { data } = await axios.post(`${serverUrl}/v1/upload`, form, {
    headers: { ...form.getHeaders(), 'Authorization': `Bearer ${token}`, 'Origin': 'https://www.iloveimg.com', 'Referer': SITE_URL },
    maxContentLength: Infinity,
    maxBodyLength: Infinity,
    timeout: 60000
  });
  return { serverFilename: data.server_filename, serverUrl };
}

async function processResize(token, serverUrl, taskId, serverFilename, originalName, opts) {
  const payload = {
    task: taskId,
    tool: 'resizeimage',
    files: [{ server_filename: serverFilename, filename: originalName }],
    keep_proportion: 'true',
    if_enlarge: 'false'
  };

  if (opts.percentage) {
    payload.resize_mode = 'percentage';
    payload.percentage = String(opts.percentage);
  } else {
    payload.resize_mode = 'pixels';
    if (opts.width) payload.pixels_width = String(opts.width);
    if (opts.height) payload.pixels_height = String(opts.height);
  }

  await axios.post(`${serverUrl}/v1/process`, payload, {
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}`, 'Origin': 'https://www.iloveimg.com', 'Referer': SITE_URL },
    timeout: 60000
  });
}

async function downloadResult(token, serverUrl, taskId) {
  const { data } = await axios.get(`${serverUrl}/v1/download/${taskId}`, {
    headers: { 'Authorization': `Bearer ${token}`, 'Origin': 'https://www.iloveimg.com', 'Referer': SITE_URL },
    responseType: 'arraybuffer',
    timeout: 60000
  });
  return Buffer.from(data);
}

async function resizeImage(buffer, filename, opts) {
  const session = await scrapeSession();
  const { serverFilename, serverUrl } = await uploadImage(session.token, session.servers[0], session.taskId, buffer, filename);
  await processResize(session.token, serverUrl, session.taskId, serverFilename, filename, opts);
  return await downloadResult(session.token, serverUrl, session.taskId);
}

async function uploadToShz(buffer, filename = "resized.jpg") {
  const form = new FormData();
  form.append("c", buffer, { filename });
  form.append("e", "7d");

  const res = await axios.post(SHZ_BASE, form, {
    headers: {
      ...form.getHeaders(),
      "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36",
      "Accept": "*/*",
      "Origin": SHZ_BASE,
      "Referer": `${SHZ_BASE}/`
    },
    timeout: 60000,
    maxBodyLength: Infinity,
    maxContentLength: Infinity
  });

  const data = typeof res.data === "string" ? JSON.parse(res.data) : res.data;
  const rawUrl = data?.url || null;
  if (!rawUrl) throw new Error("Gagal mengupload hasil gambar ke shz.al");

  const name = new URL(rawUrl).pathname.replace(/^\/+/, "");
  return `${SHZ_BASE}/d/${name}`;
}

function randomFilename(ext = "jpg") {
  return `${crypto.randomBytes(8).toString("hex")}.${ext}`;
}

module.exports = [
  {
    name: "IloveIMG Resize Image",
    desc: "Resize an uploaded image by specifying exact pixel dimensions (width/height) or a percentage scale, while preserving aspect ratio.",
    category: "Tools",
    method: "POST",
    parameters: {
      apikey: { type: "string", required: true },
      file: { type: "file", required: true },
      width: { type: "string", required: false },
      height: { type: "string", required: false },
      percentage: { type: "string", required: false }
    },
    path: "/api/tools/iloveimg-resize",
    async run(req, res) {
      const apikey = req.apiKeyInput || req.query?.apikey || req.body?.apikey;
      const uploadedFile = req.files && req.files.length > 0 ? req.files[0] : null;
      const widthInput = req.query?.width || req.body?.width;
      const heightInput = req.query?.height || req.body?.height;
      const percentageInput = req.query?.percentage || req.body?.percentage;

      if (!global.apikey.includes(apikey)) {
        return res.status(403).json({ status: false, error: "Apikey invalid" });
      }

      if (!uploadedFile || !uploadedFile.path) {
        return res.status(400).json({ status: false, error: "Wajib mengunggah file gambar (form-data: file)" });
      }

      const percentage = percentageInput ? parseInt(percentageInput, 10) : null;
      const width = widthInput ? parseInt(widthInput, 10) : null;
      const height = heightInput ? parseInt(heightInput, 10) : null;

      if (!percentage && !width && !height) {
        return res.status(400).json({ status: false, error: "Wajib mengisi salah satu: 'percentage', atau 'width'/'height'" });
      }

      if (percentage && (isNaN(percentage) || percentage <= 0)) {
        return res.status(400).json({ status: false, error: "Parameter 'percentage' harus berupa angka positif" });
      }

      const tempPath = uploadedFile.path;

      try {
        const buffer = fs.readFileSync(tempPath);
        const filename = uploadedFile.originalname || path.basename(tempPath);
        const inputSize = buffer.length;

        const resultBuffer = await resizeImage(buffer, filename, { width, height, percentage });

        if (tempPath && fs.existsSync(tempPath)) {
          try { await fsp.unlink(tempPath); } catch (e) {}
        }

        let resultUrl = null;
        try {
          resultUrl = await uploadToShz(resultBuffer, randomFilename(path.extname(filename).replace('.', '') || 'jpg'));
        } catch (e) {
          resultUrl = null;
        }

        const sizeLabel = percentage ? `${percentage}%` : `${width || '?'}x${height || '?'}`;

        if (resultUrl) {
          return res.json({
            status: true,
            result: {
              filename: filename,
              resize_mode: percentage ? 'percentage' : 'pixels',
              size_applied: sizeLabel,
              original_size_kb: (inputSize / 1024).toFixed(1),
              result_size_kb: (resultBuffer.length / 1024).toFixed(1),
              result_url: resultUrl
            }
          });
        }

        res.setHeader("Content-Type", getMimeType(filename));
        return res.send(resultBuffer);

      } catch (err) {
        if (tempPath && fs.existsSync(tempPath)) {
          try { await fsp.unlink(tempPath); } catch (e) {}
        }
        const code = err.response?.status || 500;
        return res.status(code).json({
          status: false,
          error: err.response?.data?.error?.message || err.message || "Gagal meresize gambar"
        });
      }
    }
  }
];
