async function getTodayHijriyah() {
  const url = 'https://khgt.muhammadiyah.or.id/';
  const res = await fetch(url, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
    }
  });

  if (!res.ok) {
    throw new Error(`HTTP Error ${res.status}`);
  }

  const html = await res.text();
  const match = html.match(/([a-zA-Z]+),\s*(\d+)\s+([a-zA-Z]+)\s+(\d{4})\s*H\s*\/\s*(\d+\s+[a-zA-Z]+\s+\d{4})/i);

  if (!match) {
    const fallback = html.match(/(\d+)\s+([a-zA-Z]+)\s+(\d{4})\s*H/i);
    if (fallback) {
      return {
        hijriyah: `${fallback[1]} ${fallback[2]} ${fallback[3]} H`,
        tanggal: parseInt(fallback[1], 10),
        bulan: fallback[2],
        tahun: parseInt(fallback[3], 10)
      };
    }
    throw new Error('Gagal mengekstrak tanggal Hijriyah dari halaman web.');
  }

  const [, hari, tglHijri, bulanHijri, thnHijri, masehiFull] = match;

  return {
    lengkap: match[0].trim(),
    hari: hari.trim(),
    hijriyah: {
      tanggal: parseInt(tglHijri, 10),
      bulan: bulanHijri.trim(),
      tahun: parseInt(thnHijri, 10),
      formatted: `${tglHijri.trim()} ${bulanHijri.trim()} ${thnHijri} H`
    },
    masehi: {
      formatted: masehiFull.trim()
    }
  };
}

module.exports = {
  name: "Kalender Hijriyah",
  category: "Islamic",
  desc: "Mendapatkan konversi tanggal Kalender Hijriah Global Tunggal (KHGT) hari ini secara real-time",
  path: "/api/islamic/hijriyah",
  method: "GET",
  parameters: {
    apikey: {
      type: "string",
      required: true
    }
  },
  run: async (req, res) => {
    const apiKey = req.apiKeyInput || req.query.apikey || req.body?.apikey;
    if (!apiKey || !global.apikey.includes(apiKey)) {
      return res.status(403).json({
        status: false,
        message: "Apikey invalid atau tidak ditemukan"
      });
    }

    try {
      const result = await getTodayHijriyah();
      return res.status(200).json({
        status: true,
        result: result
      });
    } catch (err) {
      return res.status(500).json({
        status: false,
        error: err.message || "Gagal mengambil data tanggal Hijriyah"
      });
    }
  }
};
