const NIAT_SHOLAT = {
  subuh: {
    judul: "Niat Sholat Subuh",
    arab: "أُصَلِّيَ فَرْضَ الصُّبْحِ رَكْعَتَيْنِ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً لِلّٰهِ تَعَالَى",
    latin: "Ushalli fardhas shubhi rak‘ataini mustaqbilal qiblati adā’an lillāhi ta‘ālā.",
    arti: "Aku niat shalat fardhu Subuh dua rakaat menghadap kiblat karena Allah Ta‘ala."
  },
  dzuhur: {
    judul: "Niat Sholat Dzuhur",
    arab: "أُصَلِّيَ فَرْضَ الظُّهْرِ أَرْبَعَ رَكْعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً لِلّٰهِ تَعَالَى",
    latin: "Ushalli fardhazh zhuhri arba‘a raka‘ātin mustaqbilal qiblati adā’an lillāhi ta‘ālā.",
    arti: "Aku niat shalat fardhu Dzuhur empat rakaat menghadap kiblat karena Allah Ta‘ala."
  },
  ashar: {
    judul: "Niat Sholat Ashar",
    arab: "أُصَلِّيَ فَرْضَ الْعَصْرِ أَرْبَعَ رَكْعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً لِلّٰهِ تَعَالَى",
    latin: "Ushalli fardhal ‘ashri arba‘a raka‘ātin mustaqbilal qiblati adā’an lillāhi ta‘ālā.",
    arti: "Aku niat shalat fardhu Ashar empat rakaat menghadap kiblat karena Allah Ta‘ala."
  },
  maghrib: {
    judul: "Niat Sholat Maghrib",
    arab: "أُصَلِّيَ فَرْضَ الْمَغْرِبِ ثَلَاثَ رَكْعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً لِلّٰهِ تَعَالَى",
    latin: "Ushalli fardhal maghribi tsalātsa raka‘ātin mustaqbilal qiblati adā’an lillāhi ta‘ālā.",
    arti: "Aku niat shalat fardhu Maghrib tiga rakaat menghadap kiblat karena Allah Ta‘ala."
  },
  isya: {
    judul: "Niat Sholat Isya",
    arab: "أُصَلِّيَ فَرْضَ الْعِشَاءِ أَرْبَعَ رَكْعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً لِلّٰهِ تَعَالَى",
    latin: "Ushalli fardhal ‘isyā’i arba‘a raka‘ātin mustaqbilal qiblati adā’an lillāhi ta‘ālā.",
    arti: "Aku niat shalat fardhu Isya empat rakaat menghadap kiblat karena Allah Ta‘ala."
  }
};

const WAKTU_LIST = Object.keys(NIAT_SHOLAT);

module.exports = [
  {
    name: "Niat Sholat",
    desc: "Get the recitation of prayer intentions (niat sholat) for the five daily prayers, including Arabic text, Latin transliteration, and Indonesian translation.",
    category: "Islamic",
    method: "GET",
    parameters: {
      apikey: { type: "string", required: true },
      waktu: {
        type: "select",
        required: true,
        selection: WAKTU_LIST,
        value: "subuh"
      }
    },
    path: "/api/islamic/niatsholat",
    async run(req, res) {
      const apikey = req.apiKeyInput || req.query?.apikey || req.body?.apikey;
      const waktu = (req.query?.waktu || req.body?.waktu || '').trim().toLowerCase();

      if (!global.apikey || !global.apikey.includes(apikey)) {
        return res.status(403).json({ status: false, error: "Apikey invalid" });
      }

      if (!waktu || !WAKTU_LIST.includes(waktu)) {
        return res.status(400).json({
          status: false,
          error: `Parameter 'waktu' wajib diisi salah satu dari: ${WAKTU_LIST.join(', ')}`
        });
      }

      return res.json({
        status: true,
        result: NIAT_SHOLAT[waktu]
      });
    }
  }
];
