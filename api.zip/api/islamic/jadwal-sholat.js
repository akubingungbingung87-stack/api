async function getHtml(url) {
  const res = await fetch(url, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
    }
  });
  if (!res.ok) throw new Error(`Gagal mengambil data dari penyedia (Status ${res.status})`);
  return await res.text();
}

async function fetchJadwalSholat(kota) {
  const keyword = kota.trim().toLowerCase();
  const baseUrl = 'https://jadwalsholat.org/jadwal-sholat/monthly.php';
  const mainHtml = await getHtml(baseUrl);

  const daftarKota = [];
  const optionRegex = /<option\s+value="(\d+)"[^>]*>([^<]+)<\/option>/gi;
  let matchOption;

  while ((matchOption = optionRegex.exec(mainHtml)) !== null) {
    const id = matchOption[1];
    const nama = matchOption[2].trim();
    if (id !== '0') {
      daftarKota.push({ id, nama });
    }
  }

  const matched = daftarKota.filter(k => k.nama.toLowerCase().includes(keyword));

  if (matched.length === 0) {
    throw new Error(`Kota '${kota}' tidak ditemukan.`);
  }

  const kotaTerpilih = matched[0];
  const targetUrl = `${baseUrl}?id=${kotaTerpilih.id}`;
  const scheduleHtml = await getHtml(targetUrl);

  const rowRegex = /<tr\s+class="table_(?:light|dark)"[\s\S]*?<\/tr>/gi;
  const tdRegex = /<td[^>]*>([\s\S]*?)<\/td>/gi;

  const jadwal = [];
  let matchRow;

  while ((matchRow = rowRegex.exec(scheduleHtml)) !== null) {
    const rowHtml = matchRow[0];
    const cols = [];
    let matchTd;

    while ((matchTd = tdRegex.exec(rowHtml)) !== null) {
      const cleanText = matchTd[1]
        .replace(/<[^>]+>/g, '')
        .replace(/&nbsp;/g, ' ')
        .trim();
      cols.push(cleanText);
    }

    if (cols.length >= 9) {
      jadwal.push({
        tanggal: cols[0],
        imsyak: cols[1],
        subuh: cols[2],
        terbit: cols[3],
        dhuha: cols[4],
        dzuhur: cols[5],
        ashar: cols[6],
        maghrib: cols[7],
        isya: cols[8]
      });
    }
  }

  return {
    id: kotaTerpilih.id,
    kota: kotaTerpilih.nama,
    total_hari: jadwal.length,
    jadwal: jadwal
  };
}

module.exports = {
  name: "Jadwal Sholat",
  category: "Islamic",
  desc: "Monthly prayer schedule scraper for various Indonesian cities and regencies",
  path: "/api/islamic/jadwal-sholat",
  method: "GET",
  parameters: {
    apikey: {
      type: "string",
      required: true
    },
    kota: {
      type: "string",
      required: true
    }
  },
  run: async (req, res) => {
    const apiKey = req.apiKeyInput || req.query.apikey || req.body?.apikey;
    if (!apiKey || !global.apikey.includes(apiKey)) {
      return res.status(403).json({
        status: false,
        message: "Apikey invalid atau tidak ditemukan"
      });
    }

    const kota = req.query?.kota || req.body?.kota;
    if (!kota || !kota.trim()) {
      return res.status(400).json({
        status: false,
        message: "Parameter 'kota' wajib diisi!"
      });
    }

    try {
      const result = await fetchJadwalSholat(kota);
      return res.status(200).json({
        status: true,
        result: result
      });
    } catch (err) {
      return res.status(500).json({
        status: false,
        error: err.message || "Gagal mengambil jadwal sholat"
      });
    }
  }
};